"""Export every selected paper's stored full-text analysis and provenance."""
from datetime import datetime
from pathlib import Path
import hashlib
import json
import unicodedata

from docx import Document
from docx.shared import Inches, Pt
from docx.oxml import OxmlElement
from docx.oxml.ns import qn

from literature_ai.config import settings
from literature_ai.analysis.schema import SUMMARY_FIELDS
from literature_ai.export.outputs import ENTITY_COLUMNS
from literature_ai.utils.common import MISSING, normalize_doi

LABELS = dict(zip(SUMMARY_FIELDS, [
    '研究内容','研究背景','科学问题','待解决问题','解决思路','实验设计','实验细胞','细胞类型',
    '动物模型','疾病模型','组织','研究方法','关键技术','主要结果','结论','局限','未来方向','争议',
    '已知机制','新机制','新信号轴','与既有知识的比较','新颖性','机制创新','方法创新','材料创新',
    '诊断创新','治疗创新','探针创新','靶点创新','潜在靶向分子','潜在靶向肽','潜在底物',
    '潜在抑制剂','潜在激活剂','探针应用','纳米医学应用',
], strict=True))
ENTITY_LABELS = {'pathways':'信号通路','proteins':'蛋白','enzymes':'酶',
                 'abbreviations':'缩写','mechanisms':'机制','innovations':'创新点'}


def reviewed_note(paper):
    """Accept curated readings only when DOI, PDF hash and page quotes match."""
    pdf = Path(paper['PDF_Local_Path']) if paper.get('PDF_Local_Path') else None
    full = Path(paper['Fulltext_Path']) if paper.get('Fulltext_Path') else None
    if not pdf or not pdf.is_file() or not full or not full.is_file():
        return None
    digest = hashlib.sha256(pdf.read_bytes()).hexdigest()
    norm = lambda value: ''.join(c for c in unicodedata.normalize('NFKC',value).casefold() if c.isalnum())
    pages = None
    for candidate in sorted((settings.root / 'library/notes').glob(f'reviewed_*/{paper["id"]}_reading.json'), reverse=True):
        try:
            note = json.loads(candidate.read_text(encoding='utf-8'))
            if note.get('pdf_sha256') != digest or normalize_doi(note.get('metadata',{}).get('DOI')) != normalize_doi(paper.get('DOI')):
                continue
            if pages is None:
                pages = {p['page']:p['text'] for p in json.loads(full.read_text(encoding='utf-8'))['pages']}
            if not note.get('evidence') or any(not quote.strip() or norm(quote) not in norm(pages.get(page,'')) for page,section,quote in note['evidence']):
                continue
            return note
        except (ValueError, KeyError, TypeError, OSError):
            continue
    return None


def render_reviewed(doc, note):
    doc.add_paragraph(note['kind'])
    for label, key in [('研究概要与关注价值','summary'),('研究背景与科学问题','background'),
                       ('实验设计与研究对象','design'),('方法与关键技术','methods')]:
        doc.add_heading(label,2)
        doc.add_paragraph(note[key])
    doc.add_heading('主要结果与结论',2)
    for result in note['results']:
        doc.add_paragraph(result)
    doc.add_heading('核心机制与信号通路',2)
    for name, text, ref in note['pathways']:
        doc.add_paragraph(f'{name}：{text} 【{ref}】')
    doc.add_heading('关键蛋白、酶与定位',2)
    for molecule in note['molecules']:
        doc.add_paragraph('；'.join(molecule))
    for label, key in [('创新点','novelty'),('靶点、探针与材料','targets'),
                       ('局限与争议','limits'),('后续研究方向','future')]:
        doc.add_heading(label,2)
        doc.add_paragraph(note[key])
    doc.add_heading('后续检索关键词',2)
    doc.add_paragraph('；'.join(note['keywords']))
    doc.add_heading('原文证据与 PDF 页码',2)
    for i,(page,section,quote) in enumerate(note['evidence'],1):
        doc.add_paragraph(f'[E{i}] PDF p.{page} | {section}：{quote}')


def reading_report(store, doi=None, batch=None):
    if batch:
        from literature_ai.batches import batch_papers
        papers = batch_papers(store,batch)
    else:
        papers = store.papers()
    if doi:
        papers = [p for p in papers if normalize_doi(p.get('DOI')) == normalize_doi(doi)]
    if not papers:
        raise ValueError('No matching papers; search first')
    entities = {table: store.rows(table) for table in ENTITY_COLUMNS}
    evidence = store.rows('evidence')
    reviewed = {p['id']: reviewed_note(p) for p in papers}
    detailed = [p for p in papers if reviewed[p['id']] or p.get('analysis_status') == 'complete']
    pending = [p for p in papers if not reviewed[p['id']] and p.get('analysis_status') != 'complete']
    doc = Document()
    for element in (doc.styles.element,doc.element):
        for border in list(element.iter(qn('w:pBdr'))):
            border.getparent().remove(border)
    section = doc.sections[0]
    section.page_width, section.page_height = Inches(8.27), Inches(11.69)
    section.top_margin = section.bottom_margin = Inches(.75)
    section.left_margin = section.right_margin = Inches(.8)
    for name in ('Normal','Title','Heading 1','Heading 2','Heading 3'):
        style = doc.styles[name]
        style.font.name = 'Microsoft YaHei'
        style.element.get_or_add_rPr().rFonts.set(qn('w:eastAsia'), 'Microsoft YaHei')
        style.paragraph_format.space_after = Pt(6)
        if name.startswith('Heading'):
            style.paragraph_format.keep_with_next = True
    doc.styles['Normal'].font.size = Pt(10.5)
    doc.styles['Normal'].paragraph_format.line_spacing = 1.15
    doc.styles['Normal'].paragraph_format.widow_control = True
    doc.add_heading('LiteratureAI 全文解读汇总' if detailed else 'LiteratureAI 待解读文献清单', 0)
    analysed = len(detailed)
    if batch:
        doc.add_paragraph(f'调研主题：{batch["topic"]}\n批次日期：{batch["date"]}\n批次文件夹：{Path(batch["folder"]).name}')
    doc.add_paragraph(f'收录 {len(papers)} 篇；已完成全文分析 {analysed} 篇；待完成 {len(papers)-analysed} 篇。')
    doc.add_paragraph('逐篇汇总知识库中的全文分析。原文证据附文件页码；System inference 表示推断。引文匹配不能替代研究者对上下文和科学结论的复核。')
    if detailed:doc.add_heading('已详细解读文献索引', 1)
    for i, paper in enumerate(detailed, 1):
        doc.add_paragraph(f'{i}. {paper["Title"]} | {paper.get("Year", "")} | {paper.get("DOI", "")}')
    for i, p in enumerate(detailed, 1):
        doc.add_heading(f'{i}. {p["Title"]}', 1).paragraph_format.page_break_before = True
        doc.add_paragraph(f'{p.get("Journal", "")} | {p.get("Year", "")}\nDOI: {p.get("DOI", "")}')
        doc.add_paragraph('PDF: ' + str(p.get('PDF_Local_Path') or '尚未取得全文'))
        if reviewed[p['id']]:
            render_reviewed(doc, reviewed[p['id']])
            continue
        doc.add_heading('中文研究概要', 2)
        doc.add_paragraph(p.get('Chinese_Summary') or MISSING)
        for field in SUMMARY_FIELDS:
            doc.add_heading(LABELS[field], 3)
            doc.add_paragraph(str(p.get(field) or MISSING))
        for table, records in entities.items():
            selected = [r for r in records if r['paper_id'] == p['id']]
            if not selected:
                continue
            doc.add_heading(ENTITY_LABELS[table], 2)
            for row in selected:
                for key in ENTITY_COLUMNS[table]:
                    value = row.get(key)
                    if value not in (None, '', MISSING):
                        doc.add_paragraph(f'{LABELS.get(key, key)}：{value}')
        doc.add_heading('原文证据与页码', 2)
        refs = [r for r in evidence if r['paper_id'] == p['id']]
        for n, row in enumerate(refs, 1):
            mark = 'System inference' if row.get('Inferred') == 'Yes' else '原文明示'
            doc.add_paragraph(f'[{n}] {LABELS.get(row.get("field"), row.get("field", ""))} | PDF p.{row.get("Evidence_Page", "")} | {row.get("Evidence_Section", "")} | {mark}')
            doc.add_paragraph(str(row.get('value', '')))
            doc.add_paragraph('原文：' + str(row.get('Evidence_Text', '')))
        if not refs:
            doc.add_paragraph('缺少可追溯证据记录，需重新分析或人工复核。')
        doc.add_heading('后续检索关键词', 2)
        doc.add_paragraph('；'.join(p.get('Recommended_Search_Keywords', [])) or MISSING)
    if pending:
        doc.add_heading('待解读文献清单',1).paragraph_format.page_break_before = bool(detailed)
        doc.add_paragraph('以下文章尚未完成详细全文解读，保留在本批次。已下载仅表示取得 PDF，不代表已经完成科学内容分析。')
        for p in pending:
            has_pdf = bool(p.get('PDF_Local_Path')) and Path(p['PDF_Local_Path']).is_file()
            doc.add_paragraph(f'R{p["id"]:05d}  {p["Title"]}\nDOI：{p.get("DOI", "")} | '+('PDF已下载，待解读' if has_pdf else 'PDF未取得，待下载和解读'))
    footer = section.footer.paragraphs[0]
    footer.alignment = 2
    field = OxmlElement('w:fldSimple')
    field.set(qn('w:instr'), 'PAGE')
    footer._p.append(field)
    folder = Path(batch['folder']) if batch else settings.root / 'exports'
    folder.mkdir(parents=True, exist_ok=True)
    filename = folder.name + ('_详细解读' if detailed else '_待解读清单') if batch else 'LiteratureAI_全文解读汇总_' + datetime.now().strftime('%Y-%m-%d_%H%M%S_%f')
    target = folder / (filename + '.docx')
    version = 2
    while target.exists():
        target = folder / (filename + f'_v{version}.docx')
        version += 1
    tmp = target.with_suffix('.tmp.docx')
    doc.save(tmp)
    Document(tmp)
    tmp.replace(target)
    return {'status': 'complete', 'file': str(target), 'papers': len(papers), 'analysed': analysed,
            'pending': len(papers) - analysed, 'detailed_paper_ids':[p['id'] for p in detailed]}
