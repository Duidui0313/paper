"""Command-line entry points for the local literature library."""
import argparse
import importlib.util
import json
import logging
import os
from pathlib import Path
import shutil
import subprocess
import sys
from datetime import datetime

TASK_NAME = "LiteratureAI Weekly Report"


def emit(value):
    print(json.dumps(value, ensure_ascii=False, default=str, indent=2))


def task_status():
    if os.name != "nt":
        return {"status":"unavailable", "reason":"Windows Task Scheduler required"}
    script = "$ErrorActionPreference='Stop'; [Console]::OutputEncoding=[System.Text.UTF8Encoding]::new(); try { $task=Get-ScheduledTask -TaskName 'LiteratureAI Weekly Report' -ErrorAction Stop; $info=$task | Get-ScheduledTaskInfo; [pscustomobject]@{status='registered'; TaskName=$task.TaskName; State=[string]$task.State; NextRun=$info.NextRunTime.ToString('o'); LastRun=$info.LastRunTime.ToString('o'); LastTaskResult=$info.LastTaskResult; LogonType=[string]$task.Principal.LogonType; UserId=$task.Principal.UserId} | ConvertTo-Json -Compress } catch { if ($_.Exception.Message -match 'No MSFT_ScheduledTask|not found|找不到|No matching') { @{status='not_registered'} | ConvertTo-Json -Compress } else { @{status='unavailable';reason=$_.Exception.GetType().Name} | ConvertTo-Json -Compress } }"
    try:
        result = subprocess.run(["powershell.exe","-NoProfile","-NonInteractive","-Command",script], capture_output=True, timeout=20, creationflags=getattr(subprocess,"CREATE_NO_WINDOW",0))
        if result.returncode: return {"status":"unavailable", "reason":"Task Scheduler query failed"}
        return json.loads(result.stdout.decode("utf-8-sig").strip())
    except Exception as exc:
        return {"status":"unavailable", "reason":type(exc).__name__}


def doctor():
    from literature_ai.config import settings,openai_key_available
    from literature_ai.database.store import Store
    from literature_ai.email.smtp import configured
    packages = ("httpx","requests","pandas","openpyxl","docx","fitz","pypdf","bs4","lxml","rapidfuzz","streamlit","playwright","dotenv","openai")
    result = {"root":str(settings.root), "python":sys.executable, "python_version":sys.version.split()[0],
        "dependencies":{name:bool(importlib.util.find_spec(name)) for name in packages},
        "OpenAI_API":"configured; connectivity not tested" if openai_key_available() else "configuration_required",
        "SMTP":"configured; delivery not tested" if configured() else "configuration_required",
        "OpenAlex_API":"key configured" if settings.openalex_api_key else "anonymous limited quota",
        "browser_components":any((settings.root / ".playwright").glob("chromium-*")),
        "institutional_access":"article-specific access is checked during download; no global entitlement inferred",
        "scheduled_task":task_status()}
    store = Store()
    try:
        result["database"] = str(store.path)
        result["database_check"] = store.conn.execute("PRAGMA integrity_check").fetchone()[0]
        result["papers"] = len(store.papers())
        runs = store.rows("weekly_runs")
        result["last_weekly_run"] = runs[-1] if runs else None
        result["disk_free_gb"] = round(shutil.disk_usage(settings.root).free / 1024**3, 2)
    finally: store.close()
    return result


def launch_ui(port=8501):
    import httpx
    import webbrowser
    try:
        if httpx.get(f"http://127.0.0.1:{port}/_stcore/health",timeout=2).status_code==200:
            webbrowser.open(f"http://127.0.0.1:{port}")
            return 0
    except httpx.HTTPError:
        pass
    script = Path(__file__).parent / "ui/app.py"
    command = [sys.executable,"-m","streamlit","run",str(script),"--server.address=127.0.0.1",f"--server.port={port}","--browser.gatherUsageStats=false","--server.headless=true"]
    webbrowser.open(f"http://127.0.0.1:{port}")
    return subprocess.call(command)


def process_papers(pipeline, action, pending=False, doi="", all_papers=False):
    from literature_ai.parser.pdf import parse_paper
    from literature_ai.analysis.analyzer import analyze_paper
    from literature_ai.export.outputs import write_note
    from literature_ai.utils.common import normalize_doi
    papers = pipeline.store.papers()
    if doi:
        papers = [p for p in papers if normalize_doi(p.get("DOI")) == normalize_doi(doi)]
        if not papers: raise ValueError("DOI不在知识库中；请先检索或导入该文献")
    elif action == "retry-download":
        papers = [p for p in papers if p.get("download_status") == "failed"]
    elif action == "download":
        papers = [p for p in papers if p.get("download_status") == "pending" or (not pending and p.get("download_status") != "downloaded")]
    results = []
    from literature_ai.batches import create_batch,add_paper,finish_batch
    batches={}
    for p in papers:
        topic=p.get('Original_Search_Query') or '文献补充处理'
        if topic not in batches: batches[topic]=create_batch(pipeline.store,topic)
        batch=batches[topic]
        pipeline.downloader.batch=batch
        try:
            if action != "analyze" or not p.get("PDF_Local_Path"):
                p = pipeline.downloader.fetch(p)
            if p.get("download_status") == "downloaded" and p.get("parse_status") != "parsed":
                p = parse_paper(p,pipeline.store)
            if action == "analyze": p = analyze_paper(p,pipeline.store)
            add_paper(pipeline.store,batch,p)
            write_note(p,pipeline.store)
            results.append(p)
        finally:
            pipeline.downloader.batch=None
    for batch in batches.values(): pipeline.last_batch=finish_batch(pipeline.store,batch)
    return results


def results_summary(papers):
    from collections import Counter
    return {"count":len(papers),"download_status":dict(Counter(p.get("download_status","pending") for p in papers)),
        "analysis_status":dict(Counter(p.get("analysis_status","pending") for p in papers)),
        "papers":[{k:p.get(k) for k in ("id","Title","Year","DOI","PDF_Local_Path","download_status","parse_status","analysis_status")} for p in papers]}


def parser():
    root = argparse.ArgumentParser(prog="literature-ai",description="LiteratureAI 科研文献检索、合法全文下载和周报")
    sub = root.add_subparsers(dest="command")
    search = sub.add_parser("search",help="检索并保存数据库与Excel")
    search.add_argument("keyword")
    search.add_argument("--from",dest="start_year",type=int,default=2021)
    search.add_argument("--to",dest="end_year",type=int,default=datetime.now().year)
    search.add_argument("--max",dest="max_results",type=int,default=100)
    search.add_argument("--journal",default="")
    search.add_argument("--open-access-only",dest="oa_only",action="store_true")
    search.add_argument("--download",action="store_true")
    search.add_argument("--analyze",action="store_true")
    download = sub.add_parser("download",help="下载尚无PDF的文献")
    download.add_argument("--pending",action="store_true")
    sub.add_parser("retry-download",help="重试失败下载")
    analysis = sub.add_parser("analyze",help="分析已有或新取得的全文")
    selection = analysis.add_mutually_exclusive_group(required=True)
    selection.add_argument("--all",dest="all_papers",action="store_true")
    selection.add_argument("--doi")
    sub.add_parser("export",help="导出Excel主表和Markdown笔记")
    reading=sub.add_parser('reading-report',help='生成全部或指定调研批次的全文解读 Word')
    reading.add_argument('--doi')
    reading.add_argument('--batch',help='调研批次 ID；输出到该批次文件夹')
    sub.add_parser('batches',help='列出按日期和主题归档的调研批次')
    ui = sub.add_parser("ui",help="启动127.0.0.1本地界面")
    ui.add_argument("--port",type=int,default=8501)
    weekly = sub.add_parser("weekly-report",help="更新文献并生成Excel/Word周报")
    weekly.add_argument("--send-email",action="store_true")
    weekly.add_argument("--no-refresh",action="store_true",help="只生成当前知识库报告，跳过联网更新")
    sub.add_parser("resend-weekly-report",help="重发最近失败/待配置的周报邮件")
    sub.add_parser("test-email",help="发送一封SMTP测试邮件")
    login = sub.add_parser("login",help="打开可见浏览器，由本人手动登录出版社")
    login.add_argument("url")
    session = sub.add_parser("session-download",help="复用本人登录会话获取一个正常PDF链接")
    session.add_argument("url")
    session.add_argument("--doi",required=True,help="知识库已有文献DOI")
    sub.add_parser("doctor",help="检查依赖、数据库、配置与真实计划任务状态")
    return root


def app(argv=None):
    args = parser().parse_args(argv)
    if not args.command: args.command = "ui"; args.port = 8501
    if args.command == "ui":
        if not 1024 <= args.port <= 65535: raise SystemExit("port must be between 1024 and 65535")
        return launch_ui(args.port)
    from literature_ai.config import settings
    logdir = settings.root / ("logs/weekly" if args.command == "weekly-report" else "logs")
    logdir.mkdir(parents=True,exist_ok=True)
    logpath = logdir / (datetime.now().strftime("%Y%m%d_%H%M%S")+"_"+args.command+f"_{os.getpid()}.log")
    logging.basicConfig(filename=logpath,level=logging.INFO,format="%(asctime)s %(levelname)s %(message)s",encoding="utf-8")
    # Third-party HTTP debug lines may include credentials in URLs.
    for name in ("httpx","httpcore","openai"): logging.getLogger(name).setLevel(logging.WARNING)
    log = logging.getLogger("LiteratureAI.cli")
    log.info("command started: %s",args.command)
    pipeline = None
    try:
        if args.command == "doctor": emit(doctor()); return 0
        if args.command == "login":
            from literature_ai.download.browser import manual_login
            manual_login(args.url); return 0
        from literature_ai.pipeline import Pipeline
        from literature_ai.export.outputs import export_master
        pipeline = Pipeline()
        if args.command == "search":
            papers = pipeline.search(args.keyword,args.start_year,args.end_year,args.max_results,args.journal,args.oa_only,args.download,args.analyze)
            result = {**results_summary(papers),"sources":pipeline.sources.statuses,"excel":export_master(pipeline.store)}
        elif args.command in ("download","retry-download","analyze"):
            papers = process_papers(pipeline,args.command,getattr(args,"pending",False),getattr(args,"doi","") or "",getattr(args,"all_papers",False))
            result = {**results_summary(papers),"excel":export_master(pipeline.store)}
        elif args.command == "export": result = {"excel":export_master(pipeline.store)}
        elif args.command == 'batches':
            from literature_ai.batches import list_batches
            result={'batches':list_batches(pipeline.store)}
        elif args.command == 'reading-report':
            from literature_ai.batches import get_batch,finish_batch
            from literature_ai.reports.reading import reading_report
            result=finish_batch(pipeline.store,get_batch(pipeline.store,args.batch)) if args.batch else reading_report(pipeline.store,doi=args.doi)
        elif args.command == "weekly-report":
            from literature_ai.reports.weekly import weekly_report
            result = weekly_report(pipeline,send_email=args.send_email,refresh=not args.no_refresh)
        elif args.command == "resend-weekly-report":
            from literature_ai.reports.weekly import resend
            result = resend(pipeline.store)
        elif args.command == "test-email":
            from literature_ai.email.smtp import send_message
            result = send_message("LiteratureAI SMTP测试邮件","这是一封LiteratureAI配置测试邮件。",store=pipeline.store,require_attachments=False)
        elif args.command == "session-download":
            from literature_ai.utils.common import normalize_doi
            from literature_ai.download.browser import download_session
            from literature_ai.parser.pdf import parse_paper
            papers = [p for p in pipeline.store.papers() if normalize_doi(p.get("DOI")) == normalize_doi(args.doi)]
            if not papers: raise ValueError("DOI不在知识库中；请先检索该文献")
            data = download_session(args.url)
            paper = pipeline.downloader.save(papers[0],data,args.url,"user-authorized browser session")
            paper = parse_paper(paper,pipeline.store)
            result = {**results_summary([paper]),"excel":export_master(pipeline.store)}
        emit(result)
        log.info("command finished: %s",args.command)
        if result.get("email_status") == "configuration_required":
            print("Email configuration required：请填写 " + str(settings.root / ".env") + "；本地报告已保留。")
            return 0
        if result.get("email_status") == "failed":
            return 2
        if result.get("status") in ("failed","partial"): return 1
        return 0
    except Exception as exc:
        if isinstance(exc,RuntimeError) and str(exc)=="Weekly report already running":
            emit({"status":"skipped","reason":"weekly_report_already_running"})
            return 0
        # No exception URL, credential, login input or traceback is persisted.
        log.error("command failed: %s",type(exc).__name__)
        emit({"status":"FAILED","reason":type(exc).__name__,"log":str(logpath)})
        return 1
    finally:
        if pipeline is not None: pipeline.close()


if __name__ == "__main__": raise SystemExit(app())
