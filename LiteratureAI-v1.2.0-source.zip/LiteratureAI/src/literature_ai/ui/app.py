"""Local-only Streamlit dashboard for a single trusted Windows user."""
import os
from datetime import datetime
from pathlib import Path
from urllib.parse import urlparse
import streamlit as st

from literature_ai.config import settings,openai_key_available
from literature_ai.pipeline import Pipeline
from literature_ai.cli import task_status, process_papers
from literature_ai.export.outputs import export_master, write_note, missing_information
from literature_ai.reports.weekly import weekly_report, resend

st.set_page_config(page_title="LiteratureAI 文献知识库",page_icon="📚",layout="wide")
st.title("LiteratureAI 文献知识库")
st.caption("本机地址 127.0.0.1 · 数据与文件保存在 " + str(settings.root))


def open_local(path):
    target = Path(path).resolve()
    root = settings.root.resolve()
    if not target.is_relative_to(root) or not target.exists():
        st.error("文件不存在或不在LiteratureAI目录中")
        return
    if os.name == "nt": os.startfile(str(target))
    else: st.info(str(target))


def safe_action(function):
    try:
        with st.spinner("处理中；联网检索与全文分析可能需要数分钟"):
            value = function()
        if isinstance(value,dict) and (value.get("status") in {"failed","partial"} or value.get("email_status") in {"failed","configuration_required"}):
            st.warning("操作已结束；报告或邮件仍有未完成项，请查看结果状态。")
        else:
            st.info("操作已结束，请查看结果及文献状态。")
        return value
    except Exception as exc:
        st.error("操作失败：" + type(exc).__name__ + "。请查看 logs 与数据库状态。")
        return None


pipeline = Pipeline()
try:
    search_tab, library_tab, weekly_tab, config_tab = st.tabs(["检索","知识库","Weekly Report","配置与登录"])
    with search_tab:
        keyword = st.text_input("科研关键词",value="cellular senescence immune clearance",help="支持较宽泛的英文/中文主题；确定性规则扩展同义词并保留蛋白和疾病限定")
        columns = st.columns(4)
        start = columns[0].number_input("From",1800,2200,2021)
        end = columns[1].number_input("To",1800,2200,datetime.now().year)
        maximum = columns[2].number_input("最大结果数",1,1000,100)
        oa = columns[3].checkbox("Open Access only")
        journal = st.text_input("期刊筛选（可选）")
        from literature_ai.search.expansion import expand
        if keyword.strip():
            with st.expander("查看扩展关键词与布尔检索式"):
                expansion = expand(keyword)
                st.write(expansion["keywords"])
                st.code(expansion["boolean_query"],language=None)
        actions = st.columns(3)
        pressed = [actions[0].button("Search",width="stretch"),actions[1].button("Search + Download",width="stretch"),actions[2].button("Search + Download + Analyze",width="stretch")]
        if any(pressed):
            action = pressed.index(True)
            result = safe_action(lambda:pipeline.search(keyword,int(start),int(end),int(maximum),journal,oa,action>=1,action>=2))
            if result is not None:
                st.session_state["search_ids"] = [p["id"] for p in result]
                st.session_state["source_status"] = dict(pipeline.sources.statuses)
                safe_action(lambda:export_master(pipeline.store))
                st.info(f"本次检索 {len(result)} 篇。多源结果先合并去重，再按最大结果数保存到知识库。")
                if pipeline.last_batch:
                    st.session_state['last_batch_folder']=pipeline.last_batch['folder']
        if st.session_state.get('last_batch_folder'):
            st.info('本次调研文件夹：'+st.session_state['last_batch_folder'])
        if st.session_state.get("source_status"):
            st.json(st.session_state["source_status"])
        papers = pipeline.store.papers()
        result_ids = st.session_state.get("search_ids",[])
        selected = [p for p in papers if p["id"] in result_ids]
        st.dataframe([{k:p.get(k,"") for k in ("id","Title","Year","Journal","DOI","download_status","analysis_status")} for p in selected],width="stretch",hide_index=True)
        if not openai_key_available():
            st.info("OpenAI API Key尚未配置。检索、下载、解析和导出可用；科研AI分析保留pending。")
    with library_tab:
        papers = pipeline.store.papers()
        st.metric("知识库文献数",len(papers))
        from literature_ai.batches import list_batches,get_batch,finish_batch
        batches=list_batches(pipeline.store)
        st.subheader('按日期和主题归档的调研')
        st.caption('每次调研单独建文件夹，PDF 与详细解读 Word 放在一起。同日同主题自动加序号；待解读文献单独列出。')
        if batches:
            selected_batch_id=st.selectbox('选择调研批次',[b['id'] for b in batches],format_func=lambda bid:Path(next(b['folder'] for b in batches if b['id']==bid)).name)
            current_batch=get_batch(pipeline.store,selected_batch_id)
            st.write('文件夹',current_batch['folder'])
            st.write(f'PDF：{current_batch.get("pdf_count",0)} 篇；已详细解读：{current_batch.get("detailed_count",0)} 篇；待解读：{current_batch.get("pending_count",0)} 篇。')
            left,right=st.columns(2)
            if left.button('打开本次调研文件夹'):open_local(current_batch['folder'])
            if right.button('更新本批次详细解读 Word'):
                updated=safe_action(lambda:finish_batch(pipeline.store,current_batch))
                if updated:current_batch=updated
            report_path=Path(current_batch['report_path']) if current_batch.get('report_path') else None
            if report_path and report_path.is_file():
                st.download_button('下载本批次详细解读 Word',report_path.read_bytes(),file_name=report_path.name,mime='application/vnd.openxmlformats-officedocument.wordprocessingml.document')
            st.dataframe([{k:b.get(k) for k in ('date','topic','pdf_count','detailed_count','pending_count','folder')} for b in batches],hide_index=True,width='stretch')
        else:st.info('新检索会自动创建日期和主题文件夹。')
        reading_reports = sorted((settings.root / "exports").glob("LiteratureAI_全文解读汇总_*.docx"),reverse=True)
        if reading_reports:
            latest_reading = reading_reports[0]
            st.subheader("历史汇总报告")
            st.caption("以前导出的汇总报告，范围以文内说明为准。当前调研的 PDF 和 Word 请从上方批次入口查看。")
            st.download_button("下载历史全文解读汇总 Word",latest_reading.read_bytes(),file_name=latest_reading.name,mime="application/vnd.openxmlformats-officedocument.wordprocessingml.document")
            if st.button("打开全文解读汇总 Word"): open_local(latest_reading)
        text_filter = st.text_input("按标题、DOI、期刊筛选")
        shown = [p for p in papers if text_filter.casefold() in " ".join(str(p.get(k,"")) for k in ("Title","DOI","Journal")).casefold()]
        st.dataframe([{"详细解读":"已解读" if p.get('Detailed_Reading_Status')=='reviewed' or p.get('analysis_status')=='complete' else '待解读',**{k:p.get(k,"") for k in ("id","Title","Year","Journal","DOI","download_status","parse_status","PDF_Local_Path")}} for p in shown],width="stretch",hide_index=True)
        actions = st.columns(4)
        if actions[0].button("Excel导出"):
            path = safe_action(lambda:export_master(pipeline.store))
            if path: st.info(path)
        if actions[1].button("下载待处理文献"): safe_action(lambda:process_papers(pipeline,"download",pending=True))
        if actions[2].button("重试失败下载"): safe_action(lambda:process_papers(pipeline,"retry-download"))
        if actions[3].button("打开PDF文件夹"): open_local(settings.root / "library/pdfs")
        excel = settings.root / "exports/literature_master.xlsx"
        if excel.exists(): st.download_button("下载Excel主表",excel.read_bytes(),file_name=excel.name)
        if shown:
            ids = [p["id"] for p in shown]
            paper_id = st.selectbox("选择文献查看详情",ids,format_func=lambda ident:next(p["Title"] for p in shown if p["id"]==ident))
            p = pipeline.store.get(paper_id)
            st.write(p.get("Abstract") or "数据库尚未提供摘要")
            links = st.columns(3)
            if links[0].button("打开PDF"):
                if p.get("PDF_Local_Path"): open_local(p["PDF_Local_Path"])
                else: st.info("本文尚无已下载PDF")
            if links[1].button("打开Markdown"):
                path = safe_action(lambda:write_note(p,pipeline.store))
                if path: open_local(path)
            if links[2].button("分析这篇全文"):
                if p.get("DOI"): safe_action(lambda:process_papers(pipeline,"analyze",doi=p["DOI"]))
                else:
                    from literature_ai.analysis.analyzer import analyze_paper
                    safe_action(lambda:analyze_paper(p,pipeline.store))
            with st.expander("基础信息、机制与原文证据"):
                st.json(p)
                st.dataframe([r for r in pipeline.store.rows("evidence") if r["paper_id"]==p["id"]],width="stretch")
    with weekly_tab:
        scheduled = task_status()
        st.write("Windows计划任务状态",scheduled.get("status"))
        st.write("Next Run（实际计划任务，本机时区）",scheduled.get("NextRun") or "未注册或无法读取")
        st.write("Last Run（实际计划任务）",scheduled.get("LastRun") or "无可读取记录")
        st.caption("普通用户任务使用Interactive登录方式：用户须登录；关机或错过时刻后尽快补跑，避免并发。")
        runs = pipeline.store.rows("weekly_runs")
        last = runs[-1] if runs else {}
        st.write("Last Report",last.get("report_path") or "尚未生成")
        st.write("Last Email Status",last.get("email_status") or "not_requested")
        metrics = st.columns(4)
        metrics[0].metric("New Papers",last.get("New_Papers",0))
        metrics[1].metric("Updated Papers",last.get("Updated_Historical_Papers",0))
        metrics[2].metric("Missing Records",sum(bool(missing_information(p,pipeline.store)) for p in pipeline.store.papers()))
        metrics[3].metric("Failed Downloads",sum(p.get("download_status")=="failed" for p in pipeline.store.papers()))
        send = st.checkbox("本次周报发送邮件",value=False,help="需先在.env配置SMTP；未配置仍生成本地报告")
        refresh = st.checkbox("生成前联网更新文献",value=True)
        controls = st.columns(3)
        if controls[0].button("Run Weekly Report Now"):
            report = safe_action(lambda:weekly_report(pipeline,send_email=send,refresh=refresh))
            if report: st.json(report)
        if controls[1].button("Resend Last Email"):
            result = safe_action(lambda:resend(pipeline.store))
            if result: st.json(result)
        if controls[2].button("Open Weekly Folder"): open_local(settings.root / "weekly_reports")
        folder = Path(last["report_path"]) if last.get("report_path") else None
        buttons = st.columns(2)
        for index, suffix, label in ((0,".xlsx","Open Last Excel"),(1,".docx","Open Last Word")):
            files = list(folder.glob("*"+suffix)) if folder and folder.exists() else []
            if buttons[index].button(label,disabled=not files): open_local(files[0])
            if files: buttons[index].download_button("下载最后"+("Excel" if index==0 else "Word"),files[0].read_bytes(),file_name=files[0].name,key="report-download-"+suffix)
        st.dataframe(runs,width="stretch",hide_index=True)
    with config_tab:
        st.write("OpenAI API", "已配置（尚未连接验证）" if openai_key_available() else "待配置")
        from literature_ai.email.smtp import configured, send_message
        st.write("SMTP", "已配置（尚未发送验证）" if configured() else "待配置")
        st.write("配置文件",str(settings.root / ".env"))
        st.caption("在本机文本编辑器填写.env后重启界面。此页不展示或存储授权码、密码与API Key。")
        if st.button("发送测试邮件"):
            result = safe_action(lambda:send_message("LiteratureAI SMTP测试邮件","LiteratureAI邮件配置测试。",store=pipeline.store,require_attachments=False))
            if result: st.json(result)
        url = st.text_input("出版社/机构正常登录页面URL",placeholder="https://publisher.example/login")
        if st.button("打开浏览器手动登录"):
            from literature_ai.download.browser import manual_login
            safe_action(lambda:manual_login(url))
        st.caption("由本人输入账号、密码、验证码与双因素认证；关闭浏览器完成。会话保存在browser_profile，不导出Cookie。")
        doi = st.text_input("已收录文献DOI")
        pdf_url = st.text_input("登录后可正常访问的PDF链接")
        if st.button("使用本人会话下载此PDF"):
            from literature_ai.download.browser import download_session
            from literature_ai.parser.pdf import parse_paper
            from literature_ai.utils.common import normalize_doi
            def session_fetch():
                matched = [p for p in pipeline.store.papers() if normalize_doi(p.get("DOI"))==normalize_doi(doi)]
                if not matched or not doi: raise ValueError("DOI must identify a library paper")
                if urlparse(pdf_url).scheme not in {"http","https"}: raise ValueError("Normal PDF URL required")
                body = download_session(pdf_url)
                p = pipeline.downloader.save(matched[0],body,pdf_url,"user-authorized browser session")
                return parse_paper(p,pipeline.store)
            p = safe_action(session_fetch)
            if p: st.write(p.get("PDF_Local_Path"))
finally:
    pipeline.close()
