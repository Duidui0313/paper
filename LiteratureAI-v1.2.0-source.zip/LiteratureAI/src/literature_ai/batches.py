"""Research-run folders and membership; PDFs can be reused across runs."""
import hashlib
import json
import shutil
import csv
import io
from datetime import datetime
from pathlib import Path
from uuid import uuid4

from literature_ai.config import settings
from literature_ai.utils.common import now, safe_name, atomic_text, dumps, TZ


def ensure_schema(store):
    store.conn.executescript('''
    CREATE TABLE IF NOT EXISTS research_batches(
      id TEXT PRIMARY KEY, topic TEXT NOT NULL, folder TEXT NOT NULL UNIQUE,
      created_at TEXT NOT NULL, status TEXT NOT NULL, payload TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS research_batch_papers(
      batch_id TEXT NOT NULL REFERENCES research_batches(id),
      paper_id INTEGER NOT NULL REFERENCES papers(id), pdf_path TEXT,
      PRIMARY KEY(batch_id,paper_id));
    ''')
    store.conn.commit()


def create_batch(store, topic, date=None, provenance='new_research_run'):
    ensure_schema(store)
    date = date or datetime.now(TZ).date().isoformat()
    datetime.strptime(date, '%Y-%m-%d')
    base = settings.root / 'research'
    base.mkdir(parents=True, exist_ok=True)
    name = date + '_' + safe_name(topic, 48)
    n = 1
    while True:
        folder = base / (name if n == 1 else f'{name}_{n:02d}')
        try:
            folder.mkdir()
            break
        except FileExistsError:
            n += 1
    batch = {'id': uuid4().hex, 'topic': topic, 'folder': str(folder.resolve()),
             'date': date, 'created_at': now(), 'status': 'running', 'provenance': provenance}
    with store.conn:
        store.conn.execute('INSERT INTO research_batches VALUES(?,?,?,?,?,?)',
                           (batch['id'], topic, batch['folder'], batch['created_at'], 'running', dumps(batch)))
    write_manifest(store, batch)
    return batch


def get_batch(store, batch_id):
    ensure_schema(store)
    row = store.conn.execute('SELECT payload FROM research_batches WHERE id=?', (batch_id,)).fetchone()
    if not row:
        raise ValueError('Unknown research batch')
    return json.loads(row[0])


def list_batches(store):
    ensure_schema(store)
    return [json.loads(r[0]) for r in store.conn.execute('SELECT payload FROM research_batches ORDER BY created_at DESC,rowid DESC')]


def pdf_target(batch, paper):
    folder = Path(batch['folder']).resolve()
    allowed = (settings.root / 'research').resolve()
    if not folder.is_relative_to(allowed):
        raise ValueError('Batch folder outside research root')
    return folder / (f'R{paper["id"]:05d}_' + safe_name(paper['Title'], 100) + '.pdf')


def add_paper(store, batch, paper):
    path = ''
    source = Path(paper['PDF_Local_Path']) if paper.get('PDF_Local_Path') else None
    if source and source.is_file():
        target = pdf_target(batch, paper)
        if source.resolve() != target.resolve():
            data_hash = hashlib.sha256(source.read_bytes()).digest()
            if not target.exists():
                temp = target.with_suffix('.pdf.part')
                shutil.copy2(source, temp)
                if hashlib.sha256(temp.read_bytes()).digest() != data_hash:
                    raise IOError('Archive copy checksum mismatch')
                temp.replace(target)
            elif hashlib.sha256(target.read_bytes()).digest() != data_hash:
                raise IOError('Existing batch PDF has different content')
        path = str(target)
    with store.conn:
        store.conn.execute('INSERT INTO research_batch_papers VALUES(?,?,?) ON CONFLICT(batch_id,paper_id) DO UPDATE SET pdf_path=excluded.pdf_path',
                           (batch['id'], paper['id'], path))
    write_manifest(store, batch)
    return path


def batch_papers(store, batch):
    papers = []
    for pid, path in store.conn.execute('SELECT paper_id,pdf_path FROM research_batch_papers WHERE batch_id=? ORDER BY paper_id', (batch['id'],)):
        p = store.get(pid)
        if p:
            if path:
                p['PDF_Local_Path'] = path
            papers.append(p)
    return papers


def write_manifest(store, batch):
    papers = batch_papers(store, batch)
    content = {**batch, 'papers': [{k:p.get(k) for k in ('id','Title','DOI','PDF_Local_Path','download_status','analysis_status','PDF_Downloaded_At')} for p in papers]}
    atomic_text(Path(batch['folder']) / '批次清单.json', dumps(content))
    table = io.StringIO()
    writer = csv.writer(table)
    writer.writerow(['文献编号','标题','DOI','PDF文件','下载状态','详细解读状态'])
    for p in papers:
        state = '已详细解读' if p['id'] in batch.get('detailed_paper_ids',[]) or p.get('Detailed_Reading_Status') == 'reviewed' or p.get('analysis_status') == 'complete' else '待解读'
        values = [p['id'],p['Title'],p.get('DOI',''),Path(p['PDF_Local_Path']).name if p.get('PDF_Local_Path') else '',p.get('download_status',''),state]
        writer.writerow(["'"+v if isinstance(v,str) and v.startswith(('=','+','-','@')) else v for v in values])
    atomic_text(Path(batch['folder']) / '文献清单.csv', '\ufeff'+table.getvalue())


def finish_batch(store, batch, generate_report=True, status='complete'):
    batch = dict(batch)
    batch.update(status=status, updated_at=now())
    papers = batch_papers(store, batch)
    batch['paper_count'] = len(papers)
    batch['pdf_count'] = sum(bool(p.get('PDF_Local_Path')) and Path(p['PDF_Local_Path']).is_file() for p in papers)
    if generate_report and papers:
        from literature_ai.reports.reading import reading_report
        result = reading_report(store, batch=batch)
        batch.update(report_path=result['file'], detailed_count=result['analysed'], pending_count=result['pending'],detailed_paper_ids=result['detailed_paper_ids'])
    with store.conn:
        store.conn.execute('UPDATE research_batches SET status=?,payload=? WHERE id=?', (status, dumps(batch), batch['id']))
    write_manifest(store, batch)
    return batch
