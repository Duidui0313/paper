# LiteratureAI

本地科研文献检索、合法全文获取、PDF 解析、可追溯的中文解读，以及 Excel / Word 报告工具。

**Windows 优先 · Python 3.11+ · 本地 SQLite · Streamlit 界面**

输入研究主题 → 多源检索与去重 → 获取可访问的 PDF → 按页解析 → AI 结构化解读与引文核验 → 知识库、全文解读 Word 和周报。

## 可以做什么

- 查询 PubMed、Europe PMC、Crossref、OpenAlex；Semantic Scholar 和 Unpaywall 按配置参与检索或补充。
- 合并 DOI 和元数据，记录检索词、来源、下载状态和缺失信息。
- 下载正常可访问的全文；验证 PDF 文件格式，保留无法获取全文的原因。
- 按页解析文本；扫描件标记需要 OCR，当前不自动 OCR。
- 用配置的 OpenAI API 提取研究问题、设计、模型、方法、结果、机制、通路、蛋白、酶、创新和局限。
- 核对事实对应的 PDF 页码与原文短引文，区分表达、活性、定位及系统推断。
- 生成 Excel 主表、逐篇 Markdown 笔记、**全部文献的全文解读汇总 Word**和按周期统计的 Word / Excel 周报。
- 可选配置 SMTP 与 Windows 每周计划任务。

此仓库是通用工具，不附带作者本地的论文、密钥、邮箱、数据库、登录会话或那份人工整理的 28 页研究报告。自动输出基于实际 API 结果，与人工精读的深度和语言组织可能不同。缺少 API 配置时只完成检索、下载、解析和状态导出，不会凭空生成解读。

## 快速开始：Windows

1. 安装 Python 3.11 或更新版本；安装时启用 Python 启动器或将 Python 加入 PATH。
2. 下载仓库 ZIP 并解压，或克隆仓库。项目可以放在有写权限的任意目录，不要求 D 盘。
3. 在项目目录打开 PowerShell：

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\install.ps1 -SkipBrowser
```

如有多个 Python，可指定解释器：

```powershell
.\install.ps1 -PythonPath 'C:\Path\To\Python\python.exe' -SkipBrowser
```

安装脚本创建项目内 `.venv`、运行数据目录及 `.env`，保留已有配置。需要本人登录出版社浏览器时去掉 `-SkipBrowser`。安装依赖需要联网。

4. 用本机文本编辑器填写 `.env`：

```dotenv
CONTACT_EMAIL=
OPENAI_API_KEY=
OPENAI_MODEL=gpt-4.1-mini
```

`CONTACT_EMAIL` 填自己的联系邮箱；部分元数据服务需要它。模型需支持当前代码使用的结构化输出，具体可用性取决于 API 账户。全文分析会把解析文本发送至配置的 API，并产生账户费用。

5. 双击 `start_literature_ai.bat`，访问本机 `http://127.0.0.1:8501`。首次打开页面若服务仍在启动，稍后刷新。
6. 在“检索”页填写主题，运行“Search + Download + Analyze”；在“知识库”页选择调研批次，下载本批次详细解读 Word。

## 每次调研单独归档

每次检索都会新建 `research/日期_主题/`，PDF、详细解读 Word、文献清单和批次记录放在同一目录。同一天相同主题再次检索时，自动使用 `_02`、`_03`，不覆盖旧批次。

```text
research/
  2026-10-04_细胞衰老/
    R00001_文章标题.pdf
    2026-10-04_细胞衰老_详细解读.docx
    文献清单.csv
    批次清单.json
  2026-10-04_细胞衰老_02/
```

重复找到的已下载文献会复制到当前批次，保证每个批次可独立查看。需要额外磁盘空间。当天不同主题各有自己的目录；补充下载按所属主题建新批次。日期采用 Asia/Shanghai 的批次启动日期。

已完成分析的文章呈现详细内容；未完成的单独列为待解读。没有任何详细解读时，Word 明确命名为“待解读清单”。缺少有效 AI 配置不会把待解读自动标为完成。每次更新报告保留旧版本。

```powershell
.\.venv\Scripts\python.exe -m literature_ai batches
.\.venv\Scripts\python.exe -m literature_ai reading-report --batch 批次ID
```

默认 `reading-report` 仍可导出全库汇总到 `exports/`；按批次输出请指定 `--batch` 或使用界面批次按钮。

## 命令行示例

直接在项目目录运行，不必激活虚拟环境：

```powershell
$env:LITERATUREAI_HOME = (Get-Location).Path
.\.venv\Scripts\python.exe -m literature_ai search "cellular senescence immune clearance" --from 2021 --to 2026 --max 30 --download --analyze
.\.venv\Scripts\python.exe -m literature_ai reading-report
.\.venv\Scripts\python.exe -m literature_ai reading-report --doi "10.xxxx/example"
.\.venv\Scripts\python.exe -m literature_ai export
.\.venv\Scripts\python.exe -m literature_ai doctor
```

其他方向可以直接替换英文主题，例如 `mitochondrial quality control in Parkinson disease`。现有同义词规则主要针对衰老及相关生命科学主题；其他方向建议使用明确英文词和领域同义词，不承诺自动覆盖所有学科。

`reading-report` 导出当前知识库的全部文章，不受周报时间窗口或 10 篇精选限制。每篇按字段整理详细内容并附证据；未分析文章明确标为待完成。重复生成保留旧版本。

### 不同方向分别存储

每个 `LITERATUREAI_HOME` 对应一个独立知识库。可为新方向设置新的数据目录，并复制 `.env.example` 为该目录的 `.env`，分别填写凭据。该目录外部的内容不受本仓库 `.gitignore` 保护，不要将数据目录公开上传。

```powershell
$env:LITERATUREAI_HOME = Join-Path $env:USERPROFILE 'LiteratureAI_Data\mitochondria'
New-Item -ItemType Directory -Force $env:LITERATUREAI_HOME | Out-Null
Copy-Item .env.example (Join-Path $env:LITERATUREAI_HOME '.env')
# 编辑新目录中的 .env，再运行检索或界面
.\.venv\Scripts\python.exe -m literature_ai ui --port 8502
```

BAT 启动器固定使用自身目录为数据根目录；使用独立方向目录时请用上面的命令行方式。环境变量未设置时，Python 命令默认使用当前目录下 `LiteratureAI_Data/`。配置修改后重启进程。

## 输出在哪里

相对于 `LITERATUREAI_HOME`：

| 内容 | 路径 |
|---|---|
| 本次 PDF、解读 Word 与清单 | `research/<日期>_<主题>/` |
| 升级前 PDF（如有） | `library/pdfs/<年份>/` |
| 按页全文 JSON 与 Markdown 笔记 | `library/notes/` |
| SQLite 数据库 | `data/literature.db` |
| Excel 主表 | `exports/literature_master.xlsx` |
| 逐篇全文解读汇总 Word | `exports/LiteratureAI_全文解读汇总_*.docx` |
| Word / Excel 周报 | `weekly_reports/<年份>/<周次>/` |
| 保存的检索主题 | `config/saved_searches.json` |
| 日志 | `logs/` |

## 周报、邮件与计划任务

周报使用 Asia/Shanghai 的每周六 13:00 截止点。截止之后新增或完成分析的记录进入下一周期；查看当前所有解读请用 `reading-report`。

```powershell
.\.venv\Scripts\python.exe -m literature_ai weekly-report --no-refresh
.\.venv\Scripts\python.exe -m literature_ai weekly-report
```

带刷新运行会重新检索已保存主题、重试下载和分析。新建空库没有保存主题时不自动替你选研究方向。周报精选正文最多展示 10 篇；完整逐篇报告请另行运行 `reading-report`。

邮件是可选功能，必须自己填写 `.env` 中的 `SMTP_HOST`、`SMTP_USER`、`SMTP_AUTH_CODE`、`EMAIL_FROM` 和 `EMAIL_RECIPIENT`。不存在预置的个人收件人。

```powershell
# 下面命令会真正发送邮件，请先确认收件人
.\.venv\Scripts\python.exe -m literature_ai test-email
.\.venv\Scripts\python.exe -m literature_ai weekly-report --send-email
.\.venv\Scripts\python.exe -m literature_ai resend-weekly-report
```

Windows 下可显式运行 `setup_weekly_task.ps1` 注册“LiteratureAI Weekly Report”。它每周六本机时间 13:00 运行 `run_weekly_report.bat`，生成周报并尝试邮件发送。需要当前用户登录，机器开机且有网络；请让系统时区与报告时区一致。该名称为单个共享任务，重复注册会更新原任务，不是多方向多任务管理器。安装脚本不会自动注册它。

## 全文权限与分析边界

只使用开放获取、正常可访问的出版社链接或本人授权登录会话。遇到付费、验证码、访问限制会记录状态。下载成功不等于获得公开再分发论文的权利，分享仓库时不要附带论文全文。

```powershell
.\.venv\Scripts\python.exe -m literature_ai login "https://publisher.example.org/"
.\.venv\Scripts\python.exe -m literature_ai session-download "https://publisher.example.org/paper.pdf" --doi "10.xxxx/example"
```

以上为占位示例，请替换为真实正常页面；DOI 需已存在知识库。程序不破解验证码或付费墙。浏览器会话保存在本地 `browser_profile/`。

引文匹配验证的是“该页有这段原文”，不能证明解读一定正确，也不能代替系统综述的纳排标准或人工科学审查。双栏排版、复杂公式和图片可能解析不完整；当前不自动提取实验图并解读，也未实现本地模型提供者。`Not explicitly reported` 表示当前未有明确支持信息。

## 开发与测试

```powershell
$env:LITERATUREAI_HOME = Join-Path (Get-Location) 'LiteratureAI_Data'
.\.venv\Scripts\python.exe -m pip install -e '.[dev]'
.\.venv\Scripts\python.exe -m pytest -q
.\.venv\Scripts\python.exe -m build
```

核心测试使用合成数据和模拟服务，不发邮件、不要求 API 密钥。测试包含批次隔离、同名编号、PDF 复用、报告范围和证据校验；其他操作系统未做端到端验证。任务注册和 BAT 启动器为 Windows 专用。

`requirements-tested.txt` 是开发环境依赖版本快照，可作为复现约束；常规安装从 `pyproject.toml` 解析依赖。它不是所有操作系统的通用锁文件。

## 上传与下载

操作步骤见 [GitHub 分享指南](docs/GITHUB_SHARING.md)。仓库带有源码打包工具与自动测试工作流。仓库首页 **Code → Download ZIP** 可下载源码；也可手动将生成的 ZIP 上传到 GitHub Releases。

只上传本项目目录。不要上传原来的本地部署目录、`.env`、论文、报告、数据库或浏览器配置。

## 许可证

本项目自行编写的源码使用 [MIT License](LICENSE)。第三方依赖遵循各自许可证，见 [依赖说明](THIRD_PARTY_NOTICES.md)。论文及元数据不属于本项目源码许可范围。
