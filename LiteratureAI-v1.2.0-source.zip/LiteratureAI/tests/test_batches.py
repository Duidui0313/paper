import hashlib
import json
from pathlib import Path
from types import SimpleNamespace

import pytest
from docx import Document

from literature_ai.config import settings
from literature_ai.database.store import Store
from literature_ai.batches import create_batch,add_paper,finish_batch,batch_papers,list_batches
from literature_ai.reports.reading import reviewed_note


@pytest.fixture
def library(tmp_path,monkeypatch):
    monkeypatch.setattr(settings,'root',tmp_path)
    store=Store(tmp_path/'data/library.db')
    yield store,tmp_path
    store.close()


def test_separate_runs_and_reused_pdf_are_self_contained(library):
    store,root=library
    original=root/'old.pdf'; original.write_bytes(b'%PDF-synthetic-bytes-for-copy-test')
    paper=store.upsert({'Title':'One paper','DOI':'10.1000/one','PDF_Local_Path':str(original),'download_status':'downloaded'})
    first=create_batch(store,'主题:/一',date='2026-10-04')
    second=create_batch(store,'主题:/一',date='2026-10-04')
    third=create_batch(store,'主题:/一',date='2026-10-05')
    assert first['folder']!=second['folder'] and second['folder'].endswith('_02')
    assert Path(third['folder']).name.startswith('2026-10-05_')
    a=Path(add_paper(store,first,paper)); b=Path(add_paper(store,second,paper))
    assert a.parent==Path(first['folder']) and b.parent==Path(second['folder'])
    assert original.read_bytes()==a.read_bytes()==b.read_bytes()
    add_paper(store,first,paper)
    assert len(batch_papers(store,first))==1
    result=finish_batch(store,first)
    assert Path(result['report_path']).parent==a.parent
    assert result['detailed_count']==0 and result['pending_count']==1
    assert '待解读文献清单' in '\n'.join(p.text for p in Document(result['report_path']).paragraphs)
    assert len(list_batches(store))==3


def test_reviewed_reading_requires_hash_and_page_evidence(library):
    store,root=library
    pdf=root/'paper.pdf';pdf.write_bytes(b'synthetic PDF bytes')
    full=root/'full.json';full.write_text(json.dumps({'pages':[{'page':1,'text':'The protein activity increased.'}]}))
    p=store.upsert({'Title':'A reviewed paper','DOI':'10.1000/review','PDF_Local_Path':str(pdf),'Fulltext_Path':str(full)})
    folder=root/'library/notes/reviewed_test';folder.mkdir(parents=True)
    note={'pdf_sha256':hashlib.sha256(pdf.read_bytes()).hexdigest(),'metadata':{'DOI':p['DOI']},'evidence':[[1,'Results','protein activity increased']]}
    target=folder/f'{p["id"]}_reading.json'; target.write_text(json.dumps(note))
    assert reviewed_note(p)
    note['evidence'][0][0]=2;target.write_text(json.dumps(note))
    assert reviewed_note(p) is None
    note['evidence'][0][0]=1;target.write_text(json.dumps(note))
    pdf.write_bytes(b'changed source')
    assert reviewed_note(p) is None


def test_search_creates_new_batch_even_when_results_repeat(library,monkeypatch):
    from literature_ai.pipeline import Pipeline
    store,root=library
    (root/'config').mkdir();(root/'library/notes').mkdir(parents=True)
    pipe=Pipeline(store)
    class Sources:
        statuses={}
        def search(self,*args):
            return [{'Title':'cellular senescence study','DOI':'10.1000/search','Year':2025,'Abstract':'senescence'}]
    pipe.sources=Sources()
    pipe.search('senescence',max_results=1,persist=False)
    first=pipe.last_batch
    pipe.search('senescence',max_results=1,persist=False)
    assert len(store.papers())==1
    assert pipe.last_batch['id']!=first['id']
    assert len(batch_papers(store,first))==1
    pipe.net.close()


def test_direct_download_creates_dated_folder_and_report(library):
    from literature_ai.download.downloader import Downloader
    store,root=library
    (root/'downloads_tmp').mkdir()
    paper=store.upsert({'Title':'A downloaded paper','DOI':'10.1000/download','Original_Search_Query':'New topic'})
    result=Downloader(None,store,None).save(paper,b'%PDF-test-fixture','https://example.org/article.pdf','test')
    batches=list_batches(store)
    assert len(batches)==1
    assert Path(result['PDF_Local_Path']).parent==Path(batches[0]['folder'])
    assert Path(batches[0]['report_path']).is_file()
    assert batches[0]['pdf_count']==1 and batches[0]['pending_count']==1
