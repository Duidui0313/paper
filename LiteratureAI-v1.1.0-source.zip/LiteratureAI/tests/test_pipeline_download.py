from pathlib import Path
from types import SimpleNamespace
import fitz
from literature_ai.database.store import Store
from literature_ai.pipeline import Pipeline
from literature_ai.download.downloader import valid_pdf,Downloader
from literature_ai.utils.network import Network,NetworkError
import httpx
import pytest

def test_search_max_deduplicates_before_saving(tmp_path,monkeypatch):
    import literature_ai.pipeline as module
    monkeypatch.setattr(module,"write_note",lambda *args:None)
    db=Store(tmp_path / "db.sqlite")
    pipe=Pipeline(db)
    class FakeSources:
        statuses={}
        def search(self,*args):
            return [{"Title":f"Senescence immune clearance {i}","DOI":f"10.9999/{i}","Year":2025,"Abstract":"cellular senescence immune clearance"} for i in range(5)]
    pipe.sources=FakeSources()
    assert len(pipe.search("senescence immune clearance",max_results=2,persist=False))==2
    assert len(db.papers())==2
    assert len(pipe.search("senescence immune clearance",max_results=2,persist=False))==2
    assert len(db.papers())==2
    pipe.close()

def test_pdf_checks_reject_html_and_corrupt_file():
    assert not valid_pdf(b"<html>login required</html>"*200,"application/pdf")
    assert not valid_pdf(b"%PDFgarbage"*200,"application/pdf")
    doc=fitz.open()
    for i in range(3):
        page=doc.new_page(); page.insert_text((72,72),"Research article page "+str(i))
    data=doc.tobytes(); doc.close()
    assert valid_pdf(data,"binary/octet-stream")
    assert not valid_pdf(data,"text/html")

def test_403_is_not_retried(monkeypatch):
    calls=[]
    def request(req): calls.append(req); return httpx.Response(403,text="denied")
    net=Network(transport=httpx.MockTransport(request)); monkeypatch.setattr(net,"wait",lambda url:None)
    with pytest.raises(NetworkError,match="publisher_blocked"): net.get("https://example.org/paper")
    assert len(calls)==1
    net.close()

def test_html_captcha_detection():
    assert Downloader.html_reason("Please verify you are human") == "captcha"
    assert Downloader.html_reason("Sign in to access full text") == "login_required"

def test_gzip_response_is_decoded_once(monkeypatch):
    import gzip
    def request(req): return httpx.Response(200,headers={"content-encoding":"gzip","content-type":"application/json"},content=gzip.compress(b'{"ok":true}'))
    net=Network(transport=httpx.MockTransport(request)); monkeypatch.setattr(net,"wait",lambda url:None)
    assert net.get("https://example.org/api").json()=={"ok":True}
    net.close()


def test_weekly_cli_skips_when_another_report_is_running(tmp_path,monkeypatch,capsys):
    import literature_ai.config as config
    import literature_ai.pipeline as pipeline_module
    import literature_ai.reports.weekly as weekly_module
    from literature_ai.cli import app
    closed=[]
    monkeypatch.setattr(config,"settings",SimpleNamespace(root=tmp_path))
    monkeypatch.setattr(pipeline_module,"Pipeline",lambda:SimpleNamespace(close=lambda:closed.append(True)))
    def locked(*args,**kwargs):
        raise RuntimeError("Weekly report already running")
    monkeypatch.setattr(weekly_module,"weekly_report",locked)
    assert app(["weekly-report","--no-refresh"])==0
    assert 'weekly_report_already_running' in capsys.readouterr().out
    assert closed==[True]
