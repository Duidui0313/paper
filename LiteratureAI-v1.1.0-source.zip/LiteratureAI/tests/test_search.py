from types import SimpleNamespace

import pytest

from literature_ai.search.expansion import expand
from literature_ai.search.sources import Sources, crossref_record, europe_record, openalex_record, pubmed_xml, semantic_record


class Response:
    def __init__(self, data=None, text=""):
        self.data, self.text = data, text
    def json(self):
        return self.data


class Net:
    def __init__(self, *responses):
        self.responses, self.calls = list(responses), []
    def get(self, url, params=None, **kwargs):
        self.calls.append((url, params, kwargs))
        response = self.responses.pop(0)
        if isinstance(response, Exception): raise response
        return response


def settings(**values):
    return SimpleNamespace(**{"contact_email":"research@example.org", "openalex_api_key":"", "s2_api_key":"", **values})


XML = '''<PubmedArticleSet><PubmedArticle><MedlineCitation><PMID>123</PMID><Article>
<Journal><Title>Journal of Senescence</Title><JournalIssue><Volume>7</Volume><Issue>2</Issue><PubDate><Year>2025</Year><Month>Jan</Month></PubDate></JournalIssue></Journal>
<ArticleTitle>Immune <i>clearance</i> of senescent cells</ArticleTitle><AuthorList><Author><LastName>Smith</LastName><ForeName>Jane</ForeName></Author><Author><CollectiveName>Research Consortium</CollectiveName></Author></AuthorList>
<Pagination><MedlinePgn>12-19</MedlinePgn></Pagination><Abstract><AbstractText Label="RESULTS">Protein expression <b>declined</b>.</AbstractText><AbstractText Label="CONCLUSION">Activity was not tested.</AbstractText></Abstract>
<ELocationID EIdType="doi">10.1000/EXAMPLE</ELocationID></Article><KeywordList><Keyword>senescence</Keyword></KeywordList></MedlineCitation>
<PubmedData><ArticleIdList><ArticleId IdType="doi">10.1000/EXAMPLE</ArticleId><ArticleId IdType="pmc">PMC987</ArticleId></ArticleIdList></PubmedData></PubmedArticle></PubmedArticleSet>'''


def test_expansion_covers_user_example():
    result = expand("senescent cell immune clearance")
    assert {"cellular senescence", "immune surveillance", "immune evasion", "NK cell senescence", "persistent senescence"}.issubset(result["keywords"])
    assert " AND " in result["boolean_query"] and " OR " in result["boolean_query"]
    assert result["queries"][0] == "senescent cell immune clearance"


def test_expansion_translation_and_specific_modifier():
    result = expand("皮肤衰老免疫清除")
    assert "skin aging immune clearance" in result["keywords"]
    assert '"skin"' in result["boolean_query"]


def test_expansion_preserves_explicit_query():
    query = "senescence[Title] AND p53"
    assert expand(query)["boolean_query"] == query
    with pytest.raises(ValueError): expand("   ")


def test_expansion_keeps_specific_unknown_protein():
    assert '"TFEB"' in expand("TFEB cellular senescence immune clearance")["boolean_query"]
    assert '"p53"' in expand("p53 cellular senescence")["boolean_query"]


def test_pubmed_xml_preserves_abstract_markup_and_identifier():
    p = pubmed_xml(XML)[0]
    assert p["Title"] == "Immune clearance of senescent cells"
    assert p["DOI"] == "10.1000/example"
    assert p["Authors"] == ["Jane Smith", "Research Consortium"]
    assert p["Publication_Date"] == "2025-01"
    assert "RESULTS: Protein expression declined." in p["Abstract"]
    assert "Activity was not tested." in p["Abstract"]
    assert p["PMCID"] == "PMC987"
    assert p["Open_Access"] is None  # PMCID alone is not OA evidence


def test_pubmed_xml_rejects_entities():
    with pytest.raises(ValueError): pubmed_xml('<!DOCTYPE a [<!ENTITY b "123">]><a>&b;</a>')


def test_pubmed_uses_efetch_xml_not_json():
    net = Net(Response({"esearchresult":{"idlist":["123"]}}), Response(text=XML))
    p = Sources(net, settings()).search("PubMed", "senescence", 2021, 2026, 10)[0]
    assert p["Abstract"]
    assert net.calls[1][0].endswith("efetch.fcgi")
    assert net.calls[1][1]["retmode"] == "xml"


def test_europe_core_oa_links_only():
    p = europe_record({"title":"A", "pubYear":"2024", "pmcid":"PMC1", "isOpenAccess":"N", "fullTextUrlList":{"fullTextUrl":[{"availability":"Subscription required", "documentStyle":"pdf", "url":"https://publisher.invalid/pay.pdf"}]}})
    assert p["PDF_URL"] == "" and p["Open_Access"] is False
    p = europe_record({"title":"A", "pubYear":"2024", "isOpenAccess":"Y", "fullTextUrlList":{"fullTextUrl":[{"availabilityCode":"OA", "documentStyle":"pdf", "url":"https://publisher.invalid/open.pdf"}]}})
    assert p["PDF_URL"].endswith("open.pdf") and p["Full_Text_Status"] == "open_pdf"


def test_europe_pagination_and_core():
    net = Net(Response({"resultList":{"result":[{"title":"A", "pubYear":"2024"}]}, "nextCursorMark":"cursor-2"}), Response({"resultList":{"result":[{"title":"B", "pubYear":"2024"}]}}))
    result = Sources(net, settings()).search("Europe PMC", "senescence", 2021, 2026, 2)
    assert len(result) == 2
    assert net.calls[0][1]["resultType"] == "core"
    assert net.calls[1][1]["cursorMark"] == "cursor-2"


def test_crossref_candidate_link_is_not_oa_proof():
    p = crossref_record({"title":["A"], "DOI":"https://doi.org/10.1/AbC", "subject":["Cell Biology"], "published":{"date-parts":[[2025, 3, 2]]}, "abstract":"<jats:p>Finding <jats:italic>one</jats:italic>.</jats:p>", "link":[{"URL":"https://publisher.invalid/paper.pdf"}]})
    assert p["DOI"] == "10.1/abc" and p["Year"] == 2025
    assert p["Abstract"] == "Finding one ."
    assert p["Author_Keywords"] == [] and p["Subject_Terms"] == ["Cell Biology"]
    assert p["PDF_URL"] == "" and p["Open_Access"] is None


def test_crossref_uses_earliest_publication_and_score_title_search():
    p = crossref_record({"title":["A"], "published":{"date-parts":[[2024]]}, "published-print":{"date-parts":[[2008, 3]]}})
    assert p["Year"] == 2008
    net = Net(Response({"message":{"items":[{"title":["A"], "published":{"date-parts":[[2024]]}}]}}))
    Sources(net, settings()).search("Crossref", "senescent cell immune clearance", 2021, 2026, 1)
    assert net.calls[0][1]["query.title"] == "senescent cell immune clearance"
    assert net.calls[0][1]["sort"] == "score" and net.calls[0][1]["order"] == "desc"


def test_openalex_reconstructs_abstract_and_corresponding():
    p = openalex_record({"title":"A", "doi":"https://doi.org/10.1/a", "publication_year":2024, "abstract_inverted_index":{"word":[1], "First":[0]}, "authorships":[{"author":{"display_name":"Ann"}, "is_corresponding":True}], "open_access":{"is_oa":True, "oa_status":"green"}, "best_oa_location":{"pdf_url":"https://repo.invalid/a.pdf"}, "keywords":[{"display_name":"senescence"}]})
    assert p["Abstract"] == "First word" and p["Corresponding_Author"] == "Ann"
    assert p["PDF_URL"].endswith("a.pdf") and p["Author_Keywords"] == []


def test_openalex_anonymous_current_api_and_page_size():
    net = Net(Response({"results":[{"title":"A", "publication_year":2024}]}))
    sources = Sources(net, settings())
    assert len(sources.search("OpenAlex", "senescence", 2021, 2026, 120)) == 1
    assert "api_key" not in net.calls[0][1]
    assert net.calls[0][1]["per_page"] == 100
    assert "anonymous" in sources.statuses["OpenAlex"]


def test_openalex_exhausted_anonymous_once():
    error = RuntimeError("URL must never be exposed")
    error.response = SimpleNamespace(status_code=409)
    net = Net(error)
    sources = Sources(net, settings())
    assert sources.search("OpenAlex", "senescence", 2021, 2026, 10) == []
    assert sources.search("OpenAlex", "senescence", 2021, 2026, 10) == []
    assert len(net.calls) == 1 and "configuration_required" in sources.statuses["OpenAlex"]


def test_unpaywall_enrichment_cache_and_doi_validation():
    net = Net(Response({"doi":"https://doi.org/10.1/a", "title":"A", "publication_year":2024}), Response({"doi":"10.1/a", "is_oa":True, "oa_status":"gold", "best_oa_location":{"url_for_pdf":"https://oa.invalid/a.pdf", "license":"cc-by"}}))
    sources = Sources(net, settings())
    p = sources.enrich({"DOI":"10.1/A", "Title":"Original", "Metadata_Source":["PubMed"]})
    assert p["Title"] == "Original" and p["PDF_URL"].endswith("a.pdf")
    assert p["OA_Evidence_Source"] == "Unpaywall" and "Unpaywall" in p["Metadata_Source"]
    assert p["Metadata_Provenance"]["PDF_URL"] == "Unpaywall"
    sources.enrich({"DOI":"10.1/a"})
    assert len(net.calls) == 2


def test_enrichment_wrong_doi_does_not_change_record():
    net = Net(Response({"doi":"10.1/other"}), Response({"doi":"10.1/other", "is_oa":True, "best_oa_location":{"url_for_pdf":"https://oa.invalid/wrong.pdf"}}))
    p = Sources(net, settings()).enrich({"DOI":"10.1/a", "Title":"Correct"})
    assert p["Title"] == "Correct" and not p.get("PDF_URL")
    assert p["Enrichment_Errors"] == {"OpenAlex":"ValueError", "Unpaywall":"ValueError"}


def test_semantic_arxiv_is_legal_pdf_fallback():
    p = semantic_record({"title":"A", "externalIds":{"ArXiv":"2601.00001", "DOI":"10.1/a"}})
    assert p["PDF_URL"] == "https://arxiv.org/pdf/2601.00001"
    assert p["Open_Access"] is True


def test_year_journal_and_oa_filter_do_not_silently_accept():
    net = Net(Response({"resultList":{"result":[{"title":"Old", "pubYear":"2020", "journalTitle":"Nature", "isOpenAccess":"Y"}, {"title":"Wrong", "pubYear":"2024", "journalTitle":"Other", "isOpenAccess":"Y"}, {"title":"Good", "pubYear":"2024", "journalTitle":"Nature", "isOpenAccess":"Y"}]}}))
    result = Sources(net, settings()).search("Europe PMC", "senescence", 2021, 2026, 10, journal="Nature", oa_only=True)
    assert [p["Title"] for p in result] == ["Good"]


def test_unpaywall_is_not_search_engine_and_bad_range_rejected():
    sources = Sources(Net(), settings())
    with pytest.raises(ValueError): sources.search("Unpaywall", "senescence", 2021, 2026, 10)
    with pytest.raises(ValueError): sources.search("PubMed", "senescence", 2026, 2021, 10)
