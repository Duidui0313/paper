import json
from datetime import datetime,timedelta
from pathlib import Path
from types import SimpleNamespace

import pytest
from docx import Document
from openpyxl import load_workbook

from literature_ai.database.store import Store
from literature_ai.utils.common import TZ,dumps,report_period
from literature_ai.reports import weekly
from literature_ai.reports.synthesis import synthesize
from literature_ai.export import outputs
from literature_ai.email import smtp


@pytest.fixture
def library(tmp_path,monkeypatch):
    monkeypatch.setattr(weekly.settings,"root",tmp_path)
    monkeypatch.delenv("OPENAI_API_KEY",raising=False)
    for name in ("SMTP_HOST","SMTP_USER","SMTP_AUTH_CODE"):
        monkeypatch.delenv(name,raising=False)
    store=Store(tmp_path / "data/literature.db")
    yield store,tmp_path
    store.close()


def put(store,title,created,**fields):
    p=store.upsert({"Title":title,"Year":2025,"DOI":"10.1000/"+title,"Abstract":"真实中文摘要",**fields})
    store.conn.execute("UPDATE papers SET created_at=?,updated_at=? WHERE id=?",(created.isoformat(),created.isoformat(),p["id"]))
    store.conn.commit()
    return store.get(p["id"])


def change(store,p,time,fields):
    store.conn.execute("INSERT INTO changes(paper_id,time,fields) VALUES(?,?,?)",(p["id"],time.isoformat(),dumps(fields)))
    store.conn.commit()


def test_period_saturday_cutoff_and_no_double_count():
    end=datetime(2026,10,3,13,tzinfo=TZ); start=end-timedelta(days=7)
    assert report_period(end)==(start,end)
    assert report_period(end-timedelta(seconds=1))[1]==start
    assert not weekly.within(start.isoformat(),start,end)
    assert weekly.within(end.isoformat(),start,end)
    assert not weekly.within(end.isoformat(),end,end+timedelta(days=7))
    assert not weekly.within("invalid",start,end)


def test_weekly_real_files_cutoff_history_and_versions(library,monkeypatch):
    store,root=library; end=datetime(2026,10,3,13,tzinfo=TZ); start=end-timedelta(days=7)
    monkeypatch.setattr(weekly,"report_period",lambda:(start,end))
    new=put(store,"本周新文献",end)
    history=put(store,"历史补充",start)
    checked=put(store,"仅检查",start-timedelta(days=1))
    put(store,"截止后新文献",end+timedelta(seconds=1))
    change(store,history,start+timedelta(hours=1),["Abstract"])
    change(store,checked,end,["last_checked_at","Missing_Information","Analysis_Pending_Reason","analysis_status"])
    for p,at in ((history,start-timedelta(seconds=1)),(history,end),(new,end)):
        store.conn.execute("INSERT INTO downloads(paper_id,time,status,payload) VALUES(?,?,?,?)",(p["id"],at.isoformat(),"downloaded","{}"))
    store.conn.commit()
    pipeline=SimpleNamespace(store=store)
    result=weekly.weekly_report(pipeline,refresh=False)
    assert result["New_Papers"]==1 and result["Updated_Historical_Papers"]==1
    assert result["New_PDFs"]==1 and result["Synthesis_Status"]=="pending"
    assert result["email_status"]=="not_requested"
    folder=Path(result["folder"])
    word=Document(next(folder.glob("*.docx")))
    headings=[p.text for p in word.paragraphs if p.style.name=="Heading 1"]
    assert len(headings)==12
    assert "待分析" in "\n".join(p.text for p in word.paragraphs)
    book=load_workbook(next(folder.glob("*.xlsx")),read_only=True)
    assert {"Weekly_Summary","Papers","New_Papers","Updated_Papers","Historical_Incomplete","Pathways","Proteins","Enzymes","Abbreviations","Mechanisms","Innovations","Search_Keywords","Downloads","Missing_Information","Failed_Downloads","Evidence","Cross_Paper_Trends","Research_Gaps"}.issubset(book.sheetnames)
    assert book["New_Papers"].max_row==2 and book["Updated_Papers"].max_row==2
    book.close()
    prior={p.name:p.read_bytes() for p in folder.glob("*.docx")}
    again=weekly.weekly_report(pipeline,refresh=False)
    assert again["folder"]!=result["folder"] and again["folder"].endswith("_v2")
    assert prior=={p.name:p.read_bytes() for p in folder.glob("*.docx")}


def test_excel_sanitizes_text_and_keeps_usable_pdf_links(library):
    _,root=library
    path=outputs.workbook(root / "safe.xlsx",{"Papers":[{"Title":"=恶意公式\x00","Abstract":"中文内容","PDF_Path":"library/pdfs/论文.pdf"}]})
    book=load_workbook(path)
    assert book["Papers"]["A2"].value=="'=恶意公式"
    assert book["Papers"]["B2"].value=="中文内容"
    assert book["Papers"]["C2"].hyperlink.target.startswith("file:")
    book.close()


def test_analysis_after_cutoff_is_not_reported_early(library,monkeypatch):
    store,root=library; end=datetime(2026,10,3,13,tzinfo=TZ); start=end-timedelta(days=7)
    monkeypatch.setattr(weekly,"report_period",lambda:(start,end))
    p=put(store,"迟到分析",end-timedelta(hours=1),analysis_status="complete",Analyzed_At=(end+timedelta(seconds=1)).isoformat(),Main_Results="不得提前写入的研究结果",Chinese_Summary="截止后生成的分析")
    store.conn.execute("INSERT INTO pathways(paper_id,payload) VALUES(?,?)",(p["id"],dumps({"Pathway_Name":"late pathway"})));store.conn.commit()
    result=weekly.weekly_report(SimpleNamespace(store=store),refresh=False)
    assert result["Analyzed_Papers"]==0 and result["Pending_Analysis"]==1
    doc=Document(next(Path(result["folder"]).glob("*.docx")))
    text="\n".join(p.text for p in doc.paragraphs)
    assert "不得提前写入的研究结果" not in text and "late pathway" not in text
    book=load_workbook(next(Path(result["folder"]).glob("*.xlsx")),read_only=True)
    assert book["Pathways"].max_row==1
    book.close()


def verified(pid,page=1):
    return {"paper_id":pid,"field":"Main_Results","value":"蛋白表达下降，但没有检测酶活性。","Evidence_Text":"Protein expression declined; activity was not tested.","Evidence_Page":page,"Evidence_Section":"Results","Inferred":"No","Explicitly_Reported":"Yes"}


def test_synthesis_requires_cross_paper_citations_and_marks_inference():
    papers=[{"id":i,"Title":f"文章{i}","DOI":f"10.1/{i}","Year":2025,"analysis_status":"complete"} for i in (1,2)]
    def provider(prompt,records):
        assert len(records)==2 and "关键词出现频率" in prompt
        return {"trends":[{"statement":"两个模型均观察到表达下降。","evidence_ids":["E1","E2"],"qualification":"只限本次两篇模型，不能推断酶活。"},
                          {"statement":"伪造趋势","evidence_ids":["E999"],"qualification":"不可信"}],
                "emerging_targets":[],"research_gaps":[{"statement":"缺少活性对照。","evidence_ids":["E1"],"qualification":"单篇不可称跨论文空白"}],"search_questions":["检索相应酶活实验"]}
    result=synthesize(papers,[verified(1),verified(2)],provider)
    assert result["Synthesis_Status"]=="complete"
    assert len(result["Cross_Paper_Trends"])==1 and result["Research_Gaps"]==[]
    assert result["Cross_Paper_Trends"][0]["statement"].startswith("System inference")
    assert result["Synthesis_Rejected_Claims"]==2


def test_synthesis_no_key_and_no_verified_evidence(monkeypatch):
    monkeypatch.delenv("OPENAI_API_KEY",raising=False)
    assert synthesize([],[])["Synthesis_Status"]=="pending"
    assert synthesize([{"id":1,"analysis_status":"complete"}],[verified(1)],lambda *_:pytest.fail("must not call"))["Synthesis_Status"]=="pending"


def fake_smtp(monkeypatch):
    messages=[]
    class Client:
        def __init__(self,*a,**kw): pass
        def __enter__(self): return self
        def __exit__(self,*a): pass
        def login(self,*a): pass
        def send_message(self,msg): messages.append(msg)
    for name,value in {"SMTP_HOST":"smtp.invalid","SMTP_USER":"research@example.org","SMTP_AUTH_CODE":"secret-not-for-logs","EMAIL_RECIPIENT":"recipient@example.org"}.items(): monkeypatch.setenv(name,value)
    monkeypatch.setattr(smtp.smtplib,"SMTP_SSL",Client)
    return messages


def test_attachment_failure_isolated_and_sent_run_not_duplicated(library,monkeypatch):
    store,root=library; messages=fake_smtp(monkeypatch)
    valid=root / "报告.docx"; Document().save(valid)
    store.conn.execute("INSERT INTO weekly_runs(email_status,payload) VALUES('failed','{}')");store.conn.commit()
    result=smtp.send_message("中文周报","中文正文",[valid,root / "missing.xlsx"],store,1)
    assert result["email_status"]=="sent" and len(messages)==1
    assert len(list(messages[0].iter_attachments()))==1
    assert "missing.xlsx" in messages[0].get_body(preferencelist=("plain",)).get_content()
    row=store.conn.execute("SELECT email_status,payload FROM weekly_runs WHERE id=1").fetchone()
    assert row[0]==json.loads(row[1])["email_status"]=="sent"
    assert "secret-not-for-logs" not in row[1]
    assert smtp.send_message("中文周报","中文正文",[valid],store,1)["already_sent"]
    assert len(messages)==1 and len(store.rows("email_history"))==1


def test_weekly_partial_attachment_and_resend_sync(library,monkeypatch):
    store,root=library
    def broken(*a): raise PermissionError("secret-not-for-logs")
    monkeypatch.setattr(weekly,"make_word",broken)
    result=weekly.weekly_report(SimpleNamespace(store=store),send_email=True,refresh=False)
    assert result["status"]=="partial" and result["email_status"]=="configuration_required"
    assert result["Report_Failures"]=={"docx":"PermissionError"}
    fake_smtp(monkeypatch)
    resent=weekly.resend(store)
    assert resent["email_status"]=="sent"
    run=store.conn.execute("SELECT email_status,payload FROM weekly_runs WHERE id=?",(result["Weekly_Run_ID"],)).fetchone()
    report=json.loads((Path(result["folder"]) / "weekly_report.json").read_text(encoding="utf-8"))
    assert run[0]==json.loads(run[1])["email_status"]==report["email_status"]=="sent"
    assert "secret-not-for-logs" not in dumps(report)
