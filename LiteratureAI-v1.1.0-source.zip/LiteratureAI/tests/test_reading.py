from docx import Document
from literature_ai.database.store import Store
from literature_ai.reports.reading import reading_report
from literature_ai.utils.common import dumps


def test_reading_report_all_papers_with_provenance_and_pending(tmp_path, monkeypatch):
    from literature_ai.config import settings
    monkeypatch.setattr(settings, 'root', tmp_path)
    store = Store(tmp_path / 'library.db')
    try:
        for i in range(12):
            p = store.upsert({'Title': f'Example {i}', 'DOI': f'10.1000/example{i}',
                'analysis_status': 'complete' if i == 11 else 'pending',
                'Main_Results': 'Distinct verified finding' if i == 11 else 'Must not appear'})
        store.conn.execute('INSERT INTO evidence(paper_id,payload) VALUES(?,?)', (p['id'], dumps({
            'field': 'Main_Results', 'value': 'Distinct verified finding',
            'Evidence_Text': 'An original passage in the synthetic test paper.',
            'Evidence_Page': 3, 'Evidence_Section': 'Results', 'Inferred': 'No'})))
        store.conn.commit()
        result = reading_report(store)
        text = '\n'.join(p.text for p in Document(result['file']).paragraphs)
        assert result['papers'] == 12 and result['pending'] == 11
        assert 'Distinct verified finding' in text and 'Must not appear' not in text
        assert 'PDF p.3' in text and 'An original passage' in text
        second = reading_report(store, 'https://doi.org/10.1000/example11')
        assert second['papers'] == 1 and second['file'] != result['file']
    finally:
        store.close()


def test_smtp_recipient_required_and_text_test_supported(tmp_path, monkeypatch):
    from literature_ai.email import smtp
    from test_reports import fake_smtp
    messages = fake_smtp(monkeypatch)
    monkeypatch.delenv('EMAIL_RECIPIENT', raising=False)
    assert not smtp.configured()
    assert smtp.send_message('Test', 'Body', require_attachments=False)['email_status'] == 'configuration_required'
    assert not messages
    monkeypatch.setenv('EMAIL_RECIPIENT', 'recipient@example.org')
    assert smtp.send_message('Test', 'Body', require_attachments=False)['email_status'] == 'sent'
    assert messages[0]['To'] == 'recipient@example.org'
    assert smtp.send_message('Report', 'Body')['email_status'] == 'failed'
