import json

import fitz
import pytest

from literature_ai.analysis.analyzer import analyze_paper, chinese_evidence_summary, evidence_chunks
from literature_ai.analysis.schema import Extraction, Fact, SUMMARY_FIELDS, PROTEIN_FIELDS, verify_fact
from literature_ai.database.store import Store
from literature_ai.parser.pdf import parse_pdf
from literature_ai.utils.common import MISSING


@pytest.fixture
def store(tmp_path):
    database = Store(tmp_path / "literature.db")
    yield database
    database.close()


def test_doi_normalization_deduplicates_and_keeps_fuller_metadata(store):
    first = store.upsert({"Title":"A research study on immune clearance", "DOI":"https://doi.org/10.1234/AbC", "Abstract":"Long original abstract", "Authors":["Ann", "Ben"], "Metadata_Source":["PubMed"]})
    second = store.upsert({"Title":"Immune clearance", "DOI":"doi: 10.1234/abc", "Abstract":"Short", "Authors":["Ann"], "Metadata_Source":["Crossref"]})
    assert first["id"] == second["id"] and len(store.papers()) == 1
    assert second["Abstract"] == first["Abstract"]
    assert second["Authors"] == ["Ann", "Ben"]
    assert second["Metadata_Source"] == ["PubMed", "Crossref"]


def test_different_doi_same_title_never_merge(store):
    a = store.upsert({"Title":"A study", "DOI":"10.1234/a"})
    b = store.upsert({"Title":"A study", "DOI":"10.1234/b"})
    assert a["id"] != b["id"]


def test_explicit_id_cannot_replace_doi_or_pollute_metadata(store):
    original = store.upsert({"Title":"Correct article", "DOI":"10.1234/a", "Abstract":"Original"})
    with pytest.raises(ValueError, match="Conflicting DOI"):
        store.upsert({"id":original["id"], "Title":"Wrong article", "DOI":"10.1234/b", "Abstract":"Wrong but much longer abstract"})
    assert store.get(original["id"]) == original
    assert not store.rows("changes")


def test_existing_doi_cannot_be_assigned_to_a_different_id(store):
    first = store.upsert({"Title":"First article", "DOI":"10.1234/a"})
    second = store.upsert({"Title":"Another distinct title"})
    with pytest.raises(ValueError, match="belongs"):
        store.upsert({**second, "DOI":first["DOI"]})
    assert store.get(second["id"])["DOI"] == ""


def test_fuzzy_match_only_without_conflicting_identity(store):
    a = store.upsert({"Title":"Immune clearance of senescent cells in tissue", "Year":2025})
    b = store.upsert({"Title":"Immune clearance of senescent cells in tissues", "Year":2025, "DOI":"10.1234/added"})
    assert a["id"] == b["id"]
    c = store.upsert({"Title":b["Title"], "Year":2020})
    assert c["id"] != b["id"]


def test_merging_nested_oa_locations_and_provenance_does_not_crash(store):
    one = {"url":"https://example.org/a.pdf", "license":{"id":"cc-by"}}
    two = {"url":"https://example.org/b.pdf", "license":{"id":"cc-by"}}
    incoming = {"Title":"A research article", "DOI":"10.1234/a", "OA_Locations":[one]}
    original = store.upsert(incoming)
    saved = store.upsert({**original, "OA_Locations":[one, two]})
    assert saved["OA_Locations"] == [one, two]
    assert incoming["OA_Locations"] == [one]


def test_metadata_completion_and_transaction_rollback(store, monkeypatch):
    p = store.upsert({"Title":"A research article", "DOI":"10.1234/a"})
    p = store.upsert({**p, "Abstract":"Complete abstract"})
    assert p["metadata_status"] == "complete"
    before = store.rows("changes")
    def fail(*args):
        raise RuntimeError("write failed")
    monkeypatch.setattr(store, "_write", fail)
    with pytest.raises(RuntimeError):
        store.upsert({**p, "Journal":"A new journal"})
    assert store.get(p["id"]) == p
    assert store.rows("changes") == before


QUOTE = "TFEB protein expression was decreased in senescent fibroblasts."


def fact(**updates):
    return Fact(**{"field":"Expression_Change", "value":"TFEB蛋白表达下降", "Evidence_Text":QUOTE,
        "Evidence_Section":"Results", "Evidence_Page":1, "Explicitly_Reported":"Yes", "Inferred":"No", **updates})


@pytest.mark.parametrize("updates", [
    {"Evidence_Text":"This quotation is not in the paper at all."},
    {"Evidence_Page":2}, {"field":"Made_Up_Field"},
    {"Inferred":"Yes"}, {"Explicitly_Reported":"No"},
    {"Inferred":"Yes", "Explicitly_Reported":"No", "value":"Unlabelled inference"},
    {"value":"System inference: expression decreased"},
    {"value":""}, {"Evidence_Section":""},
])
def test_fact_verification_rejects_untraceable_or_inconsistent_claims(updates):
    assert not verify_fact(fact(**updates), {1:QUOTE}, PROTEIN_FIELDS)


def test_quote_page_section_and_inference_are_validated():
    blocks = [{"page":1, "section":"Results", "text":QUOTE}]
    assert verify_fact(fact(), {1:QUOTE}, PROTEIN_FIELDS, blocks)
    assert not verify_fact(fact(Evidence_Section="Discussion"), {1:QUOTE}, PROTEIN_FIELDS, blocks)
    assert verify_fact(fact(Inferred="Yes", Explicitly_Reported="No", value="System inference: inferred association"), {1:QUOTE}, PROTEIN_FIELDS, blocks)


def test_expression_only_cannot_establish_activity_or_targeting_molecule():
    assert not verify_fact(fact(field="Activity_Change", value="Activity decreased"), {1:QUOTE}, PROTEIN_FIELDS)
    assert not verify_fact(fact(field="Potential_Inhibitor", Inferred="Yes", Explicitly_Reported="No", value="System inference: invented compound"), {1:QUOTE}, PROTEIN_FIELDS)
    activity = "The catalytic activity of TFEB was measured and decreased after treatment."
    assert verify_fact(fact(field="Activity_Change", Evidence_Text=activity), {1:activity}, PROTEIN_FIELDS)


def test_reference_list_cannot_support_new_mechanism():
    claim = fact(field="New_Mechanism", Evidence_Section="References")
    assert not verify_fact(claim, {1:QUOTE}, SUMMARY_FIELDS)


def test_long_block_fragments_all_retain_correct_page_and_section():
    chunks = evidence_chunks([{"page":9, "section":"Results", "text":"x" * 120000}])
    assert len(chunks) == 3 and all(len(chunk) <= 45000 for chunk in chunks)
    assert all(chunk.startswith("\n[PDF Page 9; Section Results]\n") for chunk in chunks)
    assert sum(chunk.count("x") for chunk in chunks) == 120000


def pdf_file(tmp_path, text):
    target = tmp_path / "paper.pdf"
    with fitz.open() as doc:
        page = doc.new_page()
        page.insert_text((40, 40), text)
        doc.save(target)
    return target


def test_parser_keeps_metadata_abstract_separate_from_pdf_evidence(tmp_path):
    target = pdf_file(tmp_path, "A title\n1. Introduction\nIntroduction material in the real PDF.\nResults: TFEB expression decreased.\nDiscussion\nInterpretation of the observed changes.")
    parsed = parse_pdf(target, "Database-only abstract that is not on a PDF page.")
    assert {"Introduction", "Results", "Discussion"}.issubset(parsed["sections"])
    assert "Abstract" not in parsed["sections"]
    assert all("Database-only" not in block["text"] for block in parsed["blocks"])
    assert parsed["Metadata_Abstract"].startswith("Database-only")
    assert all(block["page"] == 1 for block in parsed["blocks"])


def test_small_digital_pdf_is_not_automatically_a_scan(tmp_path):
    assert parse_pdf(pdf_file(tmp_path, "A short digital page."))["OCR_required"] is False


def test_image_backed_scan_is_flagged_without_running_ocr(tmp_path):
    target = tmp_path / "scan.pdf"
    pixmap = fitz.Pixmap(fitz.csRGB, fitz.IRect(0, 0, 200, 300), False)
    pixmap.clear_with(255)
    with fitz.open() as doc:
        page = doc.new_page(width=200, height=300)
        page.insert_image(page.rect, pixmap=pixmap)
        doc.save(target)
    parsed = parse_pdf(target)
    assert parsed["OCR_required"] is True and parsed["OCR_candidate_pages"] == [1]
    assert parsed["Text_Extraction_Empty"] is True


@pytest.mark.parametrize("key", [None, "", "   "])
def test_missing_key_stays_pending_without_initializing_provider(store, monkeypatch, key):
    if key is None:
        monkeypatch.delenv("OPENAI_API_KEY", raising=False)
    else:
        monkeypatch.setenv("OPENAI_API_KEY", key)
    from literature_ai.providers import openai_provider
    def forbidden(*args, **kwargs):
        raise AssertionError("API provider should not be initialized")
    monkeypatch.setattr(openai_provider, "OpenAIProvider", forbidden)
    p = analyze_paper(store.upsert({"Title":"A paper"}), store)
    assert p["analysis_status"] == p["AI_analysis_status"] == "pending"
    assert not store.rows("analysis")


def test_analysis_never_promotes_unverified_prose_and_keeps_activity_missing(store, tmp_path, monkeypatch):
    full = tmp_path / "full.json"
    full.write_text(json.dumps({"pages":[{"page":1, "text":QUOTE}], "blocks":[{"page":1, "section":"Results", "text":QUOTE}]}), encoding="utf-8")
    extraction = Extraction(summary=[fact(field="Main_Results")], entities=[{"category":"proteins", "name":"TFEB", "facts":[fact(), fact(field="Activity_Change", value="Activity decreased")]}],
        Generated_Keywords=["TFEB", " TFEB "], Recommended_Search_Keywords=["senescence"], Related_Search_Keywords=[], Chinese_Summary="FABRICATED_CURE_CLAIM")
    class FakeProvider:
        model = "offline-test"
        def extract(self, blocks):
            return extraction
    from literature_ai.providers import openai_provider
    monkeypatch.setenv("OPENAI_API_KEY", "offline-test-key")
    monkeypatch.setattr(openai_provider, "OpenAIProvider", FakeProvider)
    p = store.upsert({"Title":"TFEB and senescence", "DOI":"10.1234/a", "parse_status":"parsed", "Fulltext_Path":str(full)})
    result = analyze_paper(p, store)
    assert result["analysis_status"] == "complete"
    assert result["Rejected_Claims"] == 1
    assert 200 <= len(result["Chinese_Summary"]) <= 500
    assert "FABRICATED" not in result["Chinese_Summary"] and "Chinese_Summary_Draft" not in result
    assert result["Generated_Keywords"] == ["TFEB"]
    protein = store.rows("proteins")[0]
    assert protein["Expression_Change"] == "TFEB蛋白表达下降"
    assert protein["Activity_Change"] == MISSING
    assert protein["Evidence_Page"] == 1


def test_chinese_summary_length_for_missing_and_very_long_facts():
    for value in (MISSING, "据原文记录的机制与实验结果" * 100):
        summary = {field:value for field in SUMMARY_FIELDS}
        text = chinese_evidence_summary(summary, [])
        assert 200 <= len(text) <= 500
        assert "人工复核" in text


def test_provider_failure_never_saves_secret_exception_text(store, tmp_path, monkeypatch):
    full = tmp_path / "full.json"
    full.write_text(json.dumps({"pages":[{"page":1, "text":QUOTE}], "blocks":[{"page":1, "section":"Results", "text":QUOTE}]}), encoding="utf-8")
    class BrokenProvider:
        def extract(self, blocks):
            raise RuntimeError("SECRET_AUTH_TOKEN in a request URL")
    from literature_ai.providers import openai_provider
    monkeypatch.setenv("OPENAI_API_KEY", "offline-test-key")
    monkeypatch.setattr(openai_provider, "OpenAIProvider", BrokenProvider)
    p = store.upsert({"Title":"A paper", "parse_status":"parsed", "Fulltext_Path":str(full)})
    result = analyze_paper(p, store)
    assert result["analysis_status"] == "failed"
    assert result["Analysis_Failure_Reason"] == "RuntimeError"
    assert "SECRET_AUTH_TOKEN" not in json.dumps(store.papers())


def test_entity_evidence_updates_are_recorded_for_historical_weekly_updates(store):
    p = store.upsert({"Title":"An older research article", "DOI":"10.1234/a"})
    result = {"proteins":[{"Name":"TFEB", "Expression_Change":"decreased", "Evidence_Text":QUOTE, "Evidence_Page":1}]}
    store.save_analysis(p, result)
    count = len(store.rows("changes"))
    store.save_analysis(p, result)
    assert len(store.rows("changes")) == count
    result["proteins"][0]["Evidence_Page"] = 2
    store.save_analysis(p, result)
    assert len(store.rows("changes")) == count + 1
    assert "proteins" in json.loads(store.rows("changes")[-1]["fields"])
    assert store.rows("proteins")[0]["Evidence_Page"] == 2
