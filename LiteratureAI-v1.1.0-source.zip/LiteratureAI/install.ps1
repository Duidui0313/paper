﻿[CmdletBinding()]
param([switch]$SkipBrowser, [string]$PythonPath)
$ErrorActionPreference = 'Stop'
$projectRoot = [IO.Path]::GetFullPath($PSScriptRoot)
Set-Location -LiteralPath $projectRoot
$folders = @('.cache\pip', '.cache\uv', '.playwright', 'browser_profile', 'config', 'data', 'library\pdfs', 'library\notes', 'exports', 'weekly_reports', 'downloads_tmp', 'logs\weekly')
foreach ($folder in $folders) { New-Item -ItemType Directory -Path (Join-Path $projectRoot $folder) -Force | Out-Null }
$env:LITERATUREAI_HOME = $projectRoot
$env:PIP_CACHE_DIR = Join-Path $projectRoot '.cache\pip'
$env:UV_CACHE_DIR = Join-Path $projectRoot '.cache\uv'
$env:PLAYWRIGHT_BROWSERS_PATH = Join-Path $projectRoot '.playwright'
$env:TEMP = Join-Path $projectRoot 'downloads_tmp'
$env:TMP = $env:TEMP
$env:PYTHONUTF8 = '1'
$env:PYTHONIOENCODING = 'utf-8'
$env:STREAMLIT_BROWSER_GATHER_USAGE_STATS = 'false'
$pythonCandidates = @()
if ($PythonPath) { $pythonCandidates += $PythonPath }
$pythonLauncher = Get-Command py.exe -ErrorAction SilentlyContinue
if ($pythonLauncher) {
    $launcherPath = & $pythonLauncher.Source -3 -c 'import sys; print(sys.executable)' 2>$null
    if ($LASTEXITCODE -eq 0) { $pythonCandidates += $launcherPath }
}
$availablePython = Get-Command python.exe -ErrorAction SilentlyContinue
if ($availablePython) { $pythonCandidates += $availablePython.Source }
$chosenPython = $null
foreach ($candidate in ($pythonCandidates | Select-Object -Unique)) {
    if (Test-Path -LiteralPath $candidate) {
        & $candidate -c 'import sys; sys.exit(0 if sys.version_info >= (3, 11) else 1)' 2>$null
        if ($LASTEXITCODE -eq 0) { $chosenPython = $candidate; break }
    }
}
if (-not $chosenPython) { throw '没有找到Python >=3.11。请安装后重新运行，或用 -PythonPath 指定解释器。' }
$venvPython = Join-Path $projectRoot '.venv\Scripts\python.exe'
if (-not (Test-Path -LiteralPath $venvPython)) {
    & $chosenPython -m venv (Join-Path $projectRoot '.venv')
    if ($LASTEXITCODE -ne 0) { throw '创建项目Python虚拟环境失败' }
}
& $venvPython -c 'import sys; sys.exit(0 if sys.version_info >= (3, 11) else 1)'
if ($LASTEXITCODE -ne 0) { throw '现有虚拟环境版本过低，请先将它备份，再用Python >=3.11重建' }
& $venvPython -m pip install --upgrade pip setuptools wheel
if ($LASTEXITCODE -ne 0) { throw 'pip基础组件安装失败' }
& $venvPython -m pip install -e "${projectRoot}[dev]"
if ($LASTEXITCODE -ne 0) { throw '项目依赖安装失败' }
if (-not $SkipBrowser) {
    & $venvPython -m playwright install chromium
    if ($LASTEXITCODE -ne 0) { throw '浏览器组件安装失败；可先使用-SkipBrowser部署不依赖登录的功能' }
}
$envFile = Join-Path $projectRoot '.env'
if (-not (Test-Path -LiteralPath $envFile)) {
    $example = Join-Path $projectRoot '.env.example'
    if (Test-Path -LiteralPath $example) { Copy-Item -LiteralPath $example -Destination $envFile }
    else { New-Item -ItemType File -Path $envFile | Out-Null }
}
& $venvPython -m literature_ai doctor
if ($LASTEXITCODE -ne 0) { throw '环境检查失败' }
Write-Host '环境安装/修复完成；现有.env已保留。双击 start_literature_ai.bat 启动界面。'
Write-Host '计划任务请运行 setup_weekly_task.ps1；安装脚本不重复注册任务。'
