﻿[CmdletBinding()]
param()
$ErrorActionPreference = 'Stop'
$projectRoot = [IO.Path]::GetFullPath($PSScriptRoot)
$taskName = 'LiteratureAI Weekly Report'
$batchFile = Join-Path $projectRoot 'run_weekly_report.bat'
if (-not (Test-Path -LiteralPath $batchFile)) { throw '缺少项目目录中的 run_weekly_report.bat，请先完成安装' }
$currentUser = [Security.Principal.WindowsIdentity]::GetCurrent().Name
$action = New-ScheduledTaskAction -Execute "$env:SystemRoot\System32\cmd.exe" -Argument "/d /c `"`"$batchFile`"`"" -WorkingDirectory $projectRoot
$trigger = New-ScheduledTaskTrigger -Weekly -WeeksInterval 1 -DaysOfWeek Saturday -At '13:00'
$taskSettings = New-ScheduledTaskSettingsSet -StartWhenAvailable -MultipleInstances IgnoreNew -ExecutionTimeLimit (New-TimeSpan -Hours 12) -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries
# Interactive preserves the logged-in user's normal network access. S4U may
# have no network credentials and would be unsuitable for institutional SMTP.
$principal = New-ScheduledTaskPrincipal -UserId $currentUser -LogonType Interactive -RunLevel Limited
$task = New-ScheduledTask -Action $action -Trigger $trigger -Settings $taskSettings -Principal $principal -Description 'LiteratureAI每周六13:00本机时间更新文献、生成Excel/Word周报并发送邮件。用户必须登录；错过后尽快补跑；禁止并发。'
try {
    Register-ScheduledTask -TaskName $taskName -InputObject $task -Force | Out-Null
} catch {
    $reason = $_.Exception.GetType().Name
    Write-Error "FAILED：计划任务注册失败（$reason）。若Windows拒绝普通用户注册，请由本人以管理员身份运行本脚本。未建立替代或重复任务。"
    exit 1
}
$registered = Get-ScheduledTask -TaskName $taskName
$info = $registered | Get-ScheduledTaskInfo
[pscustomobject]@{
    TaskName = $registered.TaskName
    State = [string]$registered.State
    NextRun = $info.NextRunTime
    LastRun = $info.LastRunTime
    User = $registered.Principal.UserId
    LogonType = [string]$registered.Principal.LogonType
    TimeZone = (Get-TimeZone).Id
    StartWhenAvailable = $registered.Settings.StartWhenAvailable
    MultipleInstances = [string]$registered.Settings.MultipleInstances
} | Format-List
Write-Host '任务已注册/更新。每周六13:00使用Windows本地时间；用户需保持登录。关机期间不能运行，电脑可用且用户登录后尽快补跑。'
