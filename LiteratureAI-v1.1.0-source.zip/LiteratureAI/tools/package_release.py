"""Build a source-only ZIP from an explicit allowlist. No Git/network required."""
from pathlib import Path
import hashlib
import re
import tomllib
import zipfile

ROOT = Path(__file__).resolve().parents[1]
ROOT_FILES = {
    'README.md','LICENSE','THIRD_PARTY_NOTICES.md','CONTRIBUTING.md',
    'pyproject.toml','requirements-tested.txt','.gitignore','.gitattributes','.env.example',
    'install.ps1','setup_weekly_task.ps1','start_literature_ai.bat','run_weekly_report.bat',
}
PATTERNS = {
    'credential': re.compile(r'(?:sk-(?:proj-)?[A-Za-z0-9_-]{25,}|gh[pousr]_[A-Za-z0-9]{25,}|github_pat_[A-Za-z0-9_]{25,})'),
    'private_key': re.compile(r'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----'),
    'personal_home': re.compile(r'[A-Za-z]:[\\/]Users[\\/](?!Public[\\/]|YOUR_USER[\\/])[^\s\"\']+'),
}


def release_files():
    files = []
    for path in ROOT.rglob('*'):
        if not path.is_file() or path.is_symlink():
            continue
        relative = path.relative_to(ROOT)
        if any(part.startswith('.') and part not in {'.github','.gitignore','.gitattributes','.env.example'}
               for part in relative.parts):
            continue
        if len(relative.parts) == 1 and path.name in ROOT_FILES:
            files.append(path)
        elif relative.parts[0] in {'src','tests','tools'} and path.suffix == '.py':
            files.append(path)
        elif relative.parts[0] == 'docs' and path.suffix == '.md':
            files.append(path)
        elif relative.parts[:2] == ('.github','workflows') and path.suffix in {'.yml','.yaml'}:
            files.append(path)
    return sorted(files)


def main():
    files = release_files()
    missing = ROOT_FILES - {p.name for p in files if p.parent == ROOT}
    if missing:
        raise SystemExit('Missing required release files: ' + ', '.join(sorted(missing)))
    for path in files:
        text = path.read_text(encoding='utf-8-sig')
        for label, pattern in PATTERNS.items():
            if pattern.search(text):
                raise SystemExit(f'Release check failed ({label}): {path.relative_to(ROOT)}')
    sensitive = {'OPENAI_API_KEY','OPENALEX_API_KEY','SEMANTIC_SCHOLAR_API_KEY','CONTACT_EMAIL',
                 'SMTP_USER','SMTP_AUTH_CODE','EMAIL_FROM','EMAIL_RECIPIENT'}
    for line in (ROOT / '.env.example').read_text(encoding='utf-8').splitlines():
        key, separator, value = line.partition('=')
        if separator and key.strip() in sensitive and value.strip():
            raise SystemExit('Configuration template must have empty credentials and addresses')
    version = tomllib.loads((ROOT / 'pyproject.toml').read_text(encoding='utf-8'))['project']['version']
    folder = ROOT / 'dist'
    folder.mkdir(exist_ok=True)
    output = folder / f'LiteratureAI-v{version}-source.zip'
    hashes = '\n'.join(hashlib.sha256(p.read_bytes()).hexdigest() + '  ' + p.relative_to(ROOT).as_posix() for p in files)
    with zipfile.ZipFile(output, 'w', zipfile.ZIP_DEFLATED) as archive:
        for path in files:
            info = zipfile.ZipInfo('LiteratureAI/' + path.relative_to(ROOT).as_posix(), date_time=(2026,1,1,0,0,0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            archive.writestr(info, path.read_bytes())
        info = zipfile.ZipInfo('LiteratureAI/SOURCE_MANIFEST.sha256', date_time=(2026,1,1,0,0,0))
        info.compress_type = zipfile.ZIP_DEFLATED
        archive.writestr(info, hashes + '\n')
    digest = hashlib.sha256(output.read_bytes()).hexdigest()
    checksum = output.with_suffix('.zip.sha256')
    checksum.write_text(digest + '  ' + output.name + '\n', encoding='utf-8')
    print(f'{output.name}: {len(files)} source files, {output.stat().st_size} bytes')
    print(f'SHA256: {digest}')


if __name__ == '__main__':
    main()
