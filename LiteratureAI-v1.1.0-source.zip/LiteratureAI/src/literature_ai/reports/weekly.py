import json
import os
import logging
from pathlib import Path
from datetime import datetime
from collections import Counter
from contextlib import contextmanager
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from literature_ai.config import settings
from literature_ai.utils.common import now,dumps,report_period,atomic_text,MISSING,TZ
from literature_ai.analysis.schema import SUMMARY_FIELDS
from literature_ai.export.outputs import workbook,paper_rows,missing_information,PAPER_FIELDS,ENTITY_COLUMNS,EVIDENCE_FIELDS,export_master
from literature_ai.email.smtp import send_message
from literature_ai.reports.synthesis import synthesize,interpretation_text

@contextmanager
def weekly_lock():
    path=settings.root / "data/weekly.lock"
    path.parent.mkdir(parents=True,exist_ok=True)
    handle=path.open("a+b")
    handle.seek(0); handle.write(b"0"); handle.flush(); handle.seek(0)
    try:
        if os.name=="nt":
            import msvcrt
            msvcrt.locking(handle.fileno(),msvcrt.LK_NBLCK,1)
        else:
            import fcntl
            fcntl.flock(handle,fcntl.LOCK_EX | fcntl.LOCK_NB)
    except OSError:
        handle.close(); raise RuntimeError("Weekly report already running") from None
    try:
        yield
    finally:
        handle.seek(0)
        if os.name=="nt": msvcrt.locking(handle.fileno(),msvcrt.LK_UNLCK,1)
        else: fcntl.flock(handle,fcntl.LOCK_UN)
        handle.close()

def within(value,start,end):
    if not value: return False
    try:
        instant=datetime.fromisoformat(value)
        if instant.tzinfo is None: instant=instant.replace(tzinfo=TZ)
        return start<instant<=end
    except (TypeError,ValueError):
        return False

def meaningful_fields(fields):
    ignored={"id","created_at","updated_at","last_checked_at","weekly_status","Missing_Information",
             "Metadata_Source","Metadata_Provenance","Enrichment_Errors","OA_Checked_At","Fetched_At",
             "Download_Failure_Reason","Download_Last_Attempt","Analysis_Pending_Reason","Analysis_Failure_Reason"}
    return [key for key in fields if key not in ignored and not key.lower().endswith(("_checked_at","_attempted_at"))]

def unique_names(rows):
    by_name={}
    for r in rows:
        name=r.get("Name") or r.get("Pathway_Name") or r.get("Abbreviation") or ""
        if name and name!=MISSING: by_name.setdefault(name,set()).add(r["paper_id"])
    return Counter({name:len(ids) for name,ids in by_name.items()}).most_common(10)

def make_word(path,summary,papers,entities,missing,failed):
    doc=Document()
    for element in (doc.styles.element,doc.element):
        for border in list(element.iter(qn("w:pBdr"))):
            border.getparent().remove(border)
    section=doc.sections[0]; section.page_width=Inches(8.27); section.page_height=Inches(11.69)
    section.top_margin=section.bottom_margin=Inches(.75); section.left_margin=section.right_margin=Inches(.85)
    for name in ("Normal","Title","Heading 1","Heading 2"):
        style=doc.styles[name]; style.font.name="Microsoft YaHei"; style.font.color.rgb=RGBColor(0,0,0)
        style.element.get_or_add_rPr().rFonts.set(qn("w:eastAsia"),"Microsoft YaHei")
    doc.styles["Normal"].font.size=Pt(10.5); doc.styles["Normal"].paragraph_format.space_after=Pt(6)
    doc.styles["Normal"].paragraph_format.line_spacing=1.15
    doc.styles["Title"].font.size=Pt(22); doc.styles["Heading 1"].font.size=Pt(15); doc.styles["Heading 2"].font.size=Pt(12)
    doc.add_paragraph("LiteratureAI 每周文献报告",style="Title")
    doc.add_paragraph("报告周期  "+summary["Report_Period"])
    doc.add_paragraph(f'本周新增文献 {summary["New_Papers"]} 篇，新增 PDF {summary["New_PDFs"]} 篇，完成全文分析 {summary["Analyzed_Papers"]} 篇，更新历史文献 {summary["Updated_Historical_Papers"]} 篇。待分析与全文获取情况见后文。')
    doc.add_heading("一 本周文献概况",1)
    doc.add_paragraph("报告按每周六13时划分统计周期。人工运行在截止时间后新增的数据将在下周计入。本地知识库当前共有 "+str(summary["Total_Library_Papers"])+" 篇文章。")
    doc.add_paragraph(f'本周期待分析 {summary["Pending_Analysis"]} 篇，下载失败 {summary["Failed_Downloads"]} 篇。')
    doc.add_paragraph("跨论文趋势分析状态  "+summary.get("Synthesis_Reason","待分析"))
    doc.add_paragraph(interpretation_text(summary.get("Cross_Paper_Trends",[]),"跨论文趋势待分析，出现频次仅用于描述本周期样本。"))
    doc.add_heading("二 本周重点文章",1)
    if not papers:
        doc.add_paragraph("本周期尚无符合新增或历史更新条件的重点文章。可在Excel的Papers表查看当前知识库。")
    for p in papers[:10]:
        doc.add_heading(p["Title"],2)
        doc.add_paragraph(f'{p.get("Journal","")}  {p.get("Year","")}\nDOI {p.get("DOI") or "Missing DOI"}')
        if p.get("analysis_status")=="complete":
            if p.get("Chinese_Summary"): doc.add_paragraph("中文全文摘要  "+p["Chinese_Summary"])
            for label,key in (("研究内容","Main_Content"),("主要结果","Main_Results"),("核心机制","New_Mechanism"),("创新点","Mechanistic_Innovation")):
                doc.add_paragraph(label+"  "+str(p.get(key,MISSING)))
            doc.add_paragraph("关注理由  本文与保存的检索主题匹配。引文、页码和推断标记详见Excel与单篇笔记。")
        else:
            doc.add_paragraph("全文科研分析尚未完成。研究内容、主要结果、核心机制和创新点将于获取可解析全文并配置AI接口后补充。")
            if p.get("Abstract"):
                doc.add_paragraph("数据库摘要  "+p["Abstract"][:1800])
    sections=[("三 本周主要信号通路",["pathways"]),("四 本周重要蛋白与酶",["proteins","enzymes"]),("五 本周发现的新机制",["mechanisms"]),("六 本周潜在研究靶点",["proteins","enzymes"]),("七 本周创新方法 探针 材料",["innovations"])]
    for title,tables in sections:
        doc.add_heading(title,1)
        count=0
        for table in tables:
            for row in entities[table][:15]:
                fields={k:v for k,v in row.items() if k in ENTITY_COLUMNS[table] and v not in (MISSING,"",None)}
                if title.startswith("六"):
                    potential={k:v for k,v in fields.items() if k.startswith("Potential_")}
                    if not potential: continue
                    fields={"Name":row.get("Name",MISSING),**potential}
                count+=1
                doc.add_paragraph("；".join(f'{k} {v}' for k,v in fields.items()))
                doc.add_paragraph(f'来源 DOI {row.get("Source_DOI","")}；PDF第 {row.get("Evidence_Page","")} 页；{row.get("Evidence_Section","")}。'+(" System inference" if row.get("Inferred")=="Yes" else ""))
        if not count: doc.add_paragraph("尚无经过原文引文核验的可汇总信息。待全文分析完成后更新。")
        if title.startswith("六"):
            doc.add_paragraph(interpretation_text(summary.get("Emerging_Targets",[]),"跨论文潜在靶点尚待证据综合。"))
    doc.add_heading("八 本周值得继续检索的问题",1)
    for question in summary.get("Search_Questions",[]): doc.add_paragraph("检索建议  "+question)
    words=list(dict.fromkeys(word for p in papers for word in p.get("Recommended_Search_Keywords",[])))
    doc.add_paragraph("；".join(words[:20]) if words else "沿保存的检索主题继续补充全文，核对衰老亚型、免疫清除与免疫逃逸的实验条件。此项为检索建议。")
    doc.add_heading("九 研究空白与潜在方向",1)
    doc.add_paragraph(summary["Potential_Research_Gaps"])
    doc.add_paragraph("本周期通路按涉及的不同文章数统计，不能据此直接判断领域趋势。年份、模型和结论均须结合逐篇证据评估。" )
    doc.add_heading("十 尚未完善的信息",1)
    doc.add_paragraph(f'知识库当前 {len(missing)} 篇文献仍有缺失或未明确报道的信息。')
    for p in missing[:15]:
        description=p["Missing_Fields"].replace("PDF_Local_Path","PDF全文").replace("PDF full text / page information","全文解析与页码").replace("AI analysis / pathways / proteins / enzymes / mechanisms / innovations / evidence","科研分析、通路、蛋白与酶、机制、创新点及原文证据").replace("Generated_Keywords","关键词").replace("Abstract","摘要")
        doc.add_paragraph(p["Title"]+"\n待补充："+description)
    doc.add_heading("十一 下载失败文章",1)
    if not failed: doc.add_paragraph("本周期无下载失败记录。")
    for p in failed[:20]: doc.add_paragraph(p["Title"]+"\n原因 "+p.get("Download_Failure_Reason","pdf_not_found"))
    doc.add_heading("十二 PDF及数据库位置",1)
    for label,relative in (("PDF","library/pdfs"),("SQLite","data/literature.db"),("Excel主表","exports/literature_master.xlsx"),("Markdown笔记","library/notes"),("周报","weekly_reports")):
        doc.add_paragraph(label+"  "+str(settings.root / relative))
    # Keep paragraph text out of long table cells; enforce heading-following pagination.
    footer=section.footer.paragraphs[0]; footer.alignment=2
    field=OxmlElement("w:fldSimple"); field.set(qn("w:instr"),"PAGE"); footer._p.append(field)
    temporary=Path(path).with_suffix(".tmp.docx"); doc.save(temporary)
    check=Document(temporary); assert check.paragraphs[0].text=="LiteratureAI 每周文献报告"
    temporary.replace(path)
    return str(path)

def weekly_report(pipeline,send_email=False,refresh=True):
    store=pipeline.store
    with weekly_lock():
        timestamp=now(); start,end=report_period()
        iso=end.isocalendar(); week=f"{iso.year}-W{iso.week:02d}"
        base=settings.root / "weekly_reports" / str(iso.year) / week
        folder=base
        version=1
        while folder.exists():
            version+=1; folder=base.with_name(base.name+f"_v{version}")
        folder.mkdir(parents=True)
        logger=logging.getLogger("LiteratureAI.weekly"); logger.setLevel(logging.INFO)
        handler=logging.FileHandler(folder / "run.log",encoding="utf-8"); logger.addHandler(handler)
        cur=store.conn.execute("INSERT INTO weekly_runs(started_at,status,report_path,email_status,payload) VALUES(?,?,?,?,?)",(timestamp,"running",str(folder),"not_requested",dumps({"Report_Period":f"{start.isoformat()} 至 {end.isoformat()}"})))
        run_id=cur.lastrowid; store.conn.commit()
        try:
            logger.info("weekly started refresh=%s",refresh)
            if refresh: pipeline.weekly_update()
            all_papers=store.papers()
            new=[{**p,"Record_Type":"New_this_week"} for p in all_papers if within(p["created_at"],start,end)]
            updated=[]
            for p in all_papers:
                if datetime.fromisoformat(p["created_at"])<=start:
                    changes=[meaningful_fields(json.loads(r[0])) for r in store.conn.execute("SELECT fields FROM changes WHERE paper_id=? AND time>? AND time<=?",(p["id"],start.isoformat(),end.isoformat()))]
                    fields=list(dict.fromkeys(k for row in changes for k in row))
                    success={"analysis_status":"complete","AI_analysis_status":"complete","parse_status":"parsed","download_status":"downloaded"}
                    fields=[k for k in fields if k not in success or p.get(k)==success[k]]
                    if fields: updated.append({**p,"Record_Type":"Updated_this_week","What_Was_Updated":fields})
            # Library sheet shows the live library; weekly sheets honour the analysis cutoff.
            for records in (new,updated):
                for p in records:
                    if p.get("Analyzed_At") and datetime.fromisoformat(p["Analyzed_At"])>end:
                        p["analysis_status"]="pending_after_cutoff"
                        p["Report_Analysis_Cutoff_Status"]="Analysis completed after this report's cutoff; counted next week"
                        for key in SUMMARY_FIELDS+["Chinese_Summary"]: p.pop(key,None)
            selected=new+updated; ids={p["id"] for p in selected}
            historical=[{**p,"Record_Type":"Historical_incomplete"} for p in all_papers if datetime.fromisoformat(p["created_at"])<=start and missing_information(p,store)]
            missing=[m for p in all_papers if (m:=missing_information(p,store))]
            analysed_ids={p["id"] for p in selected if p.get("analysis_status")=="complete" and p.get("Analyzed_At") and datetime.fromisoformat(p["Analyzed_At"])<=end}
            entities={table:[r for r in store.rows(table) if r["paper_id"] in analysed_ids] for table in ENTITY_COLUMNS}
            all_downloads=store.rows("downloads")
            download_events=[r for r in all_downloads if within(r.get("time"),start,end)]
            failed_ids={r["paper_id"] for r in download_events if r["status"]=="failed"}
            failed=[p for p in all_papers if p["id"] in failed_ids and p.get("download_status")=="failed"]
            previous_pdfs={r["paper_id"] for r in all_downloads if r["status"]=="downloaded" and r.get("time") and datetime.fromisoformat(r["time"])<=start}
            summary={"Report_Period":f'{start:%Y-%m-%d %H:%M} 至 {end:%Y-%m-%d %H:%M} Asia/Shanghai',"New_Papers":len(new),
              "New_PDFs":len({r["paper_id"] for r in download_events if r["status"]=="downloaded"}-previous_pdfs),"Analyzed_Papers":sum(within(p.get("Analyzed_At"),start,end) for p in all_papers),
              "Updated_Historical_Papers":len(updated),"Failed_Downloads":len(failed),"Pending_Analysis":sum(p.get("analysis_status")!="complete" for p in selected),
              "Total_Library_Papers":len(all_papers),"Missing_Records":len(missing),"Main_Diseases":list(dict.fromkeys(p.get("Disease_Model",MISSING) for p in selected if p.get("analysis_status")=="complete")),
              "Main_Pathways":unique_names(entities["pathways"]),"Main_Proteins":unique_names(entities["proteins"]),"Main_Enzymes":unique_names(entities["enzymes"]),
              "New_Mechanisms":[r.get("New_Mechanism",MISSING) for r in entities["mechanisms"]],"Emerging_Targets":"Pending cross-paper evidence synthesis",
              "Potential_Research_Gaps":"目前没有足够的跨论文全文证据支持确定的研究空白。待完成全文分析后，按年份、模型、实验条件与结果差异评估。",
              "Recommended_Papers":[p.get("DOI") or p["Title"] for p in selected[:10]],"Most_Frequent_Pathways":unique_names(entities["pathways"]),"Most_Frequent_Proteins":unique_names(entities["proteins"]),"Most_Frequent_Enzymes":unique_names(entities["enzymes"]),
              "Emerging_Mechanisms":"Pending cross-paper evidence synthesis","Emerging_Keywords":list(dict.fromkeys(w for p in selected for w in p.get("Generated_Keywords",[])))[:20],"Generated_At":timestamp,"Weekly_Run_ID":run_id}
            # Facts analysed after the cutoff belong to the following week's synthesis.
            evidence_papers=[p for p in selected if p.get("Analyzed_At") and datetime.fromisoformat(p["Analyzed_At"])<=end]
            synthesis=synthesize(evidence_papers,store.rows("evidence"))
            summary.update(synthesis)
            summary["Potential_Research_Gaps"]=interpretation_text(summary["Research_Gaps"],summary["Synthesis_Reason"])
            summary["Emerging_Mechanisms"]=interpretation_text(summary["Cross_Paper_Trends"],summary["Synthesis_Reason"])
            sheets={"Weekly_Summary":[{"Metric":key,"Value":value} for key,value in summary.items()],"Papers":paper_rows(all_papers,store),"New_Papers":paper_rows(new,store),"Updated_Papers":paper_rows(updated,store),"Historical_Incomplete":paper_rows(historical,store)}
            columns={n:PAPER_FIELDS for n in ("Papers","New_Papers","Updated_Papers","Historical_Incomplete")}
            for table,rows in entities.items():
                sheets[table.title()]=rows; columns[table.title()]=["paper_id"]+ENTITY_COLUMNS[table]+EVIDENCE_FIELDS
            sheets.update(Search_Keywords=store.rows("search_history"),Downloads=download_events,Missing_Information=missing,Failed_Downloads=paper_rows(failed,store))
            sheets.update(Cross_Paper_Trends=summary["Cross_Paper_Trends"],Emerging_Targets=summary["Emerging_Targets"],Research_Gaps=summary["Research_Gaps"],Synthesis_Evidence=summary["Synthesis_Evidence"],Evidence=[r for r in store.rows("evidence") if r["paper_id"] in analysed_ids])
            columns.update(Cross_Paper_Trends=["statement","qualification","evidence_ids","sources"],Research_Gaps=["statement","qualification","evidence_ids","sources"],Synthesis_Evidence=["evidence_id","paper_id","DOI","Title","Year","field","value","quote","PDF_Page","Section"])
            columns["Emerging_Targets"]=["statement","qualification","evidence_ids","sources"]
            columns["Evidence"]=["paper_id","field","value"]+EVIDENCE_FIELDS
            columns["Missing_Information"]=["paper_id","Title","DOI","Missing_Fields","Analysis_Status","Download_Status"]
            columns["Failed_Downloads"]=PAPER_FIELDS
            files=[]; failures={}
            for kind,fn in (("xlsx",lambda path:workbook(path,sheets,columns)),("docx",lambda path:make_word(path,summary,selected,entities,missing,failed))):
                path=folder / f"LiteratureAI_Weekly_Report_{week}.{kind}"
                try:
                    files.append(fn(path)); logger.info("report %s generated",kind)
                except Exception as exc:
                    failures[kind]=type(exc).__name__; logger.error("report %s failed %s",kind,type(exc).__name__)
            summary["Report_Failures"]=failures; summary["Report_Files"]=files
            body=f'''您好，\n\n本周LiteratureAI文献整理已完成。\n统计周期：{summary["Report_Period"]}\n本周新增文献：{len(new)}篇\n新增PDF：{summary["New_PDFs"]}篇\n完成全文分析：{summary["Analyzed_Papers"]}篇\n更新历史文献：{len(updated)}篇\n本周主要通路：{dumps(summary["Main_Pathways"])}\n主要蛋白/酶：{dumps(summary["Main_Proteins"]+summary["Main_Enzymes"])}\n重点机制：{dumps(summary["New_Mechanisms"])}\n尚有{len(missing)}篇文章存在全文获取或信息补充问题。\n\n详细内容见附件。\n附件：\n'''+"\n".join(Path(f).name for f in files)+f'\n\nPDF保存目录：{settings.root / "library/pdfs"}\n周报目录：{folder}\n'
            body += "\n跨论文趋势：\n"+summary["Emerging_Mechanisms"]+"\n研究空白：\n"+summary["Potential_Research_Gaps"]
            if failures: body += "\n未生成附件："+dumps(failures)
            atomic_text(folder / "weekly_email_body.txt",body)
            email_result={"email_status":"not_requested"}
            if send_email and files:
                email_result=send_message(f"LiteratureAI每周文献报告｜{end:%Y-%m-%d}",body,files,store,run_id)
            elif send_email:
                email_result={"email_status":"failed","failure_reason":"no_report_attachment"}
            summary.update(email_result)
            atomic_text(folder / "weekly_report.json",dumps(summary))
            status="complete" if len(files)==2 else "partial" if files else "failed"
            store.conn.execute("UPDATE weekly_runs SET ended_at=?,status=?,email_status=?,payload=? WHERE id=?",(now(),status,summary["email_status"],dumps(summary),run_id)); store.conn.commit()
            try: export_master(store)
            except Exception as exc:
                logger.error("master export failed %s",type(exc).__name__)
            logger.info("weekly finished status=%s email=%s",status,summary["email_status"])
            return {**summary,"folder":str(folder),"status":status}
        except Exception as exc:
            store.conn.execute("UPDATE weekly_runs SET ended_at=?,status=?,payload=? WHERE id=?",(now(),"failed",dumps({"failure_reason":type(exc).__name__}),run_id));store.conn.commit()
            logger.error("weekly failed %s",type(exc).__name__)
            raise
        finally:
            logger.removeHandler(handler); handler.close()

def resend(store):
    with weekly_lock():
        return _resend(store)

def _resend(store):
    run=store.conn.execute("SELECT * FROM weekly_runs WHERE email_status IN ('failed','configuration_required') ORDER BY id DESC LIMIT 1").fetchone()
    if not run:
        return {"email_status":"not_requested","failure_reason":"No failed report to resend"}
    folder=Path(run["report_path"]); body=(folder / "weekly_email_body.txt").read_text(encoding="utf-8")
    result=send_message("LiteratureAI每周文献报告｜补发",body,list(folder.glob("*.xlsx"))+list(folder.glob("*.docx")),store,run["id"])
    report=folder / "weekly_report.json"; data=json.loads(report.read_text(encoding="utf-8")); data.update(result); atomic_text(report,dumps(data))
    store.conn.execute("UPDATE weekly_runs SET email_status=?,payload=? WHERE id=?",(result["email_status"],dumps(data),run["id"]));store.conn.commit()
    return result
