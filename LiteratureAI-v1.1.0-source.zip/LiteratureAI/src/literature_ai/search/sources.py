"""Official scholarly API adapters. All HTTP policy belongs to the supplied net.

API references checked 2026-10-03: NCBI E-utilities, Europe PMC REST,
Crossref REST, OpenAlex help API, Unpaywall data format, S2 Graph API.
Missing keys and transient enrichment failures never fabricate OA or citations.
"""
from __future__ import annotations

from html import unescape
from html.parser import HTMLParser
import re
import xml.etree.ElementTree as ET
from urllib.parse import quote


class SourceConfigurationError(ValueError):
    pass


class _Text(HTMLParser):
    def __init__(self):
        super().__init__()
        self.parts = []
    def handle_data(self, data):
        self.parts.append(data)


def plain(value) -> str:
    parser = _Text()
    parser.feed(str(value or ""))
    return re.sub(r"\s+", " ", unescape(" ".join(parser.parts))).strip()


def doi_normalize(value) -> str:
    return re.sub(r"^(?:https?://(?:dx\.)?doi\.org/|doi\s*:\s*)", "", str(value or "").strip(), flags=re.I).lower()


def _txt(node, path):
    el = node.find(path) if node is not None else None
    return "".join(el.itertext()).strip() if el is not None else ""


def _number(value):
    try:
        return int(value)
    except (ValueError, TypeError):
        return None


def _empty(source: str) -> dict:
    p = dict.fromkeys("Title First_Author Corresponding_Author Journal Publication_Date Volume Issue Pages DOI PMID PMCID Abstract Publisher Publisher_URL DOI_URL PubMed_URL PMC_URL Open_Access_URL PDF_URL".split(), "")
    p.update(Authors=[], Author_Keywords=[], Year=None, Citation_Count=None, Metadata_Source=[source], Search_Source=source,
             Open_Access=None, OA_Status="unknown", OA_License="", Full_Text_Status="unknown",
             OA_Evidence_Source="", Citation_Source="", Metadata_Provenance={})
    return p


def _finish(p):
    p["DOI"] = doi_normalize(p.get("DOI"))
    if p["DOI"]:
        p["DOI_URL"] = "https://doi.org/" + p["DOI"]
    if p.get("PMID"):
        p["PubMed_URL"] = "https://pubmed.ncbi.nlm.nih.gov/" + str(p["PMID"]) + "/"
    if p.get("PMCID"):
        p["PMC_URL"] = "https://pmc.ncbi.nlm.nih.gov/articles/" + str(p["PMCID"]) + "/"
    if p.get("Authors"):
        p["First_Author"] = p["Authors"][0]
    p["Metadata_Provenance"] = {k: p["Metadata_Source"][0] for k, v in p.items() if v not in (None, "", [], {}) and k != "Metadata_Provenance"}
    return p


def _oa(p, is_oa, landing="", pdf="", status="", source="", license=""):
    if is_oa is not None:
        p["Open_Access"] = bool(is_oa)
        p["OA_Status"] = status or ("open" if is_oa else "closed")
        p["OA_Evidence_Source"] = source
    if is_oa:
        p["Open_Access_URL"] = landing or pdf or p.get("Open_Access_URL", "")
        p["PDF_URL"] = pdf or p.get("PDF_URL", "")
        p["OA_License"] = license or p.get("OA_License", "")
        p["Full_Text_Status"] = "open_pdf" if p.get("PDF_URL") else "unknown"
    elif not p.get("PDF_URL") and is_oa is False:
        p["Full_Text_Status"] = "no_open_pdf"
    if source and is_oa is not None:
        provenance = p.setdefault("Metadata_Provenance", {})
        for field in ("Open_Access", "OA_Status", "OA_Evidence_Source", "Full_Text_Status"):
            provenance[field] = source
        if landing: provenance["Open_Access_URL"] = source
        if pdf: provenance["PDF_URL"] = source
        if license: provenance["OA_License"] = source


def pubmed_xml(text: str) -> list[dict]:
    if len(text) > 25_000_000 or "<!ENTITY" in text.upper():
        raise ValueError("Unsafe or excessively large PubMed XML response")
    root = ET.fromstring(text)
    results = []
    months = {m: i for i, m in enumerate("Jan Feb Mar Apr May Jun Jul Aug Sep Oct Nov Dec".split(), 1)}
    for article in root.findall(".//PubmedArticle"):
        citation = article.find("MedlineCitation")
        a = citation.find("Article") if citation is not None else None
        if a is None:
            continue
        p = _empty("PubMed")
        p["Title"] = _txt(a, "ArticleTitle")
        p["PMID"] = _txt(citation, "PMID")
        p["Authors"] = [(_txt(x, "ForeName") + " " + _txt(x, "LastName")).strip() or _txt(x, "CollectiveName")
                        for x in a.findall("AuthorList/Author")]
        p["Authors"] = [x for x in p["Authors"] if x]
        for author, name in zip(a.findall("AuthorList/Author"), p["Authors"]):
            if author.get("CorrespondingAuthor", "").lower() in ("y", "yes", "true"):
                p["Corresponding_Author"] = name
        p["Journal"] = _txt(a, "Journal/Title") or _txt(a, "Journal/ISOAbbreviation")
        p["Volume"], p["Issue"] = _txt(a, "Journal/JournalIssue/Volume"), _txt(a, "Journal/JournalIssue/Issue")
        p["Pages"] = _txt(a, "Pagination/StartPage") or _txt(a, "Pagination/MedlinePgn")
        if _txt(a, "Pagination/EndPage"):
            p["Pages"] += "-" + _txt(a, "Pagination/EndPage")
        date = a.find("ArticleDate")
        if date is None:
            date = a.find("Journal/JournalIssue/PubDate")
        year = _txt(date, "Year") or (_txt(date, "MedlineDate")[:4])
        p["Year"] = _number(year)
        if p["Year"]:
            pieces = [str(p["Year"])]
            month = _txt(date, "Month")
            month_num = _number(month) or months.get(month[:3])
            if month_num:
                pieces.append(f"{month_num:02d}")
                day = _number(_txt(date, "Day"))
                if day:
                    pieces.append(f"{day:02d}")
            p["Publication_Date"] = "-".join(pieces)
        abstracts = []
        for segment in a.findall("Abstract/AbstractText"):
            content = "".join(segment.itertext()).strip()
            label = segment.get("Label")
            abstracts.append((label + ": " if label else "") + content)
        p["Abstract"] = "\n".join(abstracts)
        p["Author_Keywords"] = ["".join(x.itertext()).strip() for x in citation.findall("KeywordList/Keyword")]
        p["MeSH_Terms"] = [_txt(x, "DescriptorName") for x in citation.findall("MeshHeadingList/MeshHeading")]
        p["Publication_Type"] = [_txt(x, ".") for x in a.findall("PublicationTypeList/PublicationType")]
        for ident in article.findall("PubmedData/ArticleIdList/ArticleId") + a.findall("ELocationID"):
            kind = ident.get("IdType") or ident.get("EIdType")
            value = "".join(ident.itertext()).strip()
            if kind == "doi": p["DOI"] = value
            elif kind == "pmc": p["PMCID"] = value
        results.append(_finish(p))
    return results


def europe_record(a):
    p = _empty("Europe PMC")
    for field, name in {"Title":"title", "DOI":"doi", "PMCID":"pmcid", "Abstract":"abstractText", "Publication_Date":"firstPublicationDate", "Pages":"pageInfo"}.items():
        p[field] = plain(a.get(name))
    p["PMID"] = str(a.get("pmid") or (a.get("id") if a.get("source") == "MED" else "") or "")
    p["Year"] = _number(a.get("pubYear"))
    p["Authors"] = [x.get("fullName") or (str(x.get("firstName", "")) + " " + str(x.get("lastName", ""))).strip()
                    for x in (a.get("authorList") or {}).get("author", [])]
    if not p["Authors"] and a.get("authorString"):
        p["Authors"] = [x.strip() for x in a["authorString"].split(",") if x.strip()]
    ji = a.get("journalInfo") or {}
    j = ji.get("journal") or {}
    p["Journal"] = j.get("title") or j.get("medlineAbbreviation") or a.get("journalTitle") or ""
    p["Volume"], p["Issue"] = str(ji.get("volume") or ""), str(ji.get("issue") or "")
    p["Author_Keywords"] = (a.get("keywordList") or {}).get("keyword", [])
    p["MeSH_Terms"] = [x.get("descriptorName", "") for x in (a.get("meshHeadingList") or {}).get("meshHeading", [])]
    p["Citation_Count"] = _number(a.get("citedByCount"))
    if p["Citation_Count"] is not None: p["Citation_Source"] = "Europe PMC"
    links = (a.get("fullTextUrlList") or {}).get("fullTextUrl", [])
    # PMCID alone does not prove the paper is in the reusable OA subset.
    accessible = [x for x in links if x.get("availabilityCode") == "OA" or str(x.get("availability", "")).lower() in ("open access", "free")]
    pdf = next((x.get("url", "") for x in accessible if str(x.get("documentStyle", "")).lower() == "pdf"), "")
    html = next((x.get("url", "") for x in accessible if str(x.get("documentStyle", "")).lower() == "html"), "")
    is_oa = a.get("isOpenAccess") == "Y" or bool(accessible)
    if is_oa and p["PMCID"] and not html:
        html = "https://europepmc.org/articles/" + p["PMCID"]
    _oa(p, is_oa, html, pdf, source="Europe PMC")
    return _finish(p)


def crossref_record(a):
    p = _empty("Crossref")
    p["Title"] = plain((a.get("title") or [""])[0])
    p["Journal"] = plain((a.get("container-title") or [""])[0])
    p["Authors"] = [(str(x.get("given", "")) + " " + str(x.get("family", ""))).strip() or x.get("name", "") for x in a.get("author", [])]
    for field, key in {"DOI":"DOI", "Publisher":"publisher", "Volume":"volume", "Issue":"issue", "Pages":"page", "Abstract":"abstract"}.items():
        p[field] = plain(a.get(key))
    dates_known = []
    for key in ("published", "published-online", "published-print", "issued"):
        dates = (a.get(key) or {}).get("date-parts") or []
        if dates and dates[0]:
            dates_known.append(dates[0])
    # Online-first is often earlier than the print issue; metadata redeposits
    # must not make an old paper appear newly published.
    parts = min(dates_known, key=lambda x: tuple(x)) if dates_known else []
    if parts:
        p["Year"] = _number(parts[0])
        p["Publication_Date"] = "-".join(str(x) if i == 0 else f"{int(x):02d}" for i, x in enumerate(parts))
    p["Publisher_URL"] = (a.get("resource") or {}).get("primary", {}).get("URL") or a.get("URL") or ""
    p["Citation_Count"] = _number(a.get("is-referenced-by-count"))
    if p["Citation_Count"] is not None: p["Citation_Source"] = "Crossref"
    # Crossref subjects are taxonomy terms, not author keywords; fulltext links
    # are candidates and do not establish subscription or OA authorization.
    p["Subject_Terms"] = a.get("subject") or []
    p["Fulltext_Candidate_URLs"] = [x["URL"] for x in a.get("link", []) if x.get("URL")]
    return _finish(p)


def openalex_record(a):
    p = _empty("OpenAlex")
    p["Title"] = plain(a.get("title") or a.get("display_name"))
    p["DOI"], p["Year"], p["Publication_Date"] = a.get("doi") or "", a.get("publication_year"), a.get("publication_date") or ""
    authorships = a.get("authorships") or []
    p["Authors"] = [(x.get("author") or {}).get("display_name", "") for x in authorships]
    p["Corresponding_Author"] = "; ".join((x.get("author") or {}).get("display_name", "") for x in authorships if x.get("is_corresponding"))
    primary = a.get("primary_location") or {}
    source = primary.get("source") or {}
    p["Journal"], p["Publisher"] = source.get("display_name") or "", source.get("host_organization_name") or ""
    p["Publisher_URL"] = primary.get("landing_page_url") or ""
    ids = a.get("ids") or {}
    p["PMID"] = str(ids.get("pmid") or "").rstrip("/").rsplit("/", 1)[-1]
    p["PMCID"] = str(ids.get("pmcid") or "").rstrip("/").rsplit("/", 1)[-1]
    biblio = a.get("biblio") or {}
    p["Volume"], p["Issue"] = str(biblio.get("volume") or ""), str(biblio.get("issue") or "")
    p["Pages"] = str(biblio.get("first_page") or "")
    if biblio.get("last_page"):
        p["Pages"] += "-" + str(biblio["last_page"])
    index = a.get("abstract_inverted_index") or {}
    words = sorted((pos, word) for word, positions in index.items() for pos in positions)
    p["Abstract"] = " ".join(word for _, word in words)
    p["Citation_Count"] = _number(a.get("cited_by_count"))
    if p["Citation_Count"] is not None: p["Citation_Source"] = "OpenAlex"
    # OpenAlex keywords are algorithmic; never label them author keywords.
    p["Index_Keywords"] = [x.get("display_name", "") for x in a.get("keywords") or []]
    access = a.get("open_access") or {}
    best = a.get("best_oa_location") or {}
    _oa(p, access.get("is_oa"), best.get("landing_page_url") or access.get("oa_url") or "", best.get("pdf_url") or "",
        access.get("oa_status") or "", "OpenAlex", best.get("license") or "")
    return _finish(p)


def semantic_record(a):
    p = _empty("Semantic Scholar")
    p["Title"], p["Abstract"], p["Year"] = plain(a.get("title")), plain(a.get("abstract")), a.get("year")
    p["Authors"] = [x.get("name", "") for x in a.get("authors") or []]
    p["Publication_Date"] = a.get("publicationDate") or ""
    journal = a.get("journal") or {}
    p["Journal"] = journal.get("name") or a.get("venue") or ""
    p["Volume"], p["Pages"] = journal.get("volume") or "", journal.get("pages") or ""
    ids = a.get("externalIds") or {}
    p["DOI"], p["PMID"], p["PMCID"] = ids.get("DOI") or "", ids.get("PubMed") or "", ids.get("PubMedCentral") or ""
    p["Citation_Count"] = _number(a.get("citationCount"))
    if p["Citation_Count"] is not None: p["Citation_Source"] = "Semantic Scholar"
    access = a.get("openAccessPdf") or {}
    pdf = access.get("url") or ""
    if ids.get("ArXiv"):
        p["Arxiv_ID"] = ids["ArXiv"]
        pdf = pdf or "https://arxiv.org/pdf/" + ids["ArXiv"]
    _oa(p, True if pdf else a.get("isOpenAccess"), pdf=pdf, status=access.get("status") or "", source="Semantic Scholar")
    return _finish(p)


class Sources:
    def __init__(self, net, settings):
        self.net, self.settings = net, settings
        self.statuses = {}
        self._enrichment_cache = {}
        self._openalex_disabled = False

    def _get(self, url, params=None, **kwargs):
        response = self.net.get(url, params=params or {}, **kwargs)
        # The standard HTTP wrapper raises itself; also handle ordinary httpx.
        if hasattr(response, "raise_for_status"):
            response.raise_for_status()
        return response

    def _openalex_get(self, url, params):
        if self._openalex_disabled:
            raise SourceConfigurationError("OpenAlex quota/authentication exhausted; configure OPENALEX_API_KEY")
        key = getattr(self.settings, "openalex_api_key", "")
        if key:
            params = {**params, "api_key":key}
        try:
            return self._get(url, params)
        except Exception as exc:
            status = getattr(exc, "status_code", None) or getattr(getattr(exc, "response", None), "status_code", None)
            if status in (401, 403, 409, 429):
                self._openalex_disabled = True
                self.statuses["OpenAlex"] = "configuration_required: OPENALEX_API_KEY or quota/authentication review"
                raise SourceConfigurationError("OpenAlex quota/authentication exhausted; configure OPENALEX_API_KEY") from None
            raise

    @property
    def contact(self):
        return str(getattr(self.settings, "contact_email", "") or "").strip()

    def search(self, source, query, start_year, end_year, max_results, journal="", oa_only=False):
        aliases = {"pubmed":"PubMed", "europe pmc":"Europe PMC", "europepmc":"Europe PMC", "crossref":"Crossref", "openalex":"OpenAlex", "semantic scholar":"Semantic Scholar", "semanticscholar":"Semantic Scholar", "s2":"Semantic Scholar"}
        source = aliases.get(str(source).lower().strip(), source)
        if source == "Unpaywall":
            raise ValueError("Unpaywall enriches DOI records; it is not a keyword search engine")
        if source not in aliases.values():
            raise ValueError(f"Unsupported search source: {source}")
        start_year, end_year, max_results = int(start_year), int(end_year), int(max_results)
        if start_year < 1800 or end_year < start_year or end_year > 2200:
            raise ValueError("Invalid publication-year range")
        if max_results < 1 or max_results > 10000:
            raise ValueError("max_results must be between 1 and 10000")
        if source == "OpenAlex" and self._openalex_disabled:
            return []
        method = {"PubMed":self._pubmed, "Europe PMC":self._europe, "Crossref":self._crossref,
                  "OpenAlex":self._openalex, "Semantic Scholar":self._semantic}[source]
        try:
            records = method(str(query), start_year, end_year, max_results, str(journal), bool(oa_only))
            result = []
            for p in records:
                if journal and journal.casefold() not in str(p.get("Journal", "")).casefold(): continue
                if p.get("Year") is not None and not start_year <= int(p["Year"]) <= end_year: continue
                if oa_only and p.get("Open_Access") is not True:
                    p = self.enrich(p)
                    if p.get("Open_Access") is not True: continue
                result.append(p)
                if len(result) >= max_results: break
            self.statuses[source] = f"completed: {len(result)} records" + ("; anonymous limited quota; OPENALEX_API_KEY recommended" if source == "OpenAlex" and not getattr(self.settings, "openalex_api_key", "") else "")
            return result
        except SourceConfigurationError:
            return []
        except Exception as exc:
            # Exception strings may contain API keys in URLs. Expose types only.
            self.statuses[source] = "error: " + type(exc).__name__
            raise

    def _pubmed(self, query, start, end, limit, journal, oa):
        term = f"({query}) AND {start}:{end}[dp]"
        if journal: term += ' AND "' + journal.replace('"', ' ') + '"[Journal]'
        if oa: term += " AND free full text[filter]"
        base = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/"
        common = {"db":"pubmed", "email":self.contact, "tool":"LiteratureAI"}
        raw = self._get(base + "esearch.fcgi", {**common, "term":term, "retmode":"json", "retmax":limit, "sort":"pub date"}).json()
        ids = (raw.get("esearchresult") or {}).get("idlist") or []
        result = []
        for i in range(0, len(ids), 100):
            text = self._get(base + "efetch.fcgi", {**common, "id":",".join(ids[i:i+100]), "retmode":"xml", "rettype":"abstract"}).text
            result.extend(pubmed_xml(text))
        return result

    def _europe(self, query, start, end, limit, journal, oa):
        q = f"({query}) AND FIRST_PDATE:[{start}-01-01 TO {end}-12-31]"
        if journal: q += ' AND JOURNAL:"' + journal.replace('"', ' ') + '"'
        if oa: q += " AND OPEN_ACCESS:Y"
        result, cursor = [], "*"
        while len(result) < limit:
            data = self._get("https://www.ebi.ac.uk/europepmc/webservices/rest/search", {"query":q, "format":"json", "resultType":"core", "pageSize":min(1000, limit-len(result)), "cursorMark":cursor}).json()
            batch = (data.get("resultList") or {}).get("result") or []
            result.extend(europe_record(x) for x in batch)
            next_cursor = data.get("nextCursorMark")
            if not batch or not next_cursor or next_cursor == cursor: break
            cursor = next_cursor
        return result[:limit]

    def _crossref(self, query, start, end, limit, journal, oa):
        result, cursor = [], "*"
        # Crossref query is scored text rather than an NCBI boolean parser.
        text = re.sub(r'\b(?:AND|OR|NOT)\b|[()"]|\[[^]]+\]', " ", query)
        while len(result) < limit:
            params = {"query.title":re.sub(r"\s+", " ", text).strip(), "filter":f"from-pub-date:{start}-01-01,until-pub-date:{end}-12-31,type:journal-article", "sort":"score", "order":"desc", "rows":min(1000, limit-len(result)), "cursor":cursor}
            if self.contact: params["mailto"] = self.contact
            if journal: params["query.container-title"] = journal
            data = self._get("https://api.crossref.org/works", params).json().get("message") or {}
            batch = data.get("items") or []
            result.extend(crossref_record(x) for x in batch)
            next_cursor = data.get("next-cursor")
            if not batch or not next_cursor or next_cursor == cursor: break
            cursor = next_cursor
        return result[:limit]

    def _openalex(self, query, start, end, limit, journal, oa):
        result, cursor = [], "*"
        filters = f"from_publication_date:{start}-01-01,to_publication_date:{end}-12-31"
        if oa: filters += ",is_oa:true"
        while len(result) < limit:
            data = self._openalex_get("https://api.openalex.org/works", {"search":query, "filter":filters, "per_page":min(100, limit-len(result)), "cursor":cursor}).json()
            batch = data.get("results") or []
            result.extend(openalex_record(x) for x in batch)
            next_cursor = (data.get("meta") or {}).get("next_cursor")
            if not batch or not next_cursor or next_cursor == cursor: break
            cursor = next_cursor
        return result[:limit]

    def _semantic(self, query, start, end, limit, journal, oa):
        result, offset = [], 0
        key = getattr(self.settings, "s2_api_key", "")
        headers = {"x-api-key":key} if key else {}
        while len(result) < min(limit, 1000):
            params = {"query":re.sub(r'\b(?:AND|OR|NOT)\b|[()"]', " ", query), "year":f"{start}-{end}", "limit":min(100, limit-len(result)), "offset":offset,
                      "fields":"title,authors,year,abstract,citationCount,externalIds,openAccessPdf,venue,journal,publicationDate,isOpenAccess"}
            if oa: params["openAccessPdf"] = ""
            data = self._get("https://api.semanticscholar.org/graph/v1/paper/search", params, headers=headers).json()
            batch = data.get("data") or []
            result.extend(semantic_record(x) for x in batch)
            nxt = data.get("next")
            if not batch or nxt is None or int(nxt) <= offset: break
            offset = int(nxt)
        return result[:limit]

    def enrich(self, paper):
        p = dict(paper)
        doi = doi_normalize(p.get("DOI"))
        if not doi: return p
        p["DOI"], p["DOI_URL"] = doi, "https://doi.org/" + doi
        if doi in self._enrichment_cache:
            enrichment = self._enrichment_cache[doi]
        else:
            enrichment, statuses, errors = {}, {}, {}
            if not self._openalex_disabled:
                try:
                    data = self._openalex_get("https://api.openalex.org/works/https://doi.org/" + quote(doi, safe=""), {}).json()
                    if doi_normalize(data.get("doi")) != doi:
                        raise ValueError("DOI mismatch")
                    enrichment = openalex_record(data)
                    statuses["OpenAlex"] = "completed"
                except SourceConfigurationError:
                    statuses["OpenAlex"] = "configuration_required: OPENALEX_API_KEY or quota/authentication review"
                except Exception as exc:
                    statuses["OpenAlex"] = "error"; errors["OpenAlex"] = type(exc).__name__
            else:
                statuses["OpenAlex"] = "configuration_required: OPENALEX_API_KEY"
            if self.contact and "@" in self.contact:
                try:
                    data = self._get("https://api.unpaywall.org/v2/" + quote(doi, safe=""), {"email":self.contact}).json()
                    if doi_normalize(data.get("doi")) != doi:
                        raise ValueError("DOI mismatch")
                    location = data.get("best_oa_location") or {}
                    # Preserve independent positive OA evidence if another index
                    # is behind. Conflicting status is explicitly retained.
                    if data.get("is_oa") is True or enrichment.get("Open_Access") is not True:
                        _oa(enrichment, data.get("is_oa"), location.get("url_for_landing_page") or location.get("url") or "",
                            location.get("url_for_pdf") or "", data.get("oa_status") or "", "Unpaywall", location.get("license") or "")
                    enrichment["Unpaywall_Is_OA"] = data.get("is_oa")
                    enrichment["Unpaywall_OA_Status"] = data.get("oa_status") or "unknown"
                    enrichment["OA_Locations"] = data.get("oa_locations") or []
                    sources = enrichment.get("Metadata_Source") or []
                    enrichment["Metadata_Source"] = list(dict.fromkeys(sources + ["Unpaywall"]))
                    statuses["Unpaywall"] = "completed"
                except Exception as exc:
                    statuses["Unpaywall"] = "error"; errors["Unpaywall"] = type(exc).__name__
            else:
                statuses["Unpaywall"] = "configuration_required: CONTACT_EMAIL"
            enrichment["Enrichment_Status"], enrichment["Enrichment_Errors"] = statuses, errors
            self._enrichment_cache[doi] = enrichment
        # Bibliographic fields fill gaps; trust existing source title/authors.
        protected = {"Metadata_Source", "Metadata_Provenance", "Search_Source"}
        provenance = dict(p.get("Metadata_Provenance") or {})
        extra_provenance = enrichment.get("Metadata_Provenance") or {}
        oa_fields = {"Open_Access", "OA_Status", "OA_License", "OA_Evidence_Source", "Open_Access_URL", "PDF_URL", "Full_Text_Status", "OA_Locations"}
        for key, value in enrichment.items():
            if key in protected or value in (None, "", [], {}): continue
            if key in oa_fields:
                if enrichment.get("Open_Access") is True or p.get("Open_Access") is not True:
                    p[key] = value
                    if key in extra_provenance: provenance[key] = extra_provenance[key]
            elif key not in p or p[key] in (None, "", [], {}):
                p[key] = value
                if key in extra_provenance: provenance[key] = extra_provenance[key]
            elif key.startswith(("Enrichment_", "Unpaywall_")):
                p[key] = value
        sources = p.get("Metadata_Source") or []
        if isinstance(sources, str): sources = [sources]
        p["Metadata_Source"] = list(dict.fromkeys(sources + (enrichment.get("Metadata_Source") or [])))
        p["Metadata_Provenance"] = provenance
        return p
