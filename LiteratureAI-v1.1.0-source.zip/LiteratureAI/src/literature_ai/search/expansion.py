"""Deterministic, reviewable bilingual query expansion; no API key required."""
from __future__ import annotations

import re

GROUPS = {
    "senescence": ["cellular senescence", "senescent cells", "senescence"],
    "immune": ["immune clearance", "immune surveillance", "immune evasion", "senescent cell clearance", "immune escape"],
    "autophagy": ["autophagy", "autophagic flux", "lysosome", "lysosomal function"],
    "mitochondria": ["mitochondria", "mitochondrial dysfunction", "mitochondrial ROS"],
    "sasp": ["SASP", "senescence-associated secretory phenotype"],
    "ferroptosis": ["ferroptosis", "iron-dependent cell death", "lipid peroxidation"],
    "probe": ["fluorescent probe", "fluorescence imaging", "near-infrared probe", "enzyme-responsive probe"],
    "nanomaterial": ["nanomaterials", "nanomedicine", "nanoparticles"],
    "nad": ["NAD metabolism", "NAD+", "nicotinamide adenine dinucleotide"],
    "ecm": ["ECM remodeling", "extracellular matrix", "matrix remodeling"],
    "peptide": ["peptide", "targeting peptide", "peptide conjugate"],
}
TRIGGERS = {
    "senescence": r"senescen|衰老", "immune": r"immun|clearance|surveillance|escape|免疫|清除|逃逸",
    "autophagy": r"autophag|lysosom|自噬|溶酶体", "mitochondria": r"mitochond|线粒体",
    "sasp": r"\bsasp\b|secretory phenotype|分泌表型", "ferroptosis": r"ferropt|铁死亡",
    "probe": r"probe|fluorescen|near.infrared|探针|荧光|近红外",
    "nanomaterial": r"nano|纳米", "nad": r"\bnad\b|烟酰胺", "ecm": r"\becm\b|extracellular matrix|细胞外基质|基质重塑",
    "peptide": r"peptide|多肽",
}
TRANSLATIONS = {
    "细胞衰老": "cellular senescence", "衰老": "senescence", "免疫清除": "immune clearance",
    "免疫逃逸": "immune evasion", "免疫监视": "immune surveillance", "自噬": "autophagy",
    "溶酶体": "lysosome", "线粒体": "mitochondria", "铁死亡": "ferroptosis", "凋亡": "apoptosis",
    "持续性衰老": "persistent senescence", "慢性衰老": "chronic senescence", "早期衰老": "early senescence",
    "皮肤衰老": "skin aging", "癌症": "cancer", "荧光探针": "fluorescent probe",
    "近红外探针": "near-infrared probe", "纳米材料": "nanomaterials", "多肽": "peptide",
    "酶响应": "enzyme-responsive", "蛋白响应": "protein-responsive", "疾病诊断": "disease diagnosis",
    "代谢重编程": "metabolic reprogramming", "代谢": "metabolism", "重塑": "remodeling",
}


def expand(keyword: str) -> dict:
    original = re.sub(r"\s+", " ", str(keyword or "")).strip()
    if not original:
        raise ValueError("keyword must not be empty")
    if len(original) > 2000:
        raise ValueError("keyword must be at most 2000 characters")
    translated = original
    for cn in sorted(TRANSLATIONS, key=len, reverse=True):
        translated = translated.replace(cn, " " + TRANSLATIONS[cn] + " ")
    translated = re.sub(r"\s+", " ", translated).strip()
    active = [name for name, pattern in TRIGGERS.items() if re.search(pattern, original, re.I)]
    keywords = [original]
    if translated != original:
        keywords.append(translated)
    for name in active:
        keywords.extend(GROUPS[name])
    if "senescence" in active and "immune" in active:
        keywords.extend(["NK cell senescence", "macrophage senescence", "persistent senescence"])
    keywords = list(dict.fromkeys(keywords))
    # Original explicit boolean/field syntax is preserved. Expanded groups are
    # alternatives within each concept, while concepts remain joined by AND.
    explicit = bool(re.search(r"\b(?:AND|OR|NOT)\b|\[[^]]+\]", translated))
    quote = lambda value: '"' + value.replace('"', ' ') + '"'
    if explicit or not active:
        boolean = translated
    else:
        groups = ["(" + " OR ".join(map(quote, GROUPS[name])) + ")" for name in active]
        # Keep specific disease/model modifiers so expansion does not erase intent.
        remainder = translated
        for phrase in sorted([p for name in active for p in GROUPS[name]], key=len, reverse=True):
            remainder = re.sub(re.escape(phrase), " ", remainder, flags=re.I)
        for name in active:
            remainder = re.sub(TRIGGERS[name], " ", remainder, flags=re.I)
        if "senescence" in active:
            remainder = re.sub(r"\b(?:cellular|cells?|senescent)\b", " ", remainder, flags=re.I)
        if "immune" in active:
            remainder = re.sub(r"\b(?:immune|immunological|evasion)\b", " ", remainder, flags=re.I)
        remainder = re.sub(r"\b(?:of|the|and|in|with|for|to|a|an)\b", " ", remainder, flags=re.I)
        modifiers = re.findall(r"[\w+.-]+", remainder)
        boolean = " AND ".join(groups + [quote(x) for x in dict.fromkeys(modifiers)])
    queries = [translated, boolean]
    if "senescence" in active and "immune" in active:
        complement = '( "senescent cells" OR "cellular senescence" ) AND ( "NK cells" OR macrophages )'
        if not explicit and active:
            complement += "".join(" AND " + quote(x) for x in dict.fromkeys(modifiers))
        queries.append(complement)
    elif len(active) > 1:
        queries.append(GROUPS[active[0]][0] + " " + GROUPS[active[1]][0])
    return {"keywords": keywords, "boolean_query": boolean, "queries": list(dict.fromkeys(queries))}
