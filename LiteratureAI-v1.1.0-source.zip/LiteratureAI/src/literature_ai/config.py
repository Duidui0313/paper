import os
from pathlib import Path
from dataclasses import dataclass
from dotenv import load_dotenv, dotenv_values

ROOT = Path(os.getenv("LITERATUREAI_HOME") or Path.cwd() / "LiteratureAI_Data").expanduser().resolve()
for name in (".cache/pip", ".cache/uv", ".playwright", "browser_profile", "config", "data", "library/notes", "exports", "weekly_reports", "downloads_tmp", "logs/weekly"):
    (ROOT / name).mkdir(parents=True, exist_ok=True)
os.environ["PIP_CACHE_DIR"] = str(ROOT / ".cache/pip")
os.environ["UV_CACHE_DIR"] = str(ROOT / ".cache/uv")
os.environ["PLAYWRIGHT_BROWSERS_PATH"] = str(ROOT / ".playwright")
os.environ["TEMP"] = str(ROOT / "downloads_tmp")
os.environ["TMP"] = str(ROOT / "downloads_tmp")
load_dotenv(ROOT / ".env", override=False)
# Explicit non-empty project settings take precedence over inherited shell values.
for key,value in dotenv_values(ROOT / ".env").items():
    if value:
        os.environ[key]=value

def openai_key_available():
    value=os.getenv("OPENAI_API_KEY","").strip()
    return bool(value) and value.isascii() and not any(c.isspace() for c in value)

@dataclass
class Settings:
    root: Path = ROOT
    contact_email: str = os.getenv("CONTACT_EMAIL", "")
    openalex_api_key: str = os.getenv("OPENALEX_API_KEY", "")
    s2_api_key: str = os.getenv("SEMANTIC_SCHOLAR_API_KEY", "")
    network_interval: float = max(1, min(3, float(os.getenv("NETWORK_INTERVAL", "2"))))
    max_pdf_mb: int = int(os.getenv("MAX_PDF_MB", "100"))

settings = Settings()
