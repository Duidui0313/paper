import json
import re
import logging
from pathlib import Path
from literature_ai.config import settings
from literature_ai.utils.network import Network
from literature_ai.database.store import Store
from literature_ai.search.sources import Sources
from literature_ai.search.expansion import expand
from literature_ai.download.downloader import Downloader
from literature_ai.parser.pdf import parse_paper
from literature_ai.analysis.analyzer import analyze_paper
from literature_ai.export.outputs import write_note, missing_information
from literature_ai.utils.common import now

class Pipeline:
    def __init__(self,store=None):
        self.store=store or Store(); self.net=Network(); self.sources=Sources(self.net,settings)
        self.downloader=Downloader(self.net,self.store,self.sources)

    def close(self):
        self.net.close(); self.store.close()

    def search(self,keyword,start_year=2021,end_year=2026,max_results=100,journal="",oa_only=False,download=False,analyze=False,persist=True):
        if not keyword.strip() or start_year>end_year or not 1<=max_results<=1000:
            raise ValueError("关键词不能为空，年份顺序须正确，max为1-1000")
        expansion=expand(keyword)
        sources=["PubMed","Europe PMC","Crossref","OpenAlex"]
        if settings.s2_api_key: sources.append("Semantic Scholar")
        candidates=Store(":memory:")
        found={}
        for source in sources:
            logging.getLogger("LiteratureAI.weekly").info("search source=%s started",source)
            query=expansion["boolean_query"] if source in {"PubMed","Europe PMC"} else expansion["queries"][0]
            try:
                results=self.sources.search(source,query,start_year,end_year,max_results,journal,oa_only)
                status=getattr(self.sources,"statuses",{}).get(source,"completed")
                logging.getLogger("LiteratureAI.weekly").info("search source=%s status=%s count=%s",source,status,len(results))
                parameters={"start_year":start_year,"end_year":end_year,"max_results":max_results,"journal":journal,"open_access_only":oa_only}
                self.store.record_search(keyword,expansion["keywords"],query,source,status,{"count":len(results),"parameters":parameters})
                for p in results:
                    try: year=int(p.get("Year") or 0)
                    except (ValueError,TypeError): continue
                    if not start_year<=year<=end_year or (journal and journal.lower() not in p.get("Journal","").lower()): continue
                    if oa_only and not p.get("Open_Access"): continue
                    p["Original_Search_Query"] = keyword
                    p["Search_Queries"]=[keyword]
                    p["Search_Provenance"]=[{"Original_Search_Query":keyword,"Final_Search_Query":query,"Search_Source":source,"Search_Time":now(),"Parameters":parameters}]
                    haystack=(p.get("Title","")+" "+p.get("Abstract","")).lower()
                    p["Matched_Keywords"]=[word for word in expansion["keywords"] if word.lower() in haystack]
                    p["Expanded_Keywords"]=expansion["keywords"]
                    suggestions=list(dict.fromkeys([*(p.get("Author_Keywords") or []),*expansion["keywords"]]))[:15]
                    p["Generated_Keywords"]=suggestions
                    p["Recommended_Search_Keywords"]=expansion["keywords"][:15]
                    p["Related_Search_Keywords"]=expansion["keywords"][-15:]
                    p["Keyword_Generation_Method"]="rule-based search candidates; not scientific findings"
                    tokens=set(re.findall(r"[a-zA-Z0-9]+",keyword.lower()))-{"cell","cells","cellular","and","or","the"}
                    overlap=sum(token in haystack for token in tokens)
                    if tokens and not overlap:
                        continue
                    if re.search(r"senescen|衰老",keyword,re.I) and not re.search(r"senescen|aging|ageing",haystack):
                        continue
                    p["Search_Relevance"] = len(p["Matched_Keywords"])*2+overlap
                    stored=candidates.upsert(p)
                    found[stored["id"]]=stored
            except Exception as exc:
                logging.getLogger("LiteratureAI.weekly").warning("search source=%s failed=%s",source,type(exc).__name__)
                self.store.record_search(keyword,expansion["keywords"],query,source,"failed",{"failure_reason":type(exc).__name__})
        # Merge all sources before selecting the requested maximum.
        papers=sorted(candidates.papers(),key=lambda p:(p.get("Search_Relevance",0),bool(p.get("Abstract")),p.get("Year",0)),reverse=True)[:max_results]
        candidates.close()
        papers=[self.store.upsert({k:v for k,v in p.items() if k not in {"id","created_at","updated_at","last_checked_at","metadata_status","download_status","parse_status","analysis_status","weekly_status","PDF_Local_Path"}}) for p in papers]
        if persist:
            self.save_query({"keyword":keyword,"start_year":start_year,"end_year":end_year,"max_results":max_results,"journal":journal,"oa_only":oa_only})
        output=[]
        for p in papers:
            if download or analyze: p=self.downloader.fetch(p)
            if p.get("download_status")=="downloaded" and p.get("parse_status")!="parsed": p=parse_paper(p,self.store)
            if analyze: p=analyze_paper(p,self.store)
            write_note(p,self.store); output.append(p)
        return output

    def save_query(self,query):
        path=settings.root / "config/saved_searches.json"
        data=json.loads(path.read_text(encoding="utf-8")) if path.exists() else []
        if query not in data:
            data.append(query); path.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding="utf-8")

    def update_all(self):
        for p in self.store.papers():
            logging.getLogger("LiteratureAI.weekly").info("checking paper_id=%s",p["id"])
            if not p.get("DOI") or not p.get("Abstract"):
                try:
                    candidates=self.sources.search("Crossref",p["Title"],max(1900,int(p.get("Year") or 2021)-1),min(2100,int(p.get("Year") or 2026)+1),3)
                    from rapidfuzz.fuzz import ratio
                    from literature_ai.utils.common import normalized_title
                    for c in candidates:
                        if ratio(normalized_title(p["Title"]),normalized_title(c["Title"]))>=95 and (not p.get("DOI") or not c.get("DOI") or p["DOI"]==c["DOI"]):
                            p=self.store.upsert({**c,"id":p["id"]}); break
                    if not p.get("Abstract") and p.get("DOI"):
                        c=self.sources.search("Europe PMC",'DOI:"'+p["DOI"]+'"',1900,2100,1)
                        if c: p=self.store.upsert({**c[0],"id":p["id"]})
                except Exception:
                    pass
            if p.get("download_status")!="downloaded": p=self.downloader.fetch(p)
            if p.get("download_status")=="downloaded" and (p.get("parse_status")!="parsed" or not p.get("Fulltext_Path")): p=parse_paper(p,self.store)
            if p.get("analysis_status")!="complete": p=analyze_paper(p,self.store)
            p["Missing_Information"] = (missing_information(p,self.store) or {}).get("Missing_Fields","")
            p["metadata_status"]="complete" if p.get("DOI") and p.get("Abstract") else "incomplete"
            p=self.store.upsert(p); write_note(p,self.store)
            logging.getLogger("LiteratureAI.weekly").info("checked paper_id=%s download=%s parse=%s analysis=%s",p["id"],p["download_status"],p["parse_status"],p["analysis_status"])

    def weekly_update(self):
        path=settings.root / "config/saved_searches.json"
        queries=json.loads(path.read_text(encoding="utf-8")) if path.exists() else []
        for query in queries:
            query=dict(query); query["max_results"]=min(query["max_results"],int(__import__("os").getenv("WEEKLY_MAX_RESULTS","20")))
            try: self.search(**query,persist=False)
            except Exception: pass
        self.update_all()
