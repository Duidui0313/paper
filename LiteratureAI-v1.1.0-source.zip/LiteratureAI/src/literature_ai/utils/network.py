import time
import threading
from urllib.parse import urlparse
from email.utils import parsedate_to_datetime
from datetime import datetime, timezone
import httpx
from literature_ai.config import settings

class NetworkError(RuntimeError):
    def __init__(self,reason,status_code=None):
        super().__init__(reason)
        self.status_code=status_code

class Network:
    def __init__(self, transport=None):
        self.client = httpx.Client(timeout=httpx.Timeout(25, connect=10), follow_redirects=False,
            headers={"User-Agent": f"LiteratureAI/1.0 (mailto:{settings.contact_email})"}, transport=transport)
        self.last = {}
        self.lock = threading.Lock()

    def wait(self, url):
        domain = urlparse(url).netloc
        with self.lock:
            delay = settings.network_interval - (time.monotonic()-self.last.get(domain,0))
            if delay > 0:
                time.sleep(delay)
            self.last[domain] = time.monotonic()

    def get(self, url, params=None, headers=None, max_bytes=None):
        if urlparse(url).scheme not in {"http", "https"}:
            raise NetworkError("unsupported_url")
        deadline=time.monotonic()+90
        for attempt in range(4):
            if time.monotonic()>deadline:
                raise NetworkError("request_time_budget_exceeded")
            try:
                current, current_params = url, params
                for redirect in range(8):
                    self.wait(current)
                    with self.client.stream("GET", current, params=current_params, headers=headers) as response:
                        if response.status_code in {301,302,303,307,308}:
                            current = str(response.url.join(response.headers["location"]))
                            current_params = None
                            continue
                        content = bytearray()
                        for chunk in response.iter_bytes():
                            if time.monotonic()>deadline:
                                raise NetworkError("request_time_budget_exceeded")
                            content.extend(chunk)
                            if len(content) > (max_bytes or 30*1024*1024):
                                raise NetworkError("response_too_large")
                        # iter_bytes has already decoded gzip/br; remove wire encoding
                        # before constructing the in-memory response to avoid decoding twice.
                        decoded_headers={k:v for k,v in response.headers.items() if k.lower() not in {"content-encoding","content-length","transfer-encoding"}}
                        r = httpx.Response(response.status_code, headers=decoded_headers, content=bytes(content), request=response.request)
                    break
                else:
                    raise NetworkError("redirect_limit")
                if r.status_code == 403:
                    raise NetworkError("publisher_blocked",403)
                if r.status_code in {401,402}:
                    raise NetworkError("login_required",r.status_code)
                if r.status_code == 429 or r.status_code >= 500:
                    if attempt == 3:
                        raise NetworkError(f"http_{r.status_code}",r.status_code)
                    retry = r.headers.get("retry-after", "")
                    try:
                        delay = float(retry)
                    except ValueError:
                        try:
                            delay = (parsedate_to_datetime(retry)-datetime.now(timezone.utc)).total_seconds()
                        except (ValueError,TypeError):
                            delay = 2**(attempt+1)
                    wait_for=max(2**(attempt+1),delay)
                    if wait_for>60 or time.monotonic()+wait_for>deadline:
                        raise NetworkError("retry_after_exceeds_run_budget",r.status_code)
                    time.sleep(wait_for)
                    continue
                if r.status_code >= 400:
                    raise NetworkError(f"http_{r.status_code}",r.status_code)
                return r
            except (httpx.TimeoutException, httpx.NetworkError) as exc:
                if attempt == 3:
                    raise NetworkError("network_error") from None
                time.sleep(2**(attempt+1))
        raise NetworkError("network_error")

    def close(self):
        self.client.close()
