import re
import json
import hashlib
from datetime import datetime, timedelta
from zoneinfo import ZoneInfo
from pathlib import Path

TZ = ZoneInfo("Asia/Shanghai")
MISSING = "Not explicitly reported"

def now():
    return datetime.now(TZ).isoformat(timespec="seconds")

def dumps(value):
    return json.dumps(value, ensure_ascii=False, default=str)

def normalized_title(title):
    return re.sub(r"[^\w]", "", (title or "").lower())

def normalize_doi(doi):
    return re.sub(r"^(?:https?://(?:dx\.)?doi\.org/|doi:\s*)", "", (doi or "").strip(), flags=re.I).lower().rstrip(".")

def safe_name(value, length=70):
    value = re.sub(r'[\\/:*?"<>|\x00-\x1f]', "_", str(value or "unknown"))
    value = re.sub(r"\s+", "_", value).strip(" ._")[:length]
    if value.upper() in {"CON", "PRN", "AUX", "NUL", *[f"COM{i}" for i in range(1,10)], *[f"LPT{i}" for i in range(1,10)]}:
        value = "_" + value
    return value or "unknown"

def stem(paper, pdf=False):
    author = str(paper.get("First_Author") or "unknown").split()[0]
    parts = [str(paper.get("Year") or "unknown"), safe_name(author,20)]
    if pdf:
        parts.append(safe_name(paper.get("Journal"),25))
    parts.append(safe_name(paper.get("Title"),65))
    parts.append(safe_name(paper.get("DOI") or hashlib.sha256(paper.get("Title", "").encode()).hexdigest()[:10],45))
    return "_".join(parts)

def atomic_text(path, text):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(text, encoding="utf-8")
    tmp.replace(path)

def report_period(at=None):
    at = at or datetime.now(TZ)
    end = (at - timedelta(days=(at.weekday()-5)%7)).replace(hour=13, minute=0, second=0, microsecond=0)
    if end > at:
        end -= timedelta(days=7)
    return end-timedelta(days=7), end

def next_run(at=None):
    at = at or datetime.now(TZ)
    end = (at + timedelta(days=(5-at.weekday())%7)).replace(hour=13, minute=0, second=0, microsecond=0)
    return end if end > at else end+timedelta(days=7)
