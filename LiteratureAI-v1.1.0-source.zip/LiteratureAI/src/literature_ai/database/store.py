import sqlite3
import json
from copy import deepcopy
from pathlib import Path
from rapidfuzz.fuzz import ratio
from literature_ai.config import settings
from literature_ai.utils.common import now, dumps, normalize_doi, normalized_title

ENTITY_TABLES = ("pathways", "proteins", "enzymes", "abbreviations", "mechanisms", "innovations", "evidence")


def merge_unique(previous, incoming):
    """Keep source order and support JSON objects as well as scalar list items."""
    values = list(previous) if isinstance(previous, list) else []
    for value in incoming:
        if not any(value == existing for existing in values):
            values.append(deepcopy(value))
    return values

class Store:
    def __init__(self, path=None):
        self.path = Path(path or settings.root / "data/literature.db")
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.conn = sqlite3.connect(self.path, timeout=30, check_same_thread=False)
        self.conn.row_factory = sqlite3.Row
        self.conn.execute("PRAGMA foreign_keys=ON")
        self.conn.execute("PRAGMA journal_mode=WAL")
        self.conn.executescript('''
        CREATE TABLE IF NOT EXISTS papers(id INTEGER PRIMARY KEY, DOI TEXT UNIQUE, Title TEXT NOT NULL,
          normalized_title TEXT NOT NULL, Year INTEGER, metadata_status TEXT DEFAULT 'incomplete',
          download_status TEXT DEFAULT 'pending', parse_status TEXT DEFAULT 'pending', analysis_status TEXT DEFAULT 'pending',
          weekly_status TEXT DEFAULT 'new', created_at TEXT NOT NULL, updated_at TEXT NOT NULL, last_checked_at TEXT,
          PDF_Local_Path TEXT, payload TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS search_history(id INTEGER PRIMARY KEY, Original_Search_Query TEXT,
          Expanded_Keywords TEXT, Final_Search_Query TEXT, Search_Source TEXT, Search_Time TEXT, status TEXT, payload TEXT);
        CREATE TABLE IF NOT EXISTS authors(id INTEGER PRIMARY KEY, paper_id INTEGER REFERENCES papers(id), Name TEXT, payload TEXT);
        CREATE TABLE IF NOT EXISTS keywords(id INTEGER PRIMARY KEY, paper_id INTEGER REFERENCES papers(id), Name TEXT, Type TEXT, payload TEXT);
        CREATE TABLE IF NOT EXISTS downloads(id INTEGER PRIMARY KEY, paper_id INTEGER REFERENCES papers(id), time TEXT, status TEXT, failure_reason TEXT, payload TEXT);
        CREATE TABLE IF NOT EXISTS analysis(id INTEGER PRIMARY KEY, paper_id INTEGER UNIQUE REFERENCES papers(id), status TEXT, payload TEXT);
        CREATE TABLE IF NOT EXISTS changes(id INTEGER PRIMARY KEY, paper_id INTEGER REFERENCES papers(id), time TEXT, fields TEXT);
        CREATE TABLE IF NOT EXISTS weekly_runs(id INTEGER PRIMARY KEY, started_at TEXT, ended_at TEXT, status TEXT, report_path TEXT, email_status TEXT, payload TEXT);
        CREATE TABLE IF NOT EXISTS email_history(id INTEGER PRIMARY KEY, weekly_run_id INTEGER REFERENCES weekly_runs(id), time TEXT, status TEXT, failure_reason TEXT, payload TEXT);
        ''')
        for table in ENTITY_TABLES:
            self.conn.execute(f'''CREATE TABLE IF NOT EXISTS {table}(id INTEGER PRIMARY KEY, paper_id INTEGER REFERENCES papers(id),
              Source_DOI TEXT, Evidence_Text TEXT, Evidence_Section TEXT, Evidence_Page INTEGER,
              Explicitly_Reported TEXT, Inferred TEXT, payload TEXT)''')
        self.conn.commit()

    def close(self):
        self.conn.close()

    def papers(self):
        return [self._paper(r) for r in self.conn.execute("SELECT * FROM papers ORDER BY id")]

    def _paper(self, r):
        p = json.loads(r["payload"])
        p.update({k:r[k] for k in r.keys() if k not in {"payload","normalized_title"}})
        p["DOI"] = p.get("DOI") or ""
        return p

    def get(self, paper_id):
        r = self.conn.execute("SELECT * FROM papers WHERE id=?", (paper_id,)).fetchone()
        return self._paper(r) if r else None

    def upsert(self, incoming):
        # A rejected merge must never leave partial metadata or change events behind.
        with self.conn:
            return self._upsert(incoming)

    def _upsert(self, incoming):
        p = deepcopy(incoming)
        p["DOI"] = normalize_doi(p.get("DOI"))
        title = normalized_title(p.get("Title"))
        if not title:
            raise ValueError("Missing Title")
        old = self.get(p["id"]) if p.get("id") else None
        if p.get("id") and not old:
            raise ValueError("Unknown paper id")
        if old and p["DOI"]:
            if old.get("DOI") and old["DOI"] != p["DOI"]:
                raise ValueError("Conflicting DOI for existing paper")
            owner = self.conn.execute("SELECT id FROM papers WHERE DOI=?", (p["DOI"],)).fetchone()
            if owner and owner[0] != old["id"]:
                raise ValueError("DOI already belongs to a different paper")
        if not old and p["DOI"]:
            r = self.conn.execute("SELECT id FROM papers WHERE DOI=?",(p["DOI"],)).fetchone()
            old = self.get(r[0]) if r else None
        if not old:
            for candidate in self.papers():
                if p["DOI"] and candidate["DOI"] and p["DOI"] != candidate["DOI"]:
                    continue
                if p.get("Year") and candidate.get("Year") and abs(int(p["Year"])-int(candidate["Year"])) > 1:
                    continue
                if ratio(title, normalized_title(candidate["Title"])) >= 95:
                    old = candidate
                    break
        timestamp = now()
        if old:
            merged = dict(old)
            changed = []
            for key,value in p.items():
                clearable={"Download_Failure_Reason","Analysis_Failure_Reason","Analysis_Pending_Reason","Parse_Failure_Reason","Missing_Information","Enrichment_Errors"}
                if key in {"id","created_at","updated_at","last_checked_at"} or (value in (None,"",[],{}) and key not in clearable):
                    continue
                previous = merged.get(key)
                if isinstance(value,list) and key not in {"Parsed_Sections","OCR_candidate_pages"}:
                    value = merge_unique(previous, value)
                elif key in {"Title","Abstract","Authors"} and previous and len(str(previous)) > len(str(value)):
                    continue
                if previous != value:
                    merged[key] = value
                    changed.append(key)
            merged["last_checked_at"] = timestamp
            metadata_status = "complete" if merged.get("DOI") and merged.get("Abstract") else "incomplete"
            if merged.get("metadata_status") != metadata_status:
                merged["metadata_status"] = metadata_status
                changed.append("metadata_status")
            if changed:
                merged["updated_at"] = timestamp
                merged["weekly_status"] = "updated"
                self.conn.execute("INSERT INTO changes(paper_id,time,fields) VALUES(?,?,?)",(old["id"],timestamp,dumps(changed)))
            self._write(merged)
            p = merged
        else:
            p.update(created_at=timestamp,updated_at=timestamp,last_checked_at=timestamp)
            p.setdefault("metadata_status", "complete" if p.get("DOI") and p.get("Abstract") else "incomplete")
            for key in ("download_status","parse_status","analysis_status"):
                p.setdefault(key,"pending")
            p.setdefault("weekly_status","new")
            cur = self.conn.execute("INSERT INTO papers(DOI,Title,normalized_title,Year,created_at,updated_at,payload) VALUES(?,?,?,?,?,?,?)",
              (p["DOI"] or None,p["Title"],title,p.get("Year"),timestamp,timestamp,dumps(p)))
            p["id"] = cur.lastrowid
            self._write(p)
        self.conn.execute("DELETE FROM authors WHERE paper_id=?",(p["id"],))
        for author in p.get("Authors",[]) if isinstance(p.get("Authors"),list) else [p.get("Authors","")]:
            if author:
                self.conn.execute("INSERT INTO authors(paper_id,Name,payload) VALUES(?,?,?)",(p["id"],author,dumps({"Name":author})))
        self.conn.execute("DELETE FROM keywords WHERE paper_id=?",(p["id"],))
        for kind in ("Author_Keywords","Matched_Keywords","Generated_Keywords","Recommended_Search_Keywords","Related_Search_Keywords"):
            for word in p.get(kind,[]) if isinstance(p.get(kind),list) else []:
                self.conn.execute("INSERT INTO keywords(paper_id,Name,Type,payload) VALUES(?,?,?,?)",(p["id"],word,kind,dumps({"Name":word,"Type":kind})))
        return self.get(p["id"])

    def _write(self,p):
        self.conn.execute('''UPDATE papers SET DOI=?,Title=?,normalized_title=?,Year=?,metadata_status=?,download_status=?,parse_status=?,
          analysis_status=?,weekly_status=?,created_at=?,updated_at=?,last_checked_at=?,PDF_Local_Path=?,payload=? WHERE id=?''',
          (p.get("DOI") or None,p["Title"],normalized_title(p["Title"]),p.get("Year"),*[p.get(k,"pending") for k in
            ("metadata_status","download_status","parse_status","analysis_status","weekly_status")],p["created_at"],p["updated_at"],p.get("last_checked_at"),p.get("PDF_Local_Path"),dumps(p),p["id"]))

    def record_search(self, original, expanded, final, source, status, details):
        self.conn.execute("INSERT INTO search_history(Original_Search_Query,Expanded_Keywords,Final_Search_Query,Search_Source,Search_Time,status,payload) VALUES(?,?,?,?,?,?,?)",
            (original,dumps(expanded),final,source,now(),status,dumps(details)))
        self.conn.commit()

    def record_download(self,p,status,reason="",url=""):
        self.conn.execute("INSERT INTO downloads(paper_id,time,status,failure_reason,payload) VALUES(?,?,?,?,?)",
          (p["id"],now(),status,reason,dumps({"Title":p["Title"],"DOI":p.get("DOI"),"URL":url,"PDF_Local_Path":p.get("PDF_Local_Path","")})))
        self.conn.commit()

    def save_analysis(self,p,result):
        with self.conn:
            existing = self.conn.execute("SELECT payload FROM analysis WHERE paper_id=?", (p["id"],)).fetchone()
            previous = json.loads(existing[0]) if existing else {}
            changed = [table for table in ENTITY_TABLES if previous.get(table, []) != result.get(table, [])]
            self.conn.execute("INSERT INTO analysis(paper_id,status,payload) VALUES(?,?,?) ON CONFLICT(paper_id) DO UPDATE SET status=excluded.status,payload=excluded.payload",(p["id"],"complete",dumps(result)))
            for table in ENTITY_TABLES:
                self.conn.execute(f"DELETE FROM {table} WHERE paper_id=?",(p["id"],))
                for item in result.get(table,[]):
                    self.conn.execute(f"INSERT INTO {table}(paper_id,Source_DOI,Evidence_Text,Evidence_Section,Evidence_Page,Explicitly_Reported,Inferred,payload) VALUES(?,?,?,?,?,?,?,?)",
                      (p["id"],p.get("DOI"),item.get("Evidence_Text"),item.get("Evidence_Section"),item.get("Evidence_Page"),item.get("Explicitly_Reported","No"),item.get("Inferred","No"),dumps(item)))
            if changed:
                timestamp = now()
                self.conn.execute("INSERT INTO changes(paper_id,time,fields) VALUES(?,?,?)", (p["id"], timestamp, dumps(changed)))
                self.conn.execute("UPDATE papers SET updated_at=?,weekly_status='updated' WHERE id=?", (timestamp, p["id"]))
                p.update(updated_at=timestamp, weekly_status="updated")

    def rows(self,table):
        allowed = {*ENTITY_TABLES,"search_history","keywords","downloads","analysis","weekly_runs","email_history","changes"}
        if table not in allowed:
            raise ValueError("Unknown table")
        rows = []
        for r in self.conn.execute(f"SELECT * FROM {table}"):
            d = dict(r)
            if "payload" in d:
                d.update(json.loads(d.pop("payload") or "{}"))
            rows.append(d)
        return rows
