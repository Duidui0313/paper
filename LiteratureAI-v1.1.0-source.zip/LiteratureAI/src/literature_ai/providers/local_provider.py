class LocalProvider:
    def extract(self,blocks):
        raise RuntimeError("Local provider not configured; Ollama extension point, no model installed")
