import re
from typing import Literal
from pydantic import BaseModel, Field

SUMMARY_FIELDS = "Main_Content Research_Background Scientific_Question Problem_To_Solve Solution Experimental_Design Cells Cell_Type Animal_Model Disease_Model Tissue Methods Key_Techniques Main_Results Conclusion Limitations Future_Directions Controversies Known_Mechanism New_Mechanism New_Signaling_Axis Compared_With_Previous_Knowledge Novelty Mechanistic_Innovation Methodological_Innovation Material_Innovation Diagnostic_Innovation Therapeutic_Innovation Probe_Innovation Target_Innovation Potential_Targeting_Molecule Potential_Targeting_Peptide Potential_Substrate Potential_Inhibitor Potential_Activator Potential_Probe_Application Potential_Nanomedicine_Application".split()
PATHWAY_FIELDS = "Pathway_Name Upstream Core_Protein Downstream Activator Inhibitor Expression_Change Activity_Change Localization_Change Biological_Effect Disease_or_Phenotype".split()
PROTEIN_FIELDS = "Name Gene_Name Full_Name Abbreviation Type Function Upstream Downstream Expression_Change Activity_Change Subcellular_Localization Localization_Change Cell_Type Tissue Disease Phenotype Senescence_Relationship Potential_Targeting_Molecule Potential_Targeting_Peptide Potential_Substrate Potential_Inhibitor Potential_Activator Potential_Probe_Application Potential_Nanomedicine_Application".split()
ABBREVIATION_FIELDS = "Abbreviation Full_Name Chinese_Name Role_In_Paper Related_Pathway".split()
MECHANISM_FIELDS = "Known_Mechanism New_Mechanism New_Signaling_Axis Compared_With_Previous_Knowledge Novelty".split()
INNOVATION_FIELDS = [k for k in SUMMARY_FIELDS if k.endswith("_Innovation")]

class Fact(BaseModel):
    field: str
    value: str
    Evidence_Text: str
    Evidence_Section: str
    Evidence_Page: int = Field(ge=1)
    Explicitly_Reported: Literal["Yes","No"]
    Inferred: Literal["Yes","No"]

class Entity(BaseModel):
    category: Literal["pathways","proteins","enzymes","abbreviations","mechanisms","innovations"]
    name: str
    facts: list[Fact]

class Extraction(BaseModel):
    summary: list[Fact]
    entities: list[Entity]
    Generated_Keywords: list[str]
    Recommended_Search_Keywords: list[str]
    Related_Search_Keywords: list[str]
    Chinese_Summary: str

def compact(text):
    return re.sub(r"\s+","",text or "").casefold()

def verify_fact(fact,pages,allowed,blocks=None):
    """Validate provenance, not semantic entailment; human review is still needed."""
    if fact.field not in allowed or fact.Evidence_Page not in pages:
        return False
    if not fact.value.strip() or not fact.Evidence_Section.strip():
        return False
    quote = compact(fact.Evidence_Text)
    if len(quote) < 15 or quote not in compact(pages[fact.Evidence_Page]):
        return False
    if (fact.Explicitly_Reported, fact.Inferred) not in {("Yes", "No"), ("No", "Yes")}:
        return False
    if fact.Inferred == "Yes" and not fact.value.strip().casefold().startswith("system inference"):
        return False
    if fact.Explicitly_Reported == "Yes" and fact.value.strip().casefold().startswith("system inference"):
        return False
    if blocks is not None:
        section_text = "\n".join(block["text"] for block in blocks
            if block["page"] == fact.Evidence_Page and compact(block["section"]) == compact(fact.Evidence_Section))
        if quote not in compact(section_text):
            return False
    # Expression or abundance alone cannot establish an activity change.
    if fact.field == "Activity_Change" and not re.search(
        r"activit|cataly|enzymatic|activation|activated|inactivation|inactivated|活性|酶活|激活|活化|催化",
        fact.Evidence_Text, flags=re.I):
        return False
    if fact.field.startswith("Potential_") and fact.Inferred == "Yes":
        return False
    novelty_fields = {*INNOVATION_FIELDS, "New_Mechanism", "New_Signaling_Axis", "Novelty", "Main_Results", "Conclusion"}
    if compact(fact.Evidence_Section) == "references" and fact.field in novelty_fields:
        return False
    return True
