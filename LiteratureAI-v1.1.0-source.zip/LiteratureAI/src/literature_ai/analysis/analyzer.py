import os
import json
from pathlib import Path
from literature_ai.analysis.schema import *
from literature_ai.utils.common import MISSING, now, dumps


def evidence_chunks(blocks, limit=45000):
    """Repeat provenance on every fragment, including unusually long PDF blocks."""
    chunks, buffer, size = [], [], 0
    for block in blocks:
        header = f'\n[PDF Page {block["page"]}; Section {block["section"]}]\n'
        fragment_size = max(1, limit - len(header) - 1)
        for start in range(0, len(block["text"]), fragment_size):
            fragment = header + block["text"][start:start + fragment_size]
            if buffer and size + len(fragment) + 1 > limit:
                chunks.append("\n".join(buffer))
                buffer, size = [], 0
            buffer.append(fragment)
            size += len(fragment) + 1
    if buffer:
        chunks.append("\n".join(buffer))
    return chunks


def chinese_evidence_summary(summary, evidence):
    """Build 200–500 characters from verified facts; never promote free prose."""
    def excerpt(field):
        value = summary.get(field, MISSING)
        if value == MISSING:
            return "尚无通过原文引文核验的明确报道，需继续核对全文。"
        value = " ".join(value.split())
        if len(value) > 52:
            value = value[:51] + "…"
        pages = sorted({fact["Evidence_Page"] for fact in evidence if fact.get("field") == field})
        return value + ("（第" + "、".join(map(str, pages[:3])) + "页）" if pages else "")

    mechanism = "New_Mechanism" if summary.get("New_Mechanism", MISSING) != MISSING else "Known_Mechanism"
    innovation = next((key for key in INNOVATION_FIELDS if summary.get(key, MISSING) != MISSING), "Mechanistic_Innovation")
    text = "以下为原文引文与页码核验后的自动整理，事实含义仍需人工复核。"
    text += "研究内容：" + excerpt("Main_Content") + "主要结果：" + excerpt("Main_Results")
    text += ("新机制：" if mechanism == "New_Mechanism" else "已知机制：") + excerpt(mechanism)
    text += "创新点：" + excerpt(innovation)
    text += "关注理由：可据此检查研究模型、实验条件和相关机制是否适用于当前课题，实际相关程度应由阅读全文后判断。"
    text += "未获得证据的内容保留缺失状态；系统推断均保留标记，不作为论文直接结论。完整事实、证据原文、章节及页码见单篇笔记和表格。"
    return text

def analyze_paper(p,store):
    from literature_ai.config import openai_key_available
    if not openai_key_available():
        p.update(analysis_status="pending",AI_analysis_status="pending",Analysis_Pending_Reason="OPENAI_API_KEY required",Analysis_Failure_Reason="")
        return store.upsert(p)
    if p.get("parse_status")!="parsed" or not p.get("Fulltext_Path"):
        p.update(analysis_status="pending",AI_analysis_status="pending",Analysis_Pending_Reason="Readable full text required")
        return store.upsert(p)
    from literature_ai.providers.openai_provider import OpenAIProvider
    from literature_ai.providers.local_provider import LocalProvider
    try:
        provider = LocalProvider() if os.getenv("LLM_PROVIDER")=="local" else OpenAIProvider()
        full = json.loads(Path(p["Fulltext_Path"]).read_text(encoding="utf-8"))
        pages = {page["page"]:page["text"] for page in full["pages"]}
        # Every block is analysed, without dropping late pages/references for context limits.
        chunks = evidence_chunks(full["blocks"])
        result = {k:[] for k in ("pathways","proteins","enzymes","abbreviations","mechanisms","innovations","evidence")}
        result["summary"] = {k:MISSING for k in SUMMARY_FIELDS}
        rejected,accepted = 0,0
        chinese = []
        keyword_data = {k:[] for k in ("Generated_Keywords","Recommended_Search_Keywords","Related_Search_Keywords")}
        allowed_entities = {"pathways":PATHWAY_FIELDS,"proteins":PROTEIN_FIELDS,"enzymes":PROTEIN_FIELDS,"abbreviations":ABBREVIATION_FIELDS,"mechanisms":MECHANISM_FIELDS,"innovations":INNOVATION_FIELDS}
        seen = set()
        for chunk in chunks:
            extraction = provider.extract(chunk)
            for fact in extraction.summary:
                if verify_fact(fact,pages,SUMMARY_FIELDS,full["blocks"]):
                    current = result["summary"][fact.field]
                    if current == MISSING:
                        result["summary"][fact.field] = fact.value
                    elif fact.value not in current.split("\n"):
                        result["summary"][fact.field] = current+"\n"+fact.value
                    result["evidence"].append({**fact.model_dump(),"Source_DOI":p.get("DOI"),"Evidence_Verification":"verbatim_quote_verified; semantic review required"})
                    accepted+=1
                else:
                    rejected+=1
            for entity in extraction.entities:
                allowed = allowed_entities[entity.category]
                verified = [f for f in entity.facts if verify_fact(f,pages,allowed,full["blocks"])]
                rejected += len(entity.facts)-len(verified)
                if not verified:
                    continue
                item = {k:MISSING for k in allowed}
                for f in verified:
                    item[f.field] = f.value if item[f.field] == MISSING else item[f.field] + "\n" + f.value
                key = (entity.category,entity.name.casefold(),dumps(item))
                if key in seen:
                    continue
                seen.add(key)
                ev = verified[0]
                item.update(Name=item.get("Name") if item.get("Name") not in (None, MISSING) else entity.name,Source_DOI=p.get("DOI"),Evidence_Text=ev.Evidence_Text,Evidence_Section=ev.Evidence_Section,Evidence_Page=ev.Evidence_Page,
                    Explicitly_Reported="Yes" if all(f.Explicitly_Reported=="Yes" for f in verified) else "No",Inferred="Yes" if any(f.Inferred=="Yes" for f in verified) else "No",Field_Evidence=[f.model_dump() for f in verified])
                result[entity.category].append(item)
                result["evidence"].extend({**f.model_dump(),"Entity":entity.name,"Source_DOI":p.get("DOI"),"Evidence_Verification":"verbatim_quote_verified; semantic review required"} for f in verified)
                accepted += len(verified)
            for k in keyword_data:
                keyword_data[k].extend(getattr(extraction,k))
            # Free prose is kept for review only; report uses validated facts below.
            chinese.append(extraction.Chinese_Summary)
        if not accepted:
            raise RuntimeError("No verified evidence returned")
        p.update(result["summary"])
        for k,words in keyword_data.items():
            p[k]=list(dict.fromkeys(word.strip() for word in words if word.strip()))[:15]
        p.update(analysis_status="complete",AI_analysis_status="complete",Analyzed_At=now(),Evidence_Status="verbatim_quote_verified; semantic review required",Rejected_Claims=rejected,Analysis_Model=getattr(provider,"model","local"))
        p["Chinese_Summary"] = chinese_evidence_summary(result["summary"], result["evidence"])
        result["Unverified_Prose_Drafts"] = chinese
        result["chunks_analysed"] = len(chunks)
        store.save_analysis(p,result)
        p = store.upsert(p)
    except Exception as exc:
        # Never persist provider/SMTP exception messages containing credentials or request URL.
        p.update(analysis_status="failed",AI_analysis_status="failed",Analysis_Failure_Reason=type(exc).__name__)
        p = store.upsert(p)
    return p
