import json
import re
from pathlib import Path
from datetime import datetime
from openpyxl import Workbook, load_workbook
from openpyxl.styles import Font, PatternFill, Alignment
from openpyxl.utils import get_column_letter
from literature_ai.config import settings
from literature_ai.analysis.schema import SUMMARY_FIELDS, PATHWAY_FIELDS, PROTEIN_FIELDS, ABBREVIATION_FIELDS, MECHANISM_FIELDS, INNOVATION_FIELDS
from literature_ai.utils.common import MISSING, stem, atomic_text, dumps

PAPER_FIELDS = "Title Authors First_Author Corresponding_Author Journal Year Publication_Date Volume Issue Pages DOI PMID PMCID Abstract Publisher Publisher_URL DOI_URL PubMed_URL PMC_URL Open_Access_URL PDF_URL PDF_Local_Path Citation_Count Original_Search_Query Matched_Keywords Metadata_Source".split() + SUMMARY_FIELDS + "Pathways Proteins Enzymes Abbreviations Author_Keywords Generated_Keywords Recommended_Search_Keywords Related_Search_Keywords PDF_Path Download_Status Analysis_Status Evidence_Status Record_Type What_Was_Updated created_at updated_at".split()
EVIDENCE_FIELDS = "Source_DOI Evidence_Text Evidence_Section Evidence_Page Explicitly_Reported Inferred Field_Evidence".split()
ENTITY_COLUMNS = {"pathways":PATHWAY_FIELDS,"proteins":PROTEIN_FIELDS,"enzymes":PROTEIN_FIELDS,"abbreviations":ABBREVIATION_FIELDS,"mechanisms":MECHANISM_FIELDS,"innovations":INNOVATION_FIELDS}

def missing_information(p,store=None):
    fields = []
    for key in ("DOI","Abstract","PDF_Local_Path"):
        if p.get(key) in (None,"",MISSING): fields.append(key)
    if p.get("parse_status")!="parsed": fields.append("PDF full text / page information")
    if p.get("analysis_status")!="complete": fields.append("AI analysis / pathways / proteins / enzymes / mechanisms / innovations / evidence")
    if not p.get("Generated_Keywords"): fields.append("Generated_Keywords")
    if p.get("analysis_status")=="complete":
        fields.extend(key for key in SUMMARY_FIELDS if p.get(key) in (None,"",MISSING))
    if p.get("analysis_status")=="complete" and store:
        for table in ENTITY_COLUMNS:
            if not store.conn.execute(f"SELECT 1 FROM {table} WHERE paper_id=? LIMIT 1",(p["id"],)).fetchone():
                fields.append(table+" (not explicitly reported or missing)")
    return {"paper_id":p["id"],"Title":p["Title"],"DOI":p.get("DOI"),"Missing_Fields":"; ".join(fields),"Analysis_Status":p.get("analysis_status"),"Download_Status":p.get("download_status")} if fields else None

def paper_rows(papers,store):
    lookup = {table:store.rows(table) for table in ENTITY_COLUMNS}
    rows=[]
    for p in papers:
        r={**p,"PDF_Path":p.get("PDF_Local_Path",""),"Download_Status":p.get("download_status"),"Analysis_Status":p.get("analysis_status"),"URL":p.get("Publisher_URL") or p.get("DOI_URL"),"Evidence_Status":p.get("Evidence_Status","pending")}
        for name,table in (("Pathways","pathways"),("Proteins","proteins"),("Enzymes","enzymes"),("Abbreviations","abbreviations")):
            r[name] = list(dict.fromkeys(e.get("Name") or e.get("Pathway_Name") or e.get("Abbreviation","") for e in lookup[table] if e["paper_id"]==p["id"]))
        for key in SUMMARY_FIELDS:
            r.setdefault(key,MISSING if p.get("analysis_status")=="complete" else "Pending AI analysis")
        rows.append(r)
    return rows

def workbook(path,sheets,columns=None):
    path=Path(path); path.parent.mkdir(parents=True,exist_ok=True)
    wb=Workbook(); wb.remove(wb.active)
    for name,rows in sheets.items():
        ws=wb.create_sheet(name[:31]); rows=list(rows)
        keys=list((columns or {}).get(name,[]))
        for row in rows:
            for key in row:
                if key not in keys and key!="payload": keys.append(key)
        if not keys: keys=["Status"]
        ws.append(keys)
        for row in rows:
            values=[]
            for key in keys:
                value=row.get(key,"")
                if isinstance(value,(dict,list)): value=dumps(value)
                if isinstance(value,str):
                    value=re.sub(r"[\x00-\x08\x0b\x0c\x0e-\x1f]","",value)[:32766]
                    if value.startswith(("=","+","-","@")): value="'"+value
                values.append(value)
            ws.append(values)
        ws.freeze_panes="A2"; ws.auto_filter.ref=ws.dimensions
        ws.row_dimensions[1].height=32
        for cell in ws[1]:
            cell.font=Font(name="Calibri",bold=True,color="FFFFFF")
            cell.fill=PatternFill("solid",fgColor="30495B")
            cell.alignment=Alignment(wrap_text=True,vertical="center")
        for j,key in enumerate(keys,1):
            ws.column_dimensions[get_column_letter(j)].width = 55 if key in {"Title","Abstract","Evidence_Text","Main_Content","Main_Results","What_Was_Updated","Missing_Fields"} else 26
        if name=="Weekly_Summary":
            ws.column_dimensions["A"].width=38
            ws.column_dimensions["B"].width=95
        for row in ws.iter_rows(min_row=2):
            ws.row_dimensions[row[0].row].height=70
            for j,cell in enumerate(row):
                cell.font=Font(name="Calibri",size=11)
                cell.alignment=Alignment(wrap_text=True,vertical="top")
                key=keys[j]
                if cell.value and key=="DOI": cell.hyperlink="https://doi.org/"+str(cell.value); cell.style="Hyperlink"
                elif isinstance(cell.value,str) and cell.value.startswith(("https://","http://")) and (key.endswith("URL") or key=="URL"):
                    cell.hyperlink=cell.value; cell.style="Hyperlink"
                elif cell.value and key in {"PDF_Path","PDF_Local_Path"}:
                    target=Path(cell.value)
                    if not target.is_absolute(): target=settings.root / target
                    cell.hyperlink=target.as_uri(); cell.style="Hyperlink"
        ws.sheet_view.zoomScale=85
    temporary=path.with_name(path.stem+".tmp.xlsx")
    wb.save(temporary)
    # Reopen before publishing: guarantee a valid readable OOXML container.
    checked=load_workbook(temporary,read_only=True)
    assert checked.sheetnames==[n[:31] for n in sheets]
    checked.close(); temporary.replace(path)
    return str(path)

def export_master(store):
    papers=store.papers()
    sheets={"Papers":paper_rows(papers,store)}
    columns={"Papers":PAPER_FIELDS}
    for table,fields in ENTITY_COLUMNS.items():
        sheets[table.title()]=store.rows(table); columns[table.title()]=["paper_id"]+fields+EVIDENCE_FIELDS
    sheets.update(SearchKeywords=store.rows("keywords"),Downloads=store.rows("downloads"),FailedDownloads=[p for p in papers if p.get("download_status")=="failed"],MissingInformation=[m for p in papers if (m:=missing_information(p,store))])
    sheets["Evidence"]=store.rows("evidence"); columns["Evidence"]=["paper_id","field","value"]+EVIDENCE_FIELDS
    path=workbook(settings.root / "exports/literature_master.xlsx",sheets,columns)
    for p in papers: write_note(p,store)
    return path

def write_note(p,store):
    parts=["# "+p["Title"],"\n## Basic Information",f'Journal: {p.get("Journal","")}\n\nYear: {p.get("Year","")}\n\nDOI: {p.get("DOI","")}\n\nAuthors: {dumps(p.get("Authors",[]))}',"\n## Abstract",p.get("Abstract") or MISSING]
    for key in SUMMARY_FIELDS:
        parts.extend(["\n## "+key.replace("_"," "),str(p.get(key,"Pending AI analysis"))])
    for table in ENTITY_COLUMNS:
        parts.append("\n## "+table.title())
        entities=[r for r in store.rows(table) if r["paper_id"]==p["id"]]
        parts.append("\n".join("```json\n"+dumps(e)+"\n```" for e in entities) or (MISSING if p.get("analysis_status")=="complete" else "Pending AI analysis"))
    for title,keys in (("Upstream and Downstream",["Upstream","Downstream"]),("Localization",["Subcellular_Localization","Localization_Change"]),("Keywords",["Author_Keywords","Original_Search_Query","Generated_Keywords","Recommended_Search_Keywords","Related_Search_Keywords"]),("Evidence",["Evidence_Status"]),("PDF Location",["PDF_Local_Path"])):
        parts.append("\n## "+title)
        parts.extend(k+": "+dumps(p.get(k,MISSING)) for k in keys)
    parts.append("\n## Evidence Records")
    parts.extend("```json\n"+dumps(e)+"\n```" for e in store.rows("evidence") if e["paper_id"]==p["id"])
    target=settings.root / "library/notes" / (stem(p)+".md")
    atomic_text(target,"\n\n".join(parts))
    return str(target)
