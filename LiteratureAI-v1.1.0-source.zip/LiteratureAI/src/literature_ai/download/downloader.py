import re
import xml.etree.ElementTree as ET
from pathlib import Path
from urllib.parse import urljoin, urlparse
from bs4 import BeautifulSoup
import pymupdf as fitz
from literature_ai.config import settings
from literature_ai.utils.common import stem, now
from literature_ai.utils.network import NetworkError

def supported_url(url):
    host=(urlparse(url).hostname or "").lower()
    # Automated PMC retrieval must use the cloud/API services, never its web PDF pages.
    return urlparse(url).scheme in {"http","https"} and not (host in {"pmc.ncbi.nlm.nih.gov","www.ncbi.nlm.nih.gov"} and ("/pdf" in url or "/pmc/articles" in url))

def valid_pdf(data, content_type="application/pdf"):
    if len(data) < 1024 or not data.startswith(b"%PDF"):
        return False
    if "html" in content_type.lower():
        return False
    try:
        with fitz.open(stream=data, filetype="pdf") as doc:
            return doc.page_count > 0
    except Exception:
        return False

class Downloader:
    def __init__(self,net,store,sources):
        self.net,self.store,self.sources = net,store,sources

    def pmc_url(self,pmcid):
        # PMC's old FTP/OA service retired Aug 2026. Use documented OA cloud dataset.
        if not re.fullmatch(r"PMC\d+",pmcid or ""):
            return None
        base = "https://pmc-oa-opendata.s3.amazonaws.com/"
        response = self.net.get(base,params={"list-type":"2","prefix":pmcid+".","delimiter":"/"})
        xml = ET.fromstring(response.content)
        prefixes = [n.text for n in xml.findall(".//{*}CommonPrefixes/{*}Prefix") if n.text]
        if not prefixes:
            return None
        prefix = max(prefixes,key=lambda s:int(s.rstrip("/").split(".")[-1]))
        name = prefix.rstrip("/")
        metadata = self.net.get(base+prefix+name+".json").json()
        if not metadata.get("is_pmc_openaccess"):
            return None
        url = metadata.get("pdf_url", "")
        if url.startswith("s3://pmc-oa-opendata/"):
            return url.replace("s3://pmc-oa-opendata/",base,1)
        return base+prefix+name+".pdf" if not url else url

    def fetch(self,p):
        local = p.get("PDF_Local_Path")
        if local and Path(local).exists() and valid_pdf(Path(local).read_bytes()):
            return p
        candidates, errors = [], []
        if p.get("PMCID"):
            try:
                url = self.pmc_url(p["PMCID"])
                if url:
                    candidates.append((url,"PMC OA Cloud"))
            except Exception as exc:
                errors.append(str(exc) if isinstance(exc,NetworkError) else "pmc_lookup_error")
        # OA URLs from Europe PMC metadata precede Unpaywall and publisher fallback.
        if p.get("PDF_URL") and p.get("Open_Access") and supported_url(p["PDF_URL"]):
            candidates.append((p["PDF_URL"],p.get("Metadata_Source","OA metadata")))
        p = self.sources.enrich(p)
        for location in p.get("OA_Locations",[]):
            url = location.get("url_for_pdf") or location.get("pdf_url")
            if url and supported_url(url):
                candidates.append((url,location.get("source","Unpaywall OA")))
        if p.get("PDF_URL") and supported_url(p["PDF_URL"]):
            candidates.append((p["PDF_URL"],"documented PDF link"))
        seen, blocked = set(),set()
        for url,source in candidates:
            if url in seen or urlparse(url).netloc in blocked:
                continue
            seen.add(url)
            try:
                response = self.net.get(url,max_bytes=settings.max_pdf_mb*1024*1024)
                if not valid_pdf(response.content,response.headers.get("content-type","")):
                    reason = self.html_reason(response.text[:100000])
                    errors.append(reason)
                    self.store.record_download(p,"failed",reason,url)
                    continue
                return self.save(p,response.content,url,source)
            except Exception as exc:
                reason = str(exc) if isinstance(exc,NetworkError) else "network_error"
                errors.append(reason)
                self.store.record_download(p,"failed",reason,url)
                if reason == "publisher_blocked":
                    blocked.add(urlparse(url).netloc)
        # Normal DOI/publisher page access also checks current institutional IP rights.
        landing = p.get("Publisher_URL") or p.get("DOI_URL")
        if landing and urlparse(landing).netloc not in blocked:
            try:
                r = self.net.get(landing)
                if valid_pdf(r.content,r.headers.get("content-type","")):
                    return self.save(p,r.content,str(r.url),"publisher/institutional network")
                reason = self.html_reason(r.text)
                if reason in {"captcha","login_required"}:
                    errors.append(reason)
                else:
                    soup = BeautifulSoup(r.text,"html.parser")
                    links = [m.get("content") for m in soup.select('meta[name="citation_pdf_url"]')]
                    links += [a.get("href") for a in soup.select('a[href]') if ".pdf" in a.get("href","").lower()][:3]
                    for href in links:
                        if not href:
                            continue
                        url = urljoin(str(r.url),href)
                        if url in seen or urlparse(url).netloc in blocked:
                            continue
                        seen.add(url)
                        try:
                            pdf = self.net.get(url,max_bytes=settings.max_pdf_mb*1024*1024)
                            if valid_pdf(pdf.content,pdf.headers.get("content-type","")):
                                return self.save(p,pdf.content,url,"publisher/institutional network")
                            errors.append(self.html_reason(pdf.text[:100000]))
                        except NetworkError as exc:
                            errors.append(str(exc))
                            if str(exc)=="publisher_blocked":
                                blocked.add(urlparse(url).netloc)
            except Exception as exc:
                errors.append(str(exc) if isinstance(exc,NetworkError) else "network_error")
        # A browser profile created through the explicit login command may be reused.
        profile=settings.root / "browser_profile"
        if (profile / "Default").exists() and p.get("PDF_URL") and urlparse(p["PDF_URL"]).netloc not in blocked and "captcha" not in errors:
            try:
                from literature_ai.download.browser import download_session
                data=download_session(p["PDF_URL"],visible=False)
                return self.save(p,data,p["PDF_URL"],"user-authorized browser session")
            except Exception as exc:
                errors.append(str(exc) if str(exc) in {"publisher_blocked","captcha","login_required","pdf_not_found"} else "browser_session_unavailable")
        reason = next((e for e in ("captcha","login_required","publisher_blocked","network_error","paywall") if e in errors),errors[-1] if errors else "pdf_not_found")
        p.update(download_status="failed",Download_Failure_Reason=reason,Download_Checked_At=now())
        p = self.store.upsert(p)
        self.store.record_download(p,"failed",reason)
        return p

    @staticmethod
    def html_reason(text):
        lower = text.lower()
        if any(x in lower for x in ("captcha","verify you are human","checking your browser","recaptcha")):
            return "captcha"
        if any(x in lower for x in ("sign in to access","login to access","institutional login")):
            return "login_required"
        if any(x in lower for x in ("purchase access","buy this article","rent this article","paywall")):
            return "paywall"
        return "pdf_not_found"

    def save(self,p,data,url,source):
        path = settings.root / "library/pdfs" / str(p.get("Year") or "unknown") / (stem(p,True)+".pdf")
        path.parent.mkdir(parents=True,exist_ok=True)
        temporary = settings.root / "downloads_tmp" / (str(p["id"])+".pdf.part")
        temporary.write_bytes(data)
        temporary.replace(path)
        p.update(PDF_Local_Path=str(path.resolve()),PDF_URL=url,download_status="downloaded",PDF_Downloaded_At=now(),PDF_Access_Source=source,Download_Failure_Reason="")
        p = self.store.upsert(p)
        self.store.record_download(p,"downloaded",url=url)
        return p
