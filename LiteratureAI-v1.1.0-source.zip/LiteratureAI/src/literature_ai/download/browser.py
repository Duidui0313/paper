import time
from urllib.parse import urlparse
from literature_ai.config import settings

def manual_login(url):
    if urlparse(url).scheme not in {"https","http"}:
        raise ValueError("请输入出版社正常网页地址")
    from playwright.sync_api import sync_playwright
    with sync_playwright() as pw:
        context = pw.chromium.launch_persistent_context(str(settings.root / "browser_profile"), headless=False, accept_downloads=True)
        page = context.pages[0] if context.pages else context.new_page()
        page.goto(url,wait_until="domcontentloaded")
        print("请在可见浏览器中手动登录。程序不读取账号、密码、验证码。关闭浏览器窗口完成。")
        while context.pages:
            try:
                page.wait_for_timeout(1000)
            except Exception:
                break
        try:
            context.close()
        except Exception:
            pass

def download_session(url,visible=True):
    # Explicit command/UI action only. Use normal context request session, never export cookies.
    from playwright.sync_api import sync_playwright
    from literature_ai.download.downloader import valid_pdf, Downloader
    with sync_playwright() as pw:
        if urlparse(url).scheme not in {"https","http"}:
            raise ValueError("unsupported_url")
        context = pw.chromium.launch_persistent_context(str(settings.root / "browser_profile"),headless=not visible)
        try:
            response = context.request.get(url,timeout=50000)
            if response.status == 403:
                raise RuntimeError("publisher_blocked")
            body = response.body()
            if not valid_pdf(body,response.headers.get("content-type","")):
                raise RuntimeError(Downloader.html_reason(body[:100000].decode("utf-8",errors="ignore")))
            if len(body) > settings.max_pdf_mb*1024*1024:
                raise RuntimeError("response_too_large")
            return body
        finally:
            context.close()
