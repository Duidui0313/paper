from literature_ai.cli import app

raise SystemExit(app())
