import re
import pymupdf as fitz
import unicodedata
from pypdf import PdfReader
from literature_ai.utils.common import atomic_text, dumps
from literature_ai.config import settings

HEADINGS = {"abstract":"Abstract","introduction":"Introduction","background":"Introduction",
    "materials and methods":"Methods","methods":"Methods","experimental procedures":"Methods",
    "results":"Results","results and discussion":"Results and Discussion","discussion":"Discussion",
    "conclusion":"Conclusion","conclusions":"Conclusion","references":"References",
    "supplementary information":"Supplementary Information","supplementary material":"Supplementary Information"}

def parse_pdf(path, abstract=""):
    pages = []
    image_information_available = True
    try:
        with fitz.open(path) as doc:
            for i,page in enumerate(doc):
                area = max(page.rect.get_area(), 1)
                image_area = sum(fitz.Rect(info["bbox"]).get_area() for info in page.get_image_info())
                # Native text-block order keeps publisher columns separate.
                # PyMuPDF sort=True can interleave two columns on each line.
                text="\n".join(block[4] for block in page.get_text("blocks",sort=False) if block[6]==0)
                pages.append({"page":i+1,"text":text,
                    "image_area_fraction":min(1.0, image_area / area)})
    except Exception:
        pages = [{"page":i+1,"text":p.extract_text() or ""} for i,p in enumerate(PdfReader(path).pages)]
        image_information_available = False
    for page in pages:
        page["text_char_count"] = len(re.sub(r"\s+", "", page["text"]))
    # Low text alone also occurs in covers and digital figures. Require a large
    # raster page before marking it as an OCR candidate.
    ocr_pages = [p["page"] for p in pages if p["text_char_count"] < 80 and p.get("image_area_fraction", 0) >= .65]
    scan = bool(ocr_pages)
    section = "Front Matter"
    blocks = []
    for page in pages:
        buffer = []
        for line in page["text"].splitlines():
            clean="".join(c for c in unicodedata.normalize("NFKC",line) if unicodedata.category(c)!="Cf")
            heading = re.sub(r"^\d+(?:\.\d+)*[.)]?\s*", "", clean.strip()).lower().strip(" .:")
            inline = re.match(r"^(?:\d+(?:\.\d+)*[.)]?\s+)?(" + "|".join(
                re.escape(h) for h in sorted(HEADINGS, key=len, reverse=True)) + r")\s*[:\u2013\u2014]\s*(.+)$", clean.strip(), re.I)
            if heading in HEADINGS or inline:
                if "".join(buffer).strip():
                    blocks.append({"page":page["page"],"section":section,"text":"\n".join(buffer)})
                section = HEADINGS[inline[1].lower() if inline else heading]
                buffer = [inline[2]] if inline else []
            else:
                buffer.append(line)
        if "".join(buffer).strip():
            blocks.append({"page":page["page"],"section":section,"text":"\n".join(buffer)})
    sections = {}
    for block in blocks:
        sections.setdefault(block["section"],[]).append(block)
    return {"pages":pages,"blocks":blocks,"sections":sections,"OCR_required":scan,"OCR_candidate_pages":ocr_pages,
        "Text_Extraction_Empty":not any(p["text_char_count"] for p in pages),
        "OCR_detection":"image-backed low-text page heuristic" if image_information_available else "unknown; raster image inspection unavailable",
        "page_count":len(pages),
        "Metadata_Abstract":abstract,"section_detection":"heuristic; metadata abstract has no PDF page evidence"}

def parse_paper(p,store):
    if not p.get("PDF_Local_Path"):
        return p
    try:
        result = parse_pdf(p["PDF_Local_Path"],p.get("Abstract",""))
        target = settings.root / "library/notes" / (str(p["id"])+"_fulltext.json")
        atomic_text(target,dumps(result))
        status = "ocr_required" if result["OCR_required"] else "no_text" if result["Text_Extraction_Empty"] else "parsed"
        p.update(parse_status=status,OCR_required=result["OCR_required"],Fulltext_Path=str(target),Parsed_Sections=list(result["sections"]),PDF_Page_Count=result["page_count"])
    except Exception:
        p.update(parse_status="failed",Parse_Failure_Reason="pdf_parse_error")
    return store.upsert(p)
