import os
import ssl
import smtplib
import mimetypes
from email.message import EmailMessage
from pathlib import Path
from literature_ai.utils.common import now,dumps

def configured():
    return all(os.getenv(k) for k in ("SMTP_HOST","SMTP_USER","SMTP_AUTH_CODE","EMAIL_RECIPIENT"))

def send_message(subject,body,attachments=(),store=None,run_id=None,require_attachments=True):
    attachments=list(attachments)
    if store and run_id:
        run=store.conn.execute("SELECT email_status FROM weekly_runs WHERE id=?",(run_id,)).fetchone()
        if run and run[0]=="sent":
            return {"email_status":"sent","failure_reason":"","already_sent":True}
    status,reason="configuration_required","Email configuration required"
    attached=[]; attachment_failures=[]
    if configured():
        try:
            msg=EmailMessage(); msg["Subject"]=subject
            msg["From"]=os.getenv("EMAIL_FROM") or os.getenv("SMTP_USER")
            msg["To"]=os.environ["EMAIL_RECIPIENT"]
            msg.set_content(body,charset="utf-8")
            for path in attachments:
                try:
                    p=Path(path)
                    if p.suffix.lower() not in {".docx",".xlsx"}: raise ValueError("unsupported_attachment")
                    main,sub=(mimetypes.guess_type(p.name)[0] or "application/octet-stream").split("/",1)
                    msg.add_attachment(p.read_bytes(),maintype=main,subtype=sub,filename=p.name)
                    attached.append(str(p))
                except Exception as exc:
                    attachment_failures.append({"filename":Path(path).name,"reason":type(exc).__name__})
            if require_attachments and not attached:
                raise ValueError("no_readable_report_attachment")
            if attachment_failures:
                # The text part is already inside the multipart message.
                msg.get_body(preferencelist=("plain",)).set_content(body+"\n部分附件未能附加："+", ".join(p["filename"] for p in attachment_failures),charset="utf-8")
            host=os.getenv("SMTP_HOST"); port=int(os.getenv("SMTP_PORT","465"))
            use_ssl=os.getenv("SMTP_USE_SSL","true").lower()=="true"
            smtp=(smtplib.SMTP_SSL if use_ssl else smtplib.SMTP)
            with smtp(host,port,timeout=40,**({"context":ssl.create_default_context()} if use_ssl else {})) as client:
                if not use_ssl: client.starttls(context=ssl.create_default_context())
                client.login(os.getenv("SMTP_USER"),os.getenv("SMTP_AUTH_CODE"))
                client.send_message(msg)
            status,reason="sent",""
        except Exception as exc:
            status,reason="failed",("no_report_attachment" if not attached else type(exc).__name__)
    if store:
        store.conn.execute("INSERT INTO email_history(weekly_run_id,time,status,failure_reason,payload) VALUES(?,?,?,?,?)",(run_id,now(),status,reason,dumps({"subject":subject,"attachments":attached,"attachment_failures":attachment_failures})))
        if run_id:
            previous=store.conn.execute("SELECT payload FROM weekly_runs WHERE id=?",(run_id,)).fetchone()
            payload=__import__("json").loads(previous[0] or "{}") if previous else {}
            payload.update(email_status=status,failure_reason=reason,attachment_failures=attachment_failures)
            store.conn.execute("UPDATE weekly_runs SET email_status=?,payload=? WHERE id=?",(status,dumps(payload),run_id))
        store.conn.commit()
    return {"email_status":status,"failure_reason":reason,"attachment_failures":attachment_failures,"sent_attachments":attached}
