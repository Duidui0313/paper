@echo off
setlocal
cd /d "%~dp0"
set "LITERATUREAI_HOME=%~dp0"
set "PIP_CACHE_DIR=%~dp0.cache\pip"
set "UV_CACHE_DIR=%~dp0.cache\uv"
set "PLAYWRIGHT_BROWSERS_PATH=%~dp0.playwright"
set "TEMP=%~dp0downloads_tmp"
set "TMP=%TEMP%"
set "PYTHONUTF8=1"
set "PYTHONIOENCODING=utf-8"
if not exist "%~dp0logs\weekly" mkdir "%~dp0logs\weekly"
for /f %%T in ('powershell.exe -NoProfile -NonInteractive -Command "(Get-Date).ToString('yyyyMMdd_HHmmss')"') do set "RUN_TIME=%%T"
if not defined RUN_TIME set "RUN_TIME=unknown"
set "RUN_LOG=%~dp0logs\weekly\weekly_%RUN_TIME%.log"
if not exist "%~dp0.venv\Scripts\python.exe" (
  echo Python environment missing. Run install.ps1 first.>>"%RUN_LOG%"
  exit /b 1
)
"%~dp0.venv\Scripts\python.exe" -m literature_ai weekly-report --send-email >>"%RUN_LOG%" 2>&1
set "RUN_EXIT=%ERRORLEVEL%"
echo Log: %RUN_LOG%
exit /b %RUN_EXIT%
