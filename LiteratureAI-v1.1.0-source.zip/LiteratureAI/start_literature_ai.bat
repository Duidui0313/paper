@echo off
setlocal
cd /d "%~dp0"
set "LITERATUREAI_HOME=%~dp0"
set "PIP_CACHE_DIR=%~dp0.cache\pip"
set "UV_CACHE_DIR=%~dp0.cache\uv"
set "PLAYWRIGHT_BROWSERS_PATH=%~dp0.playwright"
set "TEMP=%~dp0downloads_tmp"
set "TMP=%TEMP%"
set "PYTHONUTF8=1"
set "PYTHONIOENCODING=utf-8"
set "STREAMLIT_BROWSER_GATHER_USAGE_STATS=false"
if not exist "%~dp0.venv\Scripts\python.exe" (
  echo Python environment missing. Run install.ps1 first.
  pause
  exit /b 1
)
"%~dp0.venv\Scripts\python.exe" -m literature_ai ui
set "RUN_EXIT=%ERRORLEVEL%"
if not "%RUN_EXIT%"=="0" pause
exit /b %RUN_EXIT%
