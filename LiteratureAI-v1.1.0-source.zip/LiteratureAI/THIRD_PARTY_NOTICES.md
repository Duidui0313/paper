# 第三方组件

源码包不包含第三方依赖的源码、二进制文件、浏览器或模型权重；安装时按 `pyproject.toml` 获取。

本项目 MIT 许可证只覆盖本项目自行编写的源码，不会替代依赖自身的许可。尤其是 PyMuPDF / MuPDF 有 AGPL 与商业许可安排；发布包含依赖的应用、服务或二进制包时，应另行核对适用条款。本次打包未对商业分发作出许可结论。

- [PyMuPDF 许可说明](https://pymupdf.readthedocs.io/en/latest/about.html#license-and-copyright)
- [Streamlit](https://github.com/streamlit/streamlit)
- [python-docx](https://github.com/python-openxml/python-docx)
- [openpyxl](https://openpyxl.readthedocs.io/)
- [Playwright Python](https://github.com/microsoft/playwright-python)
- [OpenAI Python SDK](https://github.com/openai/openai-python)

完整直接依赖见 `pyproject.toml`，开发环境版本快照见 `requirements-tested.txt`。下载的论文、出版社材料、数据库记录及用户生成的报告不随本源码包分发。
