# 将 LiteratureAI 分享到 GitHub

## 方法一：网页上传

1. 在自己的 GitHub 账户创建空仓库，建议名称 `LiteratureAI`，需要所有人下载则选择 Public。
2. 解压源码 ZIP，进入其中的 `LiteratureAI` 文件夹。
3. 在 GitHub 仓库的上传文件页面上传文件夹内的源码、文档和配置模板。
4. 确认根目录能看到 `README.md`、`pyproject.toml`、`src/` 和 `.env.example`。不要只上传一个 ZIP，否则首页不会展示项目说明。
5. 提交后，把仓库网址分享给别人。下载入口为 Code → Download ZIP。

如果文件选择器隐藏点开头文件，请检查 `.gitignore`、`.env.example` 和 `.github/` 是否包含；命令行 Git 可以完整保留它们。

## 方法二：Git 推送

在新建的空仓库中复制真实远程地址，在此项目根目录执行：

```powershell
git init
git add .
git status --short
git commit -m "Initial LiteratureAI source release"
git branch -M main
git remote add origin https://github.com/YOUR_ACCOUNT/LiteratureAI.git
git push -u origin main
```

`YOUR_ACCOUNT` 是占位符；使用自己创建的仓库地址。GitHub 登录由本人完成，不要把访问令牌写进源码或 remote URL。

## 发布可下载的源码包

```powershell
python tools/package_release.py
```

它按允许清单打包源码与文档，排除 PDF、Word、数据库、密钥文件、运行数据及虚拟环境；同时检查典型凭据格式。生成文件在 `dist/`：源码 ZIP 和 SHA256 文件。

可在仓库 Releases 页面创建 `v1.1.0` 版本，上传 ZIP 与 SHA256 文件。GitHub 自带的 Source code 下载同样可用。该版本是 Python 源码包，**不是免安装 EXE**；使用者需安装 Python 及依赖。

## 发布前核对

- `.env.example` 中密钥、联系邮箱、SMTP 用户和收件人保持空白。
- 不上传 `.env`、`browser_profile/`、`library/`、`data/`、`exports/`、`weekly_reports/`、日志或私有检索词。
- 只将此独立项目目录作为仓库内容，不要把上级科研工作目录一起提交。
- 若曾经误提交真实凭据，仅删除文件不足以清理 Git 历史，应先撤销凭据，再处理历史。

首次公开发布由仓库所有者操作。此源码包本身不会创建仓库或上传数据。
